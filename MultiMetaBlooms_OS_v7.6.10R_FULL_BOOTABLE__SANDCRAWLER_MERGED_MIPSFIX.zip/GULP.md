# GULP — Generalized Universal Learning Procedure (MetaBlooms)

GULP is MetaBlooms’ **non-bypassable epistemic learning regime**. It governs how MetaBlooms reads, understands, and transforms
artifacts across domains (code, prose, specs, chats, datasets) by enforcing **whole-artifact reconstruction, metacognitive checks,
and fail-closed phase gates**.

## P0 invariant (governance, not utility)

**No action may occur until GULP has completed its phases and certified a minimum understanding state.**
If a phase cannot be completed, the system must **fail closed** (block downstream action) or explicitly record a governed bypass.

## Phases (must be logged)

1. **Ingest** — identify artifact boundaries; acquire the full artifact (repo graph, full text, full transcript).
2. **Decode** — parse and normalize surface form (structure, vocabulary, symbols, API surfaces).
3. **Comprehend** — build a coherent model of intent, structure, constraints, and assumptions.
4. **Integrate** — reconcile with existing doctrine/indices; map to canonical concepts (e.g., Code-as-Prose, TEKS anchors).
5. **Apply** — produce outputs constrained by the comprehension model (diffs, fixes, syntheses).
6. **Reflect** — run root-cause checks, missingness checks, and regression detection; externalize insights as artifacts.

## Artifact-type → reading-mode map (hard rule)

- **Repository**: prose-first, narrative-first, whole-artifact (graph) → then structural and constraints passes.
- **Prose (novel/article)**: linear narrative → structure/inference → reflection.
- **Spec/policy**: prose-as-code (state/invariants/pre/postconditions/undefined behavior) → testable implications.
- **Failure report**: reconstruct chronology → isolate structural allowance → certify root cause.

## Transfer rule

Transfer fails when GULP is treated as an optional capability. Therefore:

- GULP must sit **above** the reasoning engine, the router, and export/shipping.
- Export is prohibited unless the governed learning artifacts (ledgers, diffs, gates) are included.

## Minimal outputs (append-only)

- Reading ledger(s) (ndjson/md)
- Evidence log (v2)
- Missingness diff (if re-reading)
- Certified root-cause statements
- Preflight/ship gate result
