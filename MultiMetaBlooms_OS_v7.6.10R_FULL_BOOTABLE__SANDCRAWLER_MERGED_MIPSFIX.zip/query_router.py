#!/usr/bin/env python3
"""Query router for MultiMetaBlooms bundles.

Purpose: provide 'snap' navigation over the mounted OS using SYSTEM_INDEX.json.

Supported:
- list
- find <substring>
- grep <regex> [--ext md,py,json]
- whereis <keyword>  (alias: find)
- gulp  (locate Unified Literacy / code-as-prose artifacts)
"""
from __future__ import annotations
from pathlib import Path
import json, re, sys

ROOT = Path(__file__).resolve().parent
INDEX_PATH = ROOT / "SYSTEM_INDEX.json"

def _load():
    if not INDEX_PATH.exists():
        raise SystemExit("ROUTER_FAIL: SYSTEM_INDEX.json missing. Run metablooms_system_indexer.py.")
    return json.loads(INDEX_PATH.read_text(encoding="utf-8"))

def _paths(idx):
    """Return inventory paths from SYSTEM_INDEX.json across schema variants.

    v7.6+ schema uses 'inventory' (list of {path, sha256, size, tags}).
    Legacy schema used 'files'.
    """
    candidates = None
    for key in ("inventory", "files"):
        v = idx.get(key)
        if isinstance(v, list):
            candidates = v
            break
    if not candidates:
        return []
    return [f.get("path") for f in candidates if isinstance(f, dict) and f.get("path")]

def cmd_list(args):
    idx=_load()
    for p in _paths(idx):
        print(p)

def cmd_find(args):
    if not args: raise SystemExit("usage: find <substring>")
    needle=" ".join(args).lower()
    idx=_load()
    hits=[p for p in _paths(idx) if needle in p.lower()]
    print("\n".join(hits) if hits else "NO_MATCH")

def cmd_grep(args):
    if not args: raise SystemExit("usage: grep <regex> [--ext md,py,json]")
    exts=None
    if "--ext" in args:
        i=args.index("--ext")
        exts=set(e.strip().lower().lstrip(".") for e in args[i+1].split(","))
        args=args[:i]
    pat=re.compile(" ".join(args), re.I)
    idx=_load()
    for p in _paths(idx):
        path=ROOT / p
        if exts and (path.suffix.lower().lstrip(".") not in exts):
            continue
        if path.suffix.lower() not in {".md",".py",".json",".txt"}:
            continue
        try:
            text=path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if pat.search(text):
            print(p)

def cmd_gulp(args):
    idx=_load()
    # heuristic: anything mentioning code-as-prose, literacy engine, TEKS+SoR pipeline, ULP
    keys=["code_as_prose","code as prose","science_of_reading","teks","literacy","schema_proxy","unified literacy","ulp","gulp"]
    paths=_paths(idx)
    hits=[]
    for p in paths:
        pl=p.lower()
        if any(k in pl for k in ["code_as_prose","science_of_reading","sor","teks","literacy","schema_proxy","ulp","gulp"]):
            hits.append(p)
    # content-based add
    for p in paths:
        path=ROOT/p
        if path.suffix.lower() not in {".md",".json",".py",".txt"}:
            continue
        try:
            text=path.read_text(encoding="utf-8", errors="ignore").lower()
        except Exception:
            continue
        if any(k in text for k in keys):
            if p not in hits:
                hits.append(p)
    if not hits:
        print("GULP_NOT_FOUND: No artifacts mention GULP/ULP/code-as-prose. If expected, add a named marker file (e.g., GULP.md) and re-index.")
    else:
        print("\n".join(sorted(hits)))

def main():
    if len(sys.argv)<2:
        raise SystemExit("usage: query_router.py <list|find|grep|whereis|gulp> ...")
    cmd=sys.argv[1].lower()
    args=sys.argv[2:]
    if cmd in ("list",):
        cmd_list(args)
    elif cmd in ("find","whereis"):
        cmd_find(args)
    elif cmd=="grep":
        cmd_grep(args)
    elif cmd=="gulp":
        cmd_gulp(args)
    else:
        raise SystemExit(f"unknown command: {cmd}")

if __name__=="__main__":
    main()
