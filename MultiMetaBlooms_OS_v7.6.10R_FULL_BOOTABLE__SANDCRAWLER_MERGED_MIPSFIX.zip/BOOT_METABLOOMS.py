#!/usr/bin/env python3
"""BOOT_METABLOOMS.py — Canonical Immutable Entry Point for MetaBlooms OS (Fail-Closed).

Boot steps:
1) Locate `boot_manifest.json` in bundle root. If missing => BOOT_FAILED: NO_ENTRYPOINT
2) Verify doctrine files listed in manifest exist/readable. If missing => BOOT_FAILED: MISSING_DOCTRINE
3) Verify entrypoint declared is this file.
4) Execute preflight scripts (python) in-order. If any fail => BOOT_FAILED: PREFLIGHT_FAILED
5) Transfer control to `RUN_METABLOOMS.py` (`boot_metablooms()` if present, else `main()`).
"""

from __future__ import annotations

import json
import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def _die(msg: str) -> None:
    raise SystemExit(msg if msg.startswith("BOOT_FAILED:") else f"BOOT_FAILED: {msg}")

def _read_manifest() -> dict:
    mp = ROOT / "boot_manifest.json"
    if not mp.exists():
        _die("NO_ENTRYPOINT")
    try:
        return json.loads(mp.read_text(encoding="utf-8"))
    except Exception as e:
        _die(f"MANIFEST_UNREADABLE ({e})")

def _require(rel: str) -> None:
    p = ROOT / rel
    if not p.exists():
        _die(f"MISSING_FILE ({rel})")
    if not p.is_file():
        _die(f"NOT_A_FILE ({rel})")
    try:
        _ = p.read_bytes()
    except Exception as e:
        _die(f"UNREADABLE_FILE ({rel}) ({e})")

def _run_preflight(rel: str) -> None:
    _require(rel)
    try:
        runpy.run_path(str(ROOT / rel), run_name="__main__")
    except SystemExit as e:
        if getattr(e, "code", 0) not in (0, None):
            _die(f"PREFLIGHT_FAILED ({rel}) (exit={e.code})")
    except Exception as e:
        _die(f"PREFLIGHT_FAILED ({rel}) ({e})")

def main() -> None:
    m = _read_manifest()

    doctrine = m.get("doctrine", [])
    if not isinstance(doctrine, list) or not doctrine:
        _die("MISSING_DOCTRINE")
    for rel in doctrine:
        _require(rel)

    if m.get("entrypoint") != "BOOT_METABLOOMS.py":
        _die(f"ENTRYPOINT_MISMATCH ({m.get('entrypoint')})")
    _require("BOOT_METABLOOMS.py")

    preflight = m.get("preflight", [])
    if not isinstance(preflight, list) or not preflight:
        _die("PREFLIGHT_FAILED")
    for rel in preflight:
        _run_preflight(rel)


    # MIPS authority boundary: reconcile + verify self-index before runtime.
    try:
        from metablooms.tools.mips_reconcile import main as _mips_reconcile_main
        rc = _mips_reconcile_main()
        if rc != 0:
            _die(f"MIPS_INDEX_RECONCILE_FAILED (rc={rc})")
    except SystemExit as e:
        code = getattr(e, "code", 1)
        if code not in (0, None):
            _die(f"MIPS_INDEX_RECONCILE_FAILED (exit={code})")
    except Exception as e:
        _die(f"MIPS_INDEX_RECONCILE_FAILED ({e})")

    try:
        import RUN_METABLOOMS as run_mod
    except Exception as e:
        _die(f"NO_RUNTIME (import RUN_METABLOOMS failed: {e})")

    if hasattr(run_mod, "boot_metablooms"):
        run_mod.boot_metablooms()
    elif hasattr(run_mod, "main"):
        run_mod.main()
    else:
        _die("NO_RUNTIME (RUN_METABLOOMS missing boot_metablooms/main)")

    # Fail-closed continuity: ledger + capsule generation.
    try:
        from metablooms.governance.post_boot_enforcer import enforce_post_boot
        _ = enforce_post_boot(str(ROOT))
    except SystemExit as e:
        code = getattr(e, "code", 1)
        if code not in (0, None):
            _die(f"POST_BOOT_ENFORCER_FAILED (exit={code})")
    except Exception as e:
        _die(f"POST_BOOT_ENFORCER_FAILED ({e})")

    # Signal success as the last line so external orchestrators can key off it.
    print("BOOT_OK")

if __name__ == "__main__":
    main()
