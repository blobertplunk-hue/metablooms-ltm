# Root Cause: Missing System Index Generation (MetaBlooms)

## Executive finding (root cause, not symptom)
The **system index did not exist** because MetaBlooms' **P0 invariants and preflight acceptance criteria did not include “index must exist and be loaded”**; therefore the build/boot pipeline had **no enforcement point** that could detect or prevent the omission.

In other words: the failure was not “the index wasn't generated.” The failure was that the **governance layer failed to define and enforce the index as mandatory**, so the pipeline correctly (but undesirably) allowed a “boot-success-without-index” state.

---

## Evidence (from the bundle as shipped)
### What the boot contract actually enforced
1. `BOOT_METABLOOMS.py` enforces: manifest exists, doctrine exists, preflight scripts run, then control passes to runtime.
2. `boot_manifest.json` listed only:
   - `metablooms_boot_gate.py`
   - `metablooms_smoke_test.py`
3. `metablooms_core_doctrine.md` P0 invariants did **not** require a system index.

### What was missing
- No gate that:
  - generates SYSTEM_INDEX.json, and
  - validates it, and
  - loads/uses it as a first-class artifact.

---

## Root cause chain (5-Whys)
1. **Why couldn't the system “snap-resolve” locations?**
   Because there was no authoritative, precomputed index loaded.
2. **Why wasn't the index present?**
   Because no script produced it during boot or export.
3. **Why didn't boot/export produce it?**
   Because the manifest/preflight did not contain a SystemIndex step.
4. **Why didn't the manifest/preflight contain it?**
   Because doctrine + boot contract omitted “SystemIndex required” as a P0 invariant and acceptance criterion.
5. **Why did doctrine omit it?**
   Because the prior “make it bootable” patch scope was treated as satisfied when boot passed, but the *product requirement* (instant path resolution) was not encoded into the fail-closed gate.

**Root cause (final):** governance gap — “index required” was not encoded as a P0 invariant and therefore could not be enforced.

---

## What changed (fix)
This fix adds a **System Index Gate** as a mandatory preflight stage.

### Added
- `metablooms_system_index.py` — deterministic generator
- `metablooms_system_index_gate.py` — fail-closed preflight that:
  - generates `SYSTEM_INDEX.json`
  - validates minimal schema + canonical presence
  - logs success to `logs/boot_log.ndjson`

### Updated
- `boot_manifest.json` — added `metablooms_system_index_gate.py` to preflight list
- `metablooms_core_doctrine.md` — added P0 invariant requiring system index
- `metablooms_boot_gate.py` — requires generator + gate scripts exist
- `RUN_METABLOOMS.py` — version alignment and boot file exclusions updated

---

## Root Cause Engine Upgrade (so this doesn't repeat)
### Problem
The engine is classifying **absence-of-step** as “root cause.” That is a symptom statement.

### Correct root-cause framing rule
A valid root cause must be one of:
- a missing/incorrect **requirement** (doctrine/invariant/acceptance criteria),
- a missing/incorrect **enforcement point** (gate/test/preflight),
- a missing/incorrect **build artifact dependency** (pipeline wiring),
- or a missing/incorrect **ownership boundary** (who is responsible for generating/loading it).

### New engine template (drop-in)
When a step is missing, the engine MUST answer:
1) **Where should this requirement have been declared?** (doctrine section + invariant ID)
2) **Where should it have been enforced?** (gate/test name + phase)
3) **Why did enforcement not exist?** (scope/omission/ownership)
4) **What prevents recurrence?** (new invariant + new gate + regression test)

If the engine cannot point to the missing requirement/enforcement, it must output:
- `ROOT_CAUSE_INSUFFICIENT: REQUIREMENT_OR_ENFORCEMENT_NOT_IDENTIFIED`

---

## Regression test (definition of done)
Boot must now fail-closed if:
- `SYSTEM_INDEX.json` cannot be generated,
- schema validation fails,
- or canonical boot/runtime artifacts are not represented in inventory.

Success criteria:
- Boot prints `SYSTEM_INDEX_OK` during preflight.
- `SYSTEM_INDEX.json` exists in bundle root after boot.

