# 2026-01-02 OS Indexing Master Plan v1 (MetaBlooms)

This is the full, end-to-end plan to **index the OS** so MetaBlooms can answer “what exists / what it does / where it is / what it depends on / what breaks” by reading **one canonical index** instead of rereading the entire codebase.

This plan is designed to be:
- **Fail-closed** (unknown stays unknown; nothing silently promoted)
- **Evidence-backed** (every claim points to files/facts)
- **Reproducible** (another expert can rerun it)
- **Modular** (facts layer vs meaning layer vs query layer)
- **Above-board** (provenance + license posture built-in)

---

## 0) Terms (so we stay unambiguous)

### OSI (OS Semantic Index)
The canonical “one index” registry: **human-meaningful component map** with risks, invariants, activation phrases, and integration notes.

### Facts Layer (Glean Adapter)
A **structured facts export** about the codebase (symbols, refs, dependencies, etc.). Facts never decide meaning; they accelerate and validate meaning-layer indexing.

### Indexing Run
A single execution that produces:
- Updated `INDEX/OS/index.meta.json`
- Updated ledgers under `ledgers/indexing/`
- Optional `INDEX/FACTS/glean/latest.ndjson` ingestion + links

### Promotion
Moving a module/engine/validator from “found” to “canonical/promoted,” with gates and provenance.

---

## 1) Target End-State File Tree (authoritative)

```
INDEX/
  OS/
    index.meta.json                 # Canonical cognitive index (machine-readable)
    index.meta.md                   # Rendered human view of the same data
    vocab.json                      # Controlled vocabulary for roles/types/risks
    schemas/
      os_index.schema.json          # JSON schema for index.meta.json
      os_component.schema.json      # Component entry schema
    reports/
      latest_run_summary.md         # Summary of last indexing run
  FACTS/
    glean/
      latest.ndjson                 # Optional facts export from Glean adapter
      schema.json                   # Facts schema
      README.md
META/
  external_specs/
    glean_adapter_spec_v1/          # Spec (already installed by installer DeltaPack)
kernel/
  indexing/
    indexer.py                      # Query-first indexer orchestrator
    passes/
      pass0_inventory.py            # minimal scan (no deep reading)
      pass1_component_discovery.py  # detect candidate components/modules
      pass2_behavioral_reading.py   # reading-as-prose / BCA extraction
      pass3_link_facts.py           # link Glean facts (if present)
      pass4_render_and_validate.py  # render md, validate schema, write ledgers
    queries/
      index_query.py                # unified query API over OSI + facts
  adapters/
    glean/                          # adapter scaffold (installed)
governance/
  gates/
    os_index_gate.json              # gate rules for OSI integrity
    provenance_gate.json            # gate rules for provenance completeness
ledgers/
  indexing/
    runs.ndjson                     # one entry per indexing run
    components.ndjson               # one entry per component processed
    decisions.ndjson                # decisions made (promote/deprecate/hold)
    failures.ndjson                 # failures + root-cause
  provenance/
    provenance.ndjson               # attribution + license posture records
```

---

## 2) “Query-First” Invariant (the behavioral core)

### Rule
When MetaBlooms needs to answer “where is X?” it must:

1. **Read OSI** (`INDEX/OS/index.meta.json`) for canonical answer.
2. If missing/unknown:
   - Consult **facts layer** (`INDEX/FACTS/glean/latest.ndjson`) if present.
3. Only then:
   - Read the specific file(s) referenced by OSI/facts.
4. If still unknown:
   - Mark as unknown and create an indexing task entry (no invention).

This prevents full rereads, context blowups, and “inventory-only” failure modes.

---

## 3) Index Data Model (OSI component entry: required fields)

Every component must have, at minimum:

- `component_id` (stable identifier, namespaced)
- `display_name`
- `type` (engine | validator | gate | module | tool | runtime | adapter | doc)
- `role` (orchestration | pedagogy | validation | generation | governance | IO | etc.)
- `does` (one sentence)
- `where` (list of file/dir paths)
- `invoked_when` (activation phrases, boot stage triggers, or explicit calls)
- `inputs` / `outputs`
- `side_effects` (explicit)
- `invariants` (explicit, testable)
- `risks` (explicit)
- `depends_on`
- `status` (canonical | experimental | deprecated | unknown)
- `evidence` (file references; if facts present, `facts_links`)
- `provenance_ref` (pointer into provenance ledger)

No entry is allowed to omit evidence/provenance once promoted.

---

## 4) Indexing Pipeline (multi-pass, agent-friendly, repeatable)

### PASS 0 — Inventory (fast, non-semantic)
**Goal:** produce a stable snapshot of what exists without interpreting.
Outputs:
- file counts by extension
- directory map
- candidate entrypoints and manifests
Ledgers:
- `ledgers/indexing/runs.ndjson` (pass markers)
- `ledgers/indexing/failures.ndjson` if errors

### PASS 1 — Component Discovery (structure-to-candidates)
**Goal:** identify “things worth indexing” as candidate components.
Heuristics:
- known directories (`kernel/`, `engines/`, `validators/`, `governance/`, `INDEX/`)
- filenames patterns (`*_engine.py`, `*_validator.py`, `gate*.json`, `manifest*.json`)
Outputs:
- candidate list with `where` paths and preliminary `type`
Ledger:
- `ledgers/indexing/components.ndjson` with state = `discovered`

### PASS 2 — Behavioral Reading (code-as-prose + BCA)
**Goal:** interpret behavior (not inventory).
Methods:
- read key files per candidate
- extract:
  - role
  - side effects
  - invariants
  - risks
  - integration requirements
Output:
- enriched component records
Ledger:
- `components.ndjson` updated to state = `interpreted`
- `decisions.ndjson` if any “hold/promote/deprecate” decisions occur

### PASS 3 — Facts Linking (optional, accelerative)
**Goal:** if Glean facts exist, attach `facts_links` to components:
- symbol IDs
- definitions/references
- call edges
Output:
- OSI entries gain `facts_links`
Gate behavior:
- Advisory mode: missing facts OK
- Gate mode (later): facts must validate key claims (refs/defs)

### PASS 4 — Validate + Render + Freeze
**Goal:** produce canonical index artifacts and enforce correctness.
Steps:
- validate `INDEX/OS/index.meta.json` against schema
- render `index.meta.md`
- write `INDEX/OS/reports/latest_run_summary.md`
- update `vocab.json` if new controlled terms introduced
Gates:
- OSI schema validation must pass
- provenance completeness must pass for anything promoted

---

## 5) Governance & Gates (fail-closed, no Frankenstein)

### Gate: OS Index Integrity (`governance/gates/os_index_gate.json`)
Blocks promotion/export if:
- missing required fields for canonical components
- any canonical component lacks evidence
- duplicate component_ids
- broken paths (referencing files that do not exist)

### Gate: Provenance (`governance/gates/provenance_gate.json`)
Blocks promotion/export if:
- a component’s provenance_ref is missing
- the provenance record lacks license posture
- third_party content is not isolated under `/third_party/` with license text

### Mode toggles
- **ADVISORY**: logs failures but does not block
- **GATE**: blocks export / promotion

Default posture for new systems:
- ADVISORY until validated in at least 3 runs
- then promote to GATE for canonical release builds

---

## 6) Above-Board Policy (how we “steal” safely)

### Allowed “steals”
- ideas, architectures, data models (copyright does not cover ideas)
- adapter-based use of open-source tools (license respected)
- clean-room reimplementation

### Disallowed
- copying code snippets into core without license isolation
- schema cloning too closely without attribution (even if legal, it’s risky optics)
- “LLM regurgitation” of proprietary material

### Mandatory artifact
`ledgers/provenance/provenance.ndjson` entries for each external influence.

---

## 7) How this answers your “everything about everything” requirement

Once OSI exists and is maintained:
- “Where is the social studies planner?” → OSI entry returns paths + activation phrase.
- “What breaks if I turn on Sandpipe?” → OSI returns side effects + required gates.
- “Do we have an HTML generation engine?” → OSI lists engines by type/role.
- “What’s safe to run experimentally?” → status=experimental + do_not_use_if conditions.

The coordinator reads OSI first; it does not “hunt and guess.”

---

## 8) Deliverables Sequence (what gets shipped, in order)

1. **(DONE)** Glean adapter spec + installer DeltaPack
2. **NEXT** OS Indexing DeltaPack v1 (adds INDEX/OS + kernel/indexing + gates + ledgers)
3. **THEN** First indexing run on canonical OS → produce initial `index.meta.json`
4. **THEN** Promote “query-first” into runtime behavior (so all engines consult OSI)
5. **THEN** Move key gates from ADVISORY → GATE after stabilization

---

## 9) Acceptance Criteria (objective “done” signals)

Indexing system is “working” when:
- A fresh chat can answer 90% of “where is X / what does it do” questions by reading only:
  - `INDEX/OS/index.meta.json`
  - plus optional `index.meta.md`
- A promotion/export fails closed if index integrity/provenance fails
- Indexing runs are logged with reproducible evidence
- Missing items become explicit backlog entries, not hallucinations

---

## 10) What you should expect next

If you say **“Proceed with OS Indexing DeltaPack v1”**, the next package will:
- Install the `INDEX/OS/` tree
- Install `kernel/indexing/` orchestrator + pass scaffolds
- Install OSI schema + vocab
- Install OS index integrity gate + provenance gate (ADVISORY by default)
- Wire ledgers under `ledgers/indexing/`
- Provide a single entrypoint script for “run indexing pass suite” (OS-run, not user-run)
