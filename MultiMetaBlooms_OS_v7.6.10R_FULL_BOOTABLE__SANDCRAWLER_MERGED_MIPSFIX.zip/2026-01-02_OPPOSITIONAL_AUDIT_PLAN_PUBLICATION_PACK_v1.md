# Oppositional Audit Report (Plan) — ELAR Publication Pack v1

## Scope
Audit the exported public-facing pack for:
- Citation validity and “primary source” compliance
- Anchor accuracy (page/section pointers)
- Claim scope control (no overreach)
- Audience safety (no internal mechanics, no AI/tooling pitch)
- Reproducibility (someone else can verify)

## Adversarial Questions (Attack Surface)
1. **Citation laundering:** Are any citations secondary/tertiary while presented as primary?
2. **Anchor drift:** Do anchors point to exact locations, or approximate sections that could be disputed?
3. **Claim inflation:** Do any statements imply causal conclusions beyond what sources support?
4. **Omitted counterevidence:** Are there known alternative interpretations not acknowledged where appropriate?
5. **Policy mischaracterization:** Do we describe TEA/TEKS requirements in a way that could be challenged?
6. **Audience mismatch:** Does any section inadvertently reveal internal system mechanics or “how we did it”?
7. **Compliance risk:** Are we making recommendations that imply legal mandates, compliance guarantees, or medical claims?
8. **Reputational risk:** Could the pack be dismissed as “AI output” due to tone, verbosity, or lack of concrete anchors?

## Findings (Fail-Close Evaluation)
### P1 — Anchor robustness
- Expected: each key finding has an exact page/section anchor.
- Risk: if any anchor is approximate or depends on non-extractable PDF text, it’s disputable.
- Required fix: where text extraction is weak, add page screenshots as verification evidence (internal) and tighten the published anchor wording.

### P2 — Primary-source enforcement
- Expected: claims table references primary sources (TEA/TEKS documents, official guidance, peer-reviewed literature where needed).
- Risk: any blog/news summary treated as “evidence”.
- Required fix: mark any non-primary as UNSUPPORTED for publication unless corroborated by primary.

### P3 — Claim scope control
- Expected: descriptive diagnostic statements, not prescriptions masquerading as mandates.
- Risk: “should” language interpreted as compliance directive.
- Required fix: separate “observations” vs “options”; add uncertainty flags.

### P4 — Audience safety
- Expected: no internal mechanism disclosure.
- Risk: accidental leakage through methodology narrative.
- Required fix: ensure all methodology references remain high-level and non-tool-specific.

## Required Repairs (Publication Hardening)
1. **Claims→Citations tightening**: re-check every claim; drop/mark UNSUPPORTED if primary source absent.
2. **Anchor tightening**: ensure each high-impact finding cites page+section; avoid “around page”.
3. **Tone pass**: convert any persuasive phrasing into neutral diagnostic language.
4. **Optional**: add a one-page “How to verify this pack” checklist for admins.

## Decision Trace
**AUDIT RESULT:** HOLD — Pack is strong and exportable, but publication hardening must confirm anchor accuracy and primary-source compliance for every high-impact claim.
