# 2026-01-02_LITERACY_WQI_SPEC_v1
## MetaBlooms Literacy Ledger — Write + Query Interface (WQI v1)

**Purpose:** Provide the minimal executable interface for persistence and inspection of literacy advancement runs (MER/AIL), using an append-only NDJSON ledger.

---

## Canonical Storage
- **Ledger (append-only):** `ledgers/literacy/literacy_runs.ndjson`
- **Optional query trace (append-only):** `ledgers/literacy/query_trace.ndjson`

NDJSON is canonical; derivative indexes are permitted later, but must be regenerable from NDJSON.

---

## Record Contract (One line per MER run)

### Required fields
- `ts_utc` (ISO 8601 UTC)
- `run_id` (deterministic or UUID; must be unique)
- `artifact_id`
- `task_id`
- `target_grade_band`
- `required_schema_set` (list)
- `ail` (object)
  - `decision` ∈ {PASS, HOLD, REPAIR, BLOCK}
  - `justification`
  - `next_required`

### Allowed supporting fields (optional)
- `cmd` (list)
- `ssm` (list)
- `sca` (object)
- `rdr` (object)
- `failure_signal` (string)

---

## API Surface

### Write (append-only)
- `append_run(record, ledger_path=DEFAULT_LEDGER_PATH)`
- **Fail-closed:** missing required fields → exception → caller must treat as HOLD.

### Query (read-only, bounded)
- `query_runs(ledger_path=..., artifact_id=None, grade_band=None, schema_id=None, decision=None, failure_signal=None, limit=50)`
- Default cap is required to prevent runaway scans.

### Query Audit Trace (optional)
- `query_trace_log(trace_path, query_params)` appends query params for audit.

---

## Governance / Integrity Requirements
- No delete or update operations.
- Any downstream index must be re-buildable from NDJSON (deterministic regeneration).
- Corrupt lines: skipped by the query function; a separate audit sweep must detect and repair corruption (out of scope for v1).

---

## Next Wiring Step (Build Plan)
1. MER produces the run record object.
2. MER calls `append_run()`.
3. Query Router uses `query_runs()` to answer “what did we do already?” questions (grade band, schema ID, decision).
