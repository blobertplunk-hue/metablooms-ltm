# SOP-03 — ToolSmithing (On-Demand Tool Creation)

Status: active
Created: 2025-12-29T13:13:08.156260+00:00

## Purpose
Convert repeated ambiguity into a small runnable tool that produces ground truth and accelerates convergence.

## Inputs
- Task goal (what "correct" means)
- Any fixed constraints (no deps, pure HTML, file formats)
- Example(s): a reference image, prior artifact, expected outputs

## Procedure
1) Identify the uncertainty class:
   - Visual correctness, parsing correctness, constraint enforcement, or export integrity.
2) Choose the minimum tool form:
   - Python CLI tool if transformation/validation is needed.
   - Single-file HTML tool if interactive tuning helps (e.g., thresholds, grid sizes).
3) Implement the minimum pipeline:
   - Load → Transform → Validate → Export
4) Add one “hard gate” check:
   - Fail closed and print a concrete reason.
5) Produce an artifact that can be dropped into downstream pipelines.

## Definition of Done
- Tool runs end-to-end with a single command (or opens in a browser) and produces an output file.
- Output is repeatable with the same inputs.
- The tool’s parameters are explicit (flags or UI sliders).
- The tool reduces further iteration to tuning, not guessing.

