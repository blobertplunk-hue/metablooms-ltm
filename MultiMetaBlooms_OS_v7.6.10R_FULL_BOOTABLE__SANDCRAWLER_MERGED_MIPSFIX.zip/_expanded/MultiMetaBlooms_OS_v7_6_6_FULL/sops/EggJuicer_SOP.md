# Egg Juicer SOP — EJ-SOP-1.0

Purpose:
- Ensure any corpus (chat chunks, code batches, research dumps) is exhaustively extracted into durable artifacts.

Core rule:
- Do not compress early. Exhaust objects first.

Operating procedure:
1) Select the correct juicer variant (CEJ for multi-chunk chat ingestion).
2) Run CEJ-1..CEJ-9 in order.
3) Write artifacts to disk (reports + json).
4) Produce continuation capsule every run.
5) Update registries (survivors, failures) when new items are found.
6) Export OS only after artifacts are captured.

Anti-patterns:
- Skipping passes
- Summarizing instead of inventorying
- Treating “worked once” as noise
- Mixing current-chat prompts into historical analysis (temporal contamination)
