# Pointer: `versions/`

Purpose:
- Canonical registry of OS builds and their status (canonical vs invalid).
- Used for upgrade planning, forensic diffing, and release notes.

Authoritative references:
- `README.md` (versioning model)
- `manifests/MANIFEST_SYSTEM_INDEX.json` (required presence of versions/)

Next step:
- Read `VERSION_HISTORY.md` then the latest `v*.json` entry.
