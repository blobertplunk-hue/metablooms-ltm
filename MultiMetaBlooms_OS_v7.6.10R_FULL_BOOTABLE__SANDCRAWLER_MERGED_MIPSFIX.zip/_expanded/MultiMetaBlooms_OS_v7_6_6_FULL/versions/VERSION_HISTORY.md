# MetaBlooms OS — Version History

This registry records canonical OS builds and notable properties.

Definitions:
- **Canonical build**: a full filesystem snapshot that passes export validation.
- **Invalid build**: a build that regressed invariants (kept for forensics, not a base).

## v7.5.0
- Canonical base snapshot.

## v7.5.1
- INVALID (governance regression / partial snapshot behaviors were detected during development).

## v7.5.2
- Canonical: tri-layer manifests introduced; validator hardened (no-removal vs previous snapshot).

## v7.5.3
- Canonical: README completeness gate introduced (machine-checked coverage section).

## v7.5.4
- Canonical: signage reference added (non-authoritative; optional).

## v7.5.5
- Canonical: Wayfinding cut — START_HERE + POINTER.md + validator pointer integrity gate.
Generated UTC: 2025-12-31_155757Z

## v7.5.7
- Canonical: runtime visibility cut — adds minimal runtime harness and demo-seeded ledgers.
Generated UTC: 2025-12-31_161917Z

## v7.6.5 — Relive: original-context capture + replay delta

- Added **Relive v1**: replay plus context snapshot and delta logging (no scores; raw observables only).
- Added minimal environment snapshot helper for replay contexts.
- Added `original_context` schema + example.
- Added `ledgers/relive.ndjson`.
