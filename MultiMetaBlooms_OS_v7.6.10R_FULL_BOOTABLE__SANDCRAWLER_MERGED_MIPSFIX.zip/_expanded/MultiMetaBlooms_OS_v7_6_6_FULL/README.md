# MetaBlooms OS — Canonical Build v7.6.4 (Fail-Closed)
Generated UTC: 2025-12-31_152315Z

This README is **first-class and authoritative**. If a subsystem exists in the OS but is not indexed here, the build is non-compliant.

## Tri-layer index
This OS is controlled by three mutually-checking indices:
1) **README.md** (this file) — system map + invariants
2) **System index manifest** — `manifests/MANIFEST_SYSTEM_INDEX.json`
3) **Component manifests** — `manifests/MANIFEST_KERNEL.json`, `manifests/MANIFEST_MODULES.json`

Export validation MUST ensure these three agree (no silent deletion, no partial snapshots).

## Canonical directory layout (top-level)
This build is a strict superset of the previous canonical snapshot. The original canonical directories remain present:
- `baselines/`
- `ble/`
- `control_plane/`
- `docs/`
- `egg_juicer/`
- `export_gate/`
- `governance/`
- `integrations/`
- `learning/`
- `ledgers/`
- `memory/`
- `metablooms/`
- `metablooms_governance/`
- `microblooms/`
- `sops/`
- `specs/`
- `tools/`

Additions introduced in v7.5.2:
- `kernel/` — lightweight control-plane wiring for HTDL + router feedback
- `modules/` — pilot/promotion + replay engines
- `manifests/` — tri-layer index manifests

## Governance invariants (must never regress)
The following governance artifacts are required by the system index manifest:
- `governance/MB_PREFLIGHT_REALITY_ENGINE_PRE-1.0.md`
- `governance/MB_SYSTEM_LEVEL_GRABBER_SLG-1.0.md`
- `governance/MB_EXPECTED_FAILURES_LAYER_EFL-1.0.md`
- `governance/MB_MEMORY_PROMOTION_CONTRACT_MPC-1.0.md`
- `export_gate/EXPORT_GATE_MINIMUMS.json`
- `governance/kic/KIC_SCHEMA.json`

If any are missing, export validation must fail closed.

## How the new engines interact
### HTDL
- Location: `kernel/telemetry/htdl/` (new wiring) and existing ledgers in `ledgers/`
- Role: records heuristic intent vs verified reality vs divergence; trace metadata supports correlation.

### Pilot → Promotion (beta-to-enable mechanism)
- Location: `modules/pilot_promotion/`
- Pilot runs fail-closed and produces `pilot_report.json` + ledger entries.
- Promotion refuses unless pilot passed and a manifest explicitly declares writes.

### Replay v1 (retroactive replay)
- Location: `modules/replay/decision_replay_engine/`
- Converts old chat exports into **candidate decisions** + HTDL seed records.
- Replay output is fed into Pilot/Promotion for safe activation.

### Router feedback loop (closed-loop risk hints)
- Location: `kernel/router/router_feedback_loop.py`
- Produces `kernel/router/domain_risk.json` as a derived view from HTDL + pilot ledgers.
- Router policy may require Sandcrawler/PRE more often for domains with rising risk.

## Validator and export rules
- Validator: `kernel/gates/validate_metablooms_export.py`
- Enforces:
  - tri-layer index presence
  - governance artifact presence
  - no removals vs previous canonical snapshot


## README coverage index (completeness gate)
This section is **machine-checked** by the export validator.

### Indexed top-level directories
The README must list every top-level directory present in the OS root:
- `baselines/`
- `ble/`
- `control_plane/`
- `docs/`
- `egg_juicer/`
- `export_gate/`
- `governance/`
- `integrations/`
- `kernel/`
- `learning/`
- `ledgers/`
- `manifests/`
- `memory/`
- `metablooms/`
- `metablooms_governance/`
- `microblooms/`
- `modules/`
- `sops/`
- `specs/`
- `tools/`

### Indexed required governance artifacts
The README must list every required governance artifact (see also `manifests/MANIFEST_SYSTEM_INDEX.json`):
- `governance/MB_PREFLIGHT_REALITY_ENGINE_PRE-1.0.md`
- `governance/MB_SYSTEM_LEVEL_GRABBER_SLG-1.0.md`
- `governance/MB_EXPECTED_FAILURES_LAYER_EFL-1.0.md`
- `governance/MB_MEMORY_PROMOTION_CONTRACT_MPC-1.0.md`
- `export_gate/EXPORT_GATE_MINIMUMS.json`
- `governance/kic/KIC_SCHEMA.json`


## Visual signage
- See `docs/tri_layer_index_signage.png` for a visual metaphor of the tri-layer index (README ↔ MANIFEST ↔ INDEX).


## Wayfinding
- Entry point: `START_HERE.md`
- Each top-level directory must contain `POINTER.md` (validator-enforced).
- `versions/` records canonical and invalid builds.


### Required wayfinding artifacts
- `START_HERE.md`
- `*/POINTER.md` for every top-level directory


## Runtime
- Minimal runtime harness: `kernel/runtime/run_demo.py` (writes real traces into `ledgers/`).
- Note: ledgers may be empty until the OS is executed; v7.5.7 includes a demo-seeded run for visibility.


## Agent Runtime (v7.6.0)
- `kernel/runtime/agent_loop.py` implements the LLM ↔ Python execution loop.
- LLM provides plans and judgments; Python executes tools and records ledgers.
- Sandcrawler is treated as an external governed tool with recorded artifacts.


## Time Sync Sentinel
- `kernel/runtime/time_sentinel.py` enforces periodic time checks.
- Policy: `config/TIME_SOURCE_POLICY_v1.json` (tolerance + recheck cadence).
- Writes `ledgers/time.ndjson` and emits HTDL divergence events on drift.


## Chat Time
- `kernel/runtime/chat_time_gate.py` logs authoritative times per chat turn.
- Host provides platform local time (America/Chicago) and tool UTC; gate records `ledgers/chat_time.ndjson`.
- Drift > tolerance emits HTDL event.

## Runtime telemetry (HTE) — Phase 0 Raw Observables (v0)

This build wires **raw-only** telemetry into the minimal runtime:

- Ledger: `ledgers/hte_raw.ndjson`
- Logger: `kernel/telemetry/hte_phase0.py`
- Runtime wiring:
  - `kernel/runtime/agent_loop.py` emits `eligibility_assessed`, `gate_triggered`, `note`
  - `kernel/runtime/tool_registry.py` emits tool lifecycle events (`requested/started/completed/failed`)
  - `kernel/runtime/run_demo.py` proves ledgers fill (no more empty telemetry ledgers)

**Phase 0 contract:** no scores, no synthesis, no derived metrics. Derived metrics are computed in Phase 1+ analysis tooling.

Quick smoke (optional, in environments that can run python):
- `python kernel/runtime/run_demo.py`
Then inspect:
- `ledgers/hte_raw.ndjson`
- `ledgers/agent.ndjson`
- `ledgers/activation.ndjson`

---

## Replay and Relive

MetaBlooms supports two replay modes:

- **Decision Replay (v1)**: deterministic re-execution of a task contract to reproduce *the same* decisions where possible.
- **Relive (v1)**: replay plus **original-context capture** and **delta logging** between "then" and "now".

### Files

- `modules/replay/decision_replay_engine/replay_v1.py`
- `modules/replay/decision_replay_engine/relive_v1.py`
- `kernel/runtime/env_snapshot.py` (raw environment snapshot helper)

### How Relive works (high level)

1. Load an `original_context.json` that declares:
   - the task contract to replay
   - expected artifact hashes from the original run
2. Capture a fresh environment snapshot (raw facts).
3. Run the task through the governed `kernel/runtime/agent_loop.py`.
4. Hash the same artifacts, compute match/mismatch, and append events to `ledgers/relive.ndjson`.

**Important:** Relive logs raw deltas; higher-level analysis is done later by separate modules (do not mix concerns).
