# POINTER — config

This directory is part of the MetaBlooms OS.
