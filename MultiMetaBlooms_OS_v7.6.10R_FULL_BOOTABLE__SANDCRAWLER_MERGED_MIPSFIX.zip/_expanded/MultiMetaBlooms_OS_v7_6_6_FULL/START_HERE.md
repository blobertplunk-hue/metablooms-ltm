# START HERE

If you are trying to understand MetaBlooms, do not explore randomly.

Follow this order:

1. `README.md` — complete system map and invariants (and coverage gate)
2. `manifests/MANIFEST_SYSTEM_INDEX.json` — authoritative inventory + required artifacts
3. `kernel/gates/validate_metablooms_export.py` — enforcement (what must be true)
4. `versions/` — version history, feature deltas, and invalid build notes

If any of the above are missing, the system is invalid.
