#!/usr/bin/env python3
"""
ChatTimeGate — v1.0 (MetaBlooms)

Goal:
- Produce accurate, user-aligned time stamps for chat turns.
- Record each chat turn time event to an append-only ledger.

Key design constraint:
- In a standalone ZIP runtime, Python cannot call platform clocks (user_info / web.time).
- Therefore ChatTimeGate uses a HOST-ADAPTER contract:
    Host passes authoritative values (tool UTC + platform local display).
    Gate validates consistency and logs in ledgers/chat_time.ndjson.

Required host inputs per turn:
- chat_turn_id (string or integer)
- host_platform_local_iso (e.g., 2025-12-31T10:43:04-06:00) OR local date+time fields
- host_tool_utc_iso (e.g., 2025-12-31T16:43:06Z)
- host_tool_local_iso (UTC converted to America/Chicago; optional but recommended)

Policy:
- config/TIME_SOURCE_POLICY_v1.json controls tolerance and timezone.
"""
from __future__ import annotations
from pathlib import Path
import json, datetime

def append_ndjson(path: Path, obj: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def parse_iso(s: str) -> datetime.datetime | None:
    try:
        # supports 'Z'
        if s.endswith("Z"):
            s = s.replace("Z","+00:00")
        return datetime.datetime.fromisoformat(s)
    except Exception:
        return None

def load_policy(os_root: Path) -> dict:
    p = os_root/"config"/"TIME_SOURCE_POLICY_v1.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"tolerance_seconds":5,"display_timezone":"America/Chicago"}

def log_chat_time(os_root: Path, chat_turn_id, host_platform_local_iso: str | None,
                  host_tool_utc_iso: str | None, host_tool_local_iso: str | None):
    policy = load_policy(os_root)
    tol = float(policy.get("tolerance_seconds", 5))
    ledgers = os_root/"ledgers"

    dt_platform = parse_iso(host_platform_local_iso) if host_platform_local_iso else None
    dt_tool_utc = parse_iso(host_tool_utc_iso) if host_tool_utc_iso else None
    dt_tool_local = parse_iso(host_tool_local_iso) if host_tool_local_iso else None

    drift_seconds = None
    if dt_platform and dt_tool_local:
        drift_seconds = abs((dt_platform - dt_tool_local).total_seconds())

    append_ndjson(ledgers/"chat_time.ndjson", {
        "event":"chat_time",
        "chat_turn_id": str(chat_turn_id),
        "platform_local_iso": host_platform_local_iso,
        "tool_utc_iso": host_tool_utc_iso,
        "tool_local_iso": host_tool_local_iso,
        "drift_seconds": drift_seconds,
        "tolerance_seconds": tol,
        "result": "OK" if (drift_seconds is None or drift_seconds <= tol) else "DRIFT"
    })

    if drift_seconds is not None and drift_seconds > tol:
        append_ndjson(ledgers/"htdl.ndjson", {
            "event":"htdl_record",
            "span_id":"chat_time_gate",
            "chat_turn_id": str(chat_turn_id),
            "heuristic_claim":"platform local and tool-derived local align",
            "reality_check":"time drift detected",
            "divergence":"chat_time_drift",
            "severity":"warn",
            "metrics":{"drift_seconds": drift_seconds, "tolerance_seconds": tol}
        })
