#!/usr/bin/env python3
"""
TimeSyncSentinel — v1.0 (MetaBlooms)

Problem solved:
- "Time drift / inconsistent timestamps" caused by relying on stale or ambiguous clocks.
- The system must periodically re-assert authoritative time source and log divergence.

Constraints:
- In-chat platform tools (user_info/web.time) cannot be called from inside a standalone zip runtime.
- Therefore, TimeSyncSentinel uses an ADAPTER model:
    - If running inside ChatGPT sandbox: a host adapter can inject authoritative UTC and local time.
    - If running offline: fall back to system clock and log reduced-trust mode.

Contract:
- Emits NDJSON events to ledgers/time.ndjson
- If divergence exceeds tolerance, emits HTDL divergence event (via ledgers/htdl.ndjson)
"""
from __future__ import annotations
from pathlib import Path
import json, time

DEFAULT_POLICY = {
  "primary": "utc_system",
  "display_timezone": "America/Chicago",
  "tolerance_seconds": 5,
  "recheck_every_steps": 5
}

def append_ndjson(path: Path, obj: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def get_system_utc_epoch() -> float:
    return time.time()

def check_time(os_root: Path, policy: dict, run_id: str, step_index: int,
               host_utc_epoch: float | None = None,
               host_local_iso: str | None = None,
               host_utc_iso: str | None = None):
    ledgers = os_root / "ledgers"
    now_epoch = get_system_utc_epoch()
    utc_epoch = host_utc_epoch if host_utc_epoch is not None else now_epoch
    trust = "host" if host_utc_epoch is not None else "system"

    event = {
      "event":"time_check",
      "run_id": run_id,
      "step_index": step_index,
      "ts_epoch_utc": utc_epoch,
      "trust": trust,
      "host_local_iso": host_local_iso,
      "host_utc_iso": host_utc_iso,
      "policy": {
        "tolerance_seconds": policy.get("tolerance_seconds", 5),
        "primary": policy.get("primary","utc_system")
      }
    }
    append_ndjson(ledgers/"time.ndjson", event)

    # Divergence detection: compare host vs system if both available
    if host_utc_epoch is not None:
        drift = abs(host_utc_epoch - now_epoch)
        if drift > policy.get("tolerance_seconds", 5):
            append_ndjson(ledgers/"htdl.ndjson", {
              "event":"htdl_record",
              "run_id": run_id,
              "span_id": "time_sentinel",
              "ts_epoch_utc": host_utc_epoch,
              "heuristic_claim":"system clock acceptable",
              "reality_check":"host time indicates drift",
              "divergence":"time_drift",
              "severity":"warn",
              "metrics":{"drift_seconds": drift}
            })
