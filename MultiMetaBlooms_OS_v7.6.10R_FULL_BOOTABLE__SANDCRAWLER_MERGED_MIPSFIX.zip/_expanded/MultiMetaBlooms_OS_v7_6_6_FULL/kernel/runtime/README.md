# Minimal Runtime Harness

Run `python kernel/runtime/run_demo.py` to generate a real execution trace in `ledgers/`.
