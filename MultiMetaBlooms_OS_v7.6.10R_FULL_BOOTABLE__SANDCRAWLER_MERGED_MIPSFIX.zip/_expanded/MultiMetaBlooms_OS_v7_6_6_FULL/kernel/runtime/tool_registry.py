#!/usr/bin/env python3
"""Tool Registry — v1.1 (wired to HTE Phase 0 raw telemetry)

This registry is deliberately small:
- It describes tool *provenance* (local vs external_recorded)
- It provides a single `call_tool()` wrapper that emits Phase 0 events

NOTE:
- External tools (e.g., Sandcrawler/web) are not executed in this minimal runtime.
  They are logged as requested/completed/failed depending on environment.
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Optional
import json, time

from kernel.telemetry.hte_phase0 import emit
from kernel.runtime.common import append_ndjson, utc_now_iso

TOOLS = {
  "filesystem": "local",
  "validator": "kernel/gates",
  "sandcrawler": "external_recorded",
  "pilot": "modules/pilot_promotion"
}

def call_tool(
    os_root: Path,
    *,
    run_id: str,
    chat_turn_id: Optional[str],
    span_id: Optional[str],
    tool_name: str,
    provider: str,
    args: Dict[str, Any],
    request_id: Optional[str] = None,
    allow_external: bool = False
) -> Dict[str, Any]:
    """Call or record a tool invocation; always emits Phase 0 raw events."""
    # requested
    ev_req = {
        "run_id": run_id,
        "chat_turn_id": chat_turn_id,
        "span_id": span_id,
        "parent_event_id": None,
        "event_type": "tool_call_requested",
        "actor": "assistant",
        "tool": {
            "name": tool_name,
            "provider": provider,
            "args_hash": None,
            "result_hash": None,
            "status": "requested"
        },
        "eligibility": None,
        "gate": None,
        "draft": None,
        "temporal_refs": None,
        "compliance": None,
        "note": None
    }
    if request_id:
        ev_req["compliance"] = {"request_id": request_id, "requested_action": f"call:{tool_name}", "fulfilled": False, "fulfillment_event_id": None}
    emit(os_root, ev_req)

    # started
    ev_start = dict(ev_req)
    ev_start["event_type"] = "tool_call_started"
    ev_start["tool"] = dict(ev_req["tool"])
    ev_start["tool"]["status"] = "started"
    emit(os_root, ev_start)

    # execute (local only in this minimal runtime)
    result: Dict[str, Any] = {"ok": False, "tool": tool_name, "provider": provider, "data": None}
    status = "failed"
    note = None

    if provider == "local" and tool_name == "filesystem.noop":
        result = {"ok": True, "tool": tool_name, "provider": provider, "data": {"noop": True}}
        status = "completed"
    elif provider in ("web","external","mcp"):
        if allow_external:
            # Placeholder hook: real execution belongs in integrations layer.
            result = {"ok": False, "tool": tool_name, "provider": provider, "data": None}
            status = "failed"
            note = "External tool execution not wired in minimal runtime."
        else:
            result = {"ok": False, "tool": tool_name, "provider": provider, "data": None}
            status = "failed"
            note = "External tool call blocked (allow_external=false)."
    else:
        note = "Unknown tool/provider."

    # completed/failed
    ev_done = {
        "run_id": run_id,
        "chat_turn_id": chat_turn_id,
        "span_id": span_id,
        "parent_event_id": None,
        "event_type": "tool_call_completed" if status == "completed" else "tool_call_failed",
        "actor": "assistant",
        "tool": {
            "name": tool_name,
            "provider": provider,
            "args_hash": None,
            "result_hash": None,
            "status": status
        },
        "eligibility": None,
        "gate": None,
        "draft": None,
        "temporal_refs": None,
        "compliance": None,
        "note": note
    }
    if request_id:
        ev_done["compliance"] = {"request_id": request_id, "requested_action": f"call:{tool_name}", "fulfilled": (status=="completed"), "fulfillment_event_id": None}
    emit(os_root, ev_done)

    return result
