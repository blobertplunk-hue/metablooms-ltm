#!/usr/bin/env python3
"""MetaBlooms Minimal Runtime Harness — v0.2 (Demo, telemetry-wired)

Goal:
- Provide a concrete "it runs" pathway without external deps.
- Populate ledgers with a real execution trace (NDJSON) including:
  - agent.ndjson
  - activation.ndjson (demo)
  - hte_raw.ndjson (Phase 0 raw observables)

This proves: the runtime produces filled ledgers (no more empty files).
"""

from __future__ import annotations
from pathlib import Path
import json, uuid, time

from kernel.runtime.common import append_ndjson, utc_now_iso
from kernel.runtime.agent_loop import run as run_agent

def main():
    os_root = Path(__file__).resolve().parents[2]  # .../kernel/runtime -> OS root
    ledgers = os_root/"ledgers"
    run_id = f"demo-{uuid.uuid4().hex[:10]}"
    t0 = time.time()

    append_ndjson(ledgers/"activation.ndjson", {"event":"activation_start","run_id":run_id,"ts_utc_iso":utc_now_iso()})

    task = {
        "run_id": run_id,
        "objective": "Demo: show Phase0 raw observables logging",
        "steps": [
            {"type":"note","note":"Start demo; eligibility+gate events will be emitted."},
            {"type":"tool_call","tool_name":"Sandcrawler.search_query","provider":"web","args":{"q":"llm confidence calibration"}, "needs_citations": True, "needs_web": True, "request_id":"req-demo-sandcrawler"},
            {"type":"tool_call","tool_name":"filesystem.noop","provider":"local","args":{}},
            {"type":"note","note":"End demo."}
        ]
    }

    _ = run_agent(os_root, task, chat_turn_id="demo-turn")

    append_ndjson(ledgers/"activation.ndjson", {
        "event":"activation_complete",
        "run_id":run_id,
        "ts_utc_iso":utc_now_iso(),
        "duration_s": round(time.time()-t0, 3),
        "result":"OK"
    })

    print("DEMO_RUN_OK", run_id)

if __name__ == "__main__":
    main()
