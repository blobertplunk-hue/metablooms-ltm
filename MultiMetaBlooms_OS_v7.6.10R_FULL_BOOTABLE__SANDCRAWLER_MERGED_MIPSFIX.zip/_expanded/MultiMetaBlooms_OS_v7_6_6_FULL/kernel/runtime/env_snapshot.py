import json,os,platform,sys
from datetime import datetime,timezone

def snapshot():
  return {"ts_utc":datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),"py":sys.version.split()[0],"platform":platform.platform(),"assistant_model":os.getenv('MB_ASSISTANT_MODEL')}

def write(out_path):
  with open(out_path,'w',encoding='utf-8') as f: json.dump(snapshot(),f)
