# Pointer: `specs/`

Purpose:
- This directory is part of the MetaBlooms OS filesystem.

Authoritative references:
- `README.md` (system map, invariants, interactions)
- `manifests/MANIFEST_SYSTEM_INDEX.json` (inventory + required artifacts)
- `manifests/MANIFEST_KERNEL.json` / `manifests/MANIFEST_MODULES.json` (component file lists)

Next step:
- If you are unsure what to do here, return to `START_HERE.md`.
