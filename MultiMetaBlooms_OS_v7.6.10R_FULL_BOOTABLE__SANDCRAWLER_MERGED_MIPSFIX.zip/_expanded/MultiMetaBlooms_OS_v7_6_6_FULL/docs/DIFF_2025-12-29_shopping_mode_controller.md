# DIFF — 2025-12-29 Shopping Mode Controller Addition

## Added
- `docs/SOP_Shopping_Mode_Controller_Sandcrawler_v1.md`
- `control_plane/SHOPPING_MODE_CONTROLLER_RULES_v1.json`
- `control_plane/SHOPPING_MODE_CONTROLLER_TESTS_v1.json`

## Rationale
Adds explicit, testable mode-switching logic for shopping workflows:
FIND ↔ EVALUATE ↔ FINE_TUNE with automatic backtracking when constraints change or a shortlist collapses.

## Constraints
- No changes made to locked control_plane manifests (status: locked).
- Append-only additions consistent with MetaBlooms governance.

