# SOP: Close the Research Loop (MetaBlooms)

## Trigger
Use when a FIND/EVALUATE sweep produces a conclusion that should improve MetaBlooms.

## Inputs (authoritative)
- Evidence artifact(s) from the sweep (markdown/json)
- DeltaPack schema: `metablooms/deltas/deltapack_v1_schema.json`

## Procedure
1. **Extract the takeaway** as a falsifiable statement.
2. **Create a DeltaPack** that encodes:
   - what changes (operations)
   - why (notes)
   - how to verify (activation_requirements)
3. **Apply the change** to the OS filesystem.
4. **Boot** to generate observability outputs.
5. **Verify**:
   - `HEALTH.json` is valid
   - `STATUS.md` includes the new `last_delta`
   - `WHAT_CHANGED_TODAY.md` lists the DeltaPack (ledger-first; fallback scan allowed if ledgers absent)
6. **Export** only if ExportGate passes.

## Outputs
- DeltaPack JSON in `metablooms/deltas/`
- Updated observability files generated on boot
- Export receipts including observability validation hashes

## Fail Conditions
- No evidence artifact: still allowed, but DeltaPack must mark links as `unknown` and the system should show DEGRADED in STATUS.md.
- Observability generation/validation fails: do not proceed; boot/export must fail closed.
