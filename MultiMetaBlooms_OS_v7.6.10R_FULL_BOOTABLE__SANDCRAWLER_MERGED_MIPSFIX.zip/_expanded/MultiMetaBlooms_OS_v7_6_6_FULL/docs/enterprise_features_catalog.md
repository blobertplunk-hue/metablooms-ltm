# Enterprise Features Catalog — Steal Later vs Now
Generated (UTC): 2025-12-31_150234Z

This is the authoritative place in MetaBlooms to park “enterprise features worth stealing later.”

## Implement Now (MetaBlooms scale)
- HTDL trace metadata (v1.1) for correlation citeturn0search5turn0search13
- Pilot + Promotion quality gates (fail-closed) citeturn0search3turn0search7
- Retroactive Replay (RRE v1) to convert old chats into candidates

## Steal Later (when scaling beyond one operator)
- Feature flag / canary rollout management citeturn0search0turn0search12turn0search16
- OTel-based distributed tracing exports citeturn0search1turn0search9turn0search21
- Centralized LLM gateway (auth, PII, routing) (defer until multi-tenant)
- RBAC / team workflows (defer until multi-operator)

## Retroactive Replay (Teaching Engine relevance)
Replay is immediately valuable for rebuilding lost state. In MetaBlooms, Replay should remain fail-closed:
- extract candidates
- verify volatile claims via Sandcrawler
- pilot in sandbox
- only then promote into OS ledgers/modules
