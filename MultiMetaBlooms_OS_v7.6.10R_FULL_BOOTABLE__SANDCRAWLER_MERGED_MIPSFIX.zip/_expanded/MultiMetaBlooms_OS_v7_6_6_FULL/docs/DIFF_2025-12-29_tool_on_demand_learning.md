# DIFF — 2025-12-29 — Tool-on-Demand Learning (LID-2.0)

## Why
A visual-shape task (4-leaf clover mask) demonstrated that repeated subjective iteration does not converge without
ground truth + instrumentation. Creating small tools (rasterizer, mask builder) moved the system from guessing to tuning.

## Added
- governance/LEARNING_TOOL_ON_DEMAND_LID-2.0.md
- sops/ToolOnDemand/SOP-03_ToolSmithing.md
- ble/BLE_EXTENSION_TOOL_ON_DEMAND_v1.(json|md)
- tools/toolsmith.py

## No changes
- Locked manifests remain untouched (control_plane manifests are status=locked).

