# MetaBlooms — Boot Activator (No Dormant Capability)
# Single authoritative place to activate every shipped capability.
# Fail-closed: required subsystems must register ACTIVE during boot.
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any, List

from control_plane.activation_registry import ActivationRegistry
from control_plane.shopping_mode_controller import activate as activate_smc

_ROOT = Path(__file__).resolve().parent.parent
_CP = Path(__file__).resolve().parent

REQUIRED: List[str] = [
    "CONTROL_PLANE_CORE",
    "BRIDGE_MAP",
    "HEURISTIC_MATRIX",
    "CHM",
    "SHOPPING_MODE_CONTROLLER",
    "EGG_JUICER",
    "BLE",
    "GOVERNANCE_CORE",
    "DECISION_SPINE",
    "SANDFIT_V0",
]

def _load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def _activate_presence(registry: ActivationRegistry, name: str, path: Path, kind: str) -> None:
    try:
        if not path.exists():
            registry.set_error(name, "MISSING_REQUIRED_FILE", path=str(path), kind=kind)
            return
        if path.suffix.lower() == ".json":
            data = _load_json(path)
            status = data.get("status") or data.get("learning") or "present"
            registry.set_active(name, file=str(path), status=status, kind=kind)
        else:
            registry.set_active(name, file=str(path), status="present", kind=kind)
    except Exception as e:
        registry.set_error(name, "FILE_CHECK_FAILED", path=str(path), kind=kind, exc=str(e))

def activate_all(registry: ActivationRegistry) -> Dict[str, Any]:
    # Control plane core
    _activate_presence(registry, "CONTROL_PLANE_CORE", _CP / "BOOT_STATE.json", kind="control_plane")

    # CHM / Heuristic Matrix / BridgeMap (first-class governance)
    chm_contract = _CP / "chm_contract.json"
    hm = _CP / "heuristic_matrix.json"
    hm_delta = _CP / "heuristic_matrix_v1_1_delta.json"
    bm = _CP / "bridge_map.json"

    # Presence checks (fail-closed via registry errors)
    _activate_presence(registry, "CHM", chm_contract, kind="control_plane")
    _activate_presence(registry, "HEURISTIC_MATRIX", hm, kind="control_plane")
    # delta is supplemental but must exist if shipped
    if hm_delta.exists():
        _activate_presence(registry, "HEURISTIC_MATRIX", hm_delta, kind="control_plane")
    _activate_presence(registry, "BRIDGE_MAP", bm, kind="control_plane")

    # Emit initial CHM health record at boot (proves activation vs presence)
    try:
        from control_plane.chm_activation import activate as _chm_activate
        _chm_activate()
        registry.set_active("CHM", status="active", kind="control_plane", note="CHM activation record emitted")
    except Exception as e:
        registry.set_error("CHM", "ACTIVATION_FAILED", error=str(e))

    # Shopping Mode Controller (rules + tests + behavior)
    smc_report = activate_smc(registry)
    registry.set_active("SHOPPING_MODE_CONTROLLER", status="active", kind="control_plane", **smc_report)

    # EggJuicer: active if directory exists and has an anchor file
    egg_dir = _ROOT / "egg_juicer"
    if not egg_dir.is_dir():
        registry.set_error("EGG_JUICER", "MISSING_DIRECTORY", path=str(egg_dir))
    else:
        anchors = [egg_dir / "EggJuicer.md", egg_dir / "README.md"]
        anchor = next((p for p in anchors if p.exists()), None)
        if anchor is None:
            registry.set_error("EGG_JUICER", "NO_ANCHOR_FILE_FOUND", path=str(egg_dir))
        else:
            _activate_presence(registry, "EGG_JUICER", anchor, kind="egg_juicer")

    # BLE: anchor
    ble_dir = _ROOT / "ble"
    ble_anchor = ble_dir / "BLE_RULESET.md"
    if not ble_anchor.exists():
        ble_anchor = _CP / "MB_REASONING_ENGINE_INTERFACE_SPEC_v1.json"
    _activate_presence(registry, "BLE", ble_anchor, kind="ble")

    # Governance core: anchor
    gov_dir = _ROOT / "governance"
    mg_dir = _ROOT / "metablooms_governance"
    gov_anchor = gov_dir / "GOVERNANCE.md"
    if not gov_anchor.exists():
        alt = mg_dir / "README.md"
        gov_anchor = alt if alt.exists() else (_CP / "MB_GATE_REGISTRY_MANIFEST_v1.json")
    _activate_presence(registry, "GOVERNANCE_CORE", gov_anchor, kind="governance")

    # Decision Spine (control-plane reference, non-executing)
    ds = _CP / "decision_spine" / "DECISION_SPINE.md"
    _activate_presence(registry, "DECISION_SPINE", ds, kind="control_plane")

    # SandFit v0 (microbloom capability, subordinate)
    sf = _ROOT / "microblooms" / "sandfit_v0" / "src" / "sandfit_engine.py"
    _activate_presence(registry, "SANDFIT_V0", sf, kind="microbloom")

    return {"required": REQUIRED}

def required_list() -> List[str]:
    return list(REQUIRED)

REQUIRED_SUBSYSTEMS = ['CHM','HEURISTIC_MATRIX','BRIDGE_MAP']
