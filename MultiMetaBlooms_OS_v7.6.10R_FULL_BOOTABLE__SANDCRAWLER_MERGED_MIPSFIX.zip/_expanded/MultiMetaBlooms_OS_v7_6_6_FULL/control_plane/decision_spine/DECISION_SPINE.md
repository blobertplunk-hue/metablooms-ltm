# MetaBlooms Decision Spine — Canonical Doctrine

## Mandatory Flow
1. SandCrawler — discovery/enumeration
2. SandFit — constraint & reality adjudication
3. HDL — heuristic vs governance delta logging
4. HOLD / FOLD / WALK / RUN — outcome classification

## SandFit
- Internal engine name
- Fail-closed on hard constraints
- Rejection is a valid output
- Applies to goods, services, labor, planning, and personal decisions

## Heuristic Differential Ledger (HDL)
- Append-only
- Logs heuristic impulse vs MetaBlooms action
- Required on any override or block

## Governance Corrections
- Low-risk exploratory allowance
- Post-correctness terseness
- Scope freeze + single clarification

## Meta-Law
A system is correct not when it is right, but when it stops being wrong for the same reason twice.