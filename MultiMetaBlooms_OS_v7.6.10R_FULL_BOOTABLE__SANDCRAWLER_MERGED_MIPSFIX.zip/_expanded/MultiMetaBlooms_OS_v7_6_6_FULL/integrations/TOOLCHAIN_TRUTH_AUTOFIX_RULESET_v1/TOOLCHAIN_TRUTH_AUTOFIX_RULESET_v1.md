# TOOLCHAIN_TRUTH_AUTOFIX_RULESET_v1

Version: 1.0.0  
Status: canonical_draft

## Purpose
Map deterministic toolchain/runtime errors to mechanical autofixes with mandatory verification + rollback.

## Scope
- Applies only to **Toolchain Truth** failures: parser/runtime errors with deterministic meaning.
- Does **not** apply to semantic reasoning, strategy, or style.

## Required behavior
1) Match error signature (stderr regex) in a declared environment.
2) Apply a whitelisted fix kind.
3) Verify immediately (compile/parse/rerun).
4) If verify fails: rollback and downgrade to supervised lane.
5) If verify passes: record an Immediate Learning event and (if INVALID_CONSTRUCT) update ECM.

## Environments covered (v1)
- termux:bash
- powershell:pwsh
- python:cpython
- generic:zip_build

See JSON for full rule definitions.
