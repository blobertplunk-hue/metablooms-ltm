# ENVIRONMENT_COMPETENCE_MAP_v1

Environment-scoped procedural competence memory.
