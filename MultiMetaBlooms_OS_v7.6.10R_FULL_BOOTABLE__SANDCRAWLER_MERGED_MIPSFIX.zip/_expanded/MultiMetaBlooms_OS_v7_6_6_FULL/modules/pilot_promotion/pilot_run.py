#!/usr/bin/env python3
"""
Pilot Runner (MetaBlooms) v0.1 — fail-closed.

Inputs:
- --candidate: path to a candidate package folder OR zip OR single file
- --domain: domain label (e.g., github_ui, system_architecture)
- --evidence: optional path to an evidence pack (required for volatile domains by policy)
- --os: metablooms_os root
- --out: output folder

Outputs:
- pilot_report.json (pass/fail + checks)
- pilot_ledger.ndjson (append-only; can be promoted into OS)
- optional htdl_seed.ndjson (trace metadata + placeholders)

This runner does not "trust" heuristics: it expects evidence for volatile surfaces.
"""
from __future__ import annotations
import argparse, json, os, sys, time, uuid, zipfile, shutil
from pathlib import Path
from datetime import datetime
import fnmatch

def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))

def now():
    return datetime.utcnow().isoformat()+"Z"

def unzip_to(tmp: Path, zpath: Path):
    with zipfile.ZipFile(zpath, "r") as z:
        z.extractall(tmp)

def is_zip(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() == ".zip"

def collect_files(root: Path):
    for p in root.rglob("*"):
        if p.is_file():
            yield p

def basic_smoke(candidate_root: Path):
    """Very conservative smoke: ensure files exist and are readable; no execution."""
    checks = []
    file_count = 0
    total_bytes = 0
    for p in collect_files(candidate_root):
        file_count += 1
        total_bytes += p.stat().st_size
        try:
            _ = p.read_bytes()
        except Exception as e:
            checks.append({"check":"read_file", "path": str(p), "ok": False, "error": str(e)})
            return checks, file_count, total_bytes
    checks.append({"check":"read_all_files", "ok": True, "files": file_count, "bytes": total_bytes})
    return checks, file_count, total_bytes

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--domain", required=True)
    ap.add_argument("--evidence", required=False)
    ap.add_argument("--os", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    os_root = Path(args.os)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    policy = load_json(os_root / "modules" / "pilot_promotion" / "policies" / "pilot_policy.json")

    trace_id = str(uuid.uuid4())
    start = time.time()

    # Prepare candidate extraction dir
    cand = Path(args.candidate)
    work = out_dir / "_candidate"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True, exist_ok=True)

    if is_zip(cand):
        unzip_to(work, cand)
        candidate_root = work
    elif cand.is_dir():
        # copy to work to ensure immutability
        shutil.copytree(cand, work, dirs_exist_ok=True)
        candidate_root = work
    elif cand.is_file():
        # single file candidate
        shutil.copy2(cand, work / cand.name)
        candidate_root = work
    else:
        raise SystemExit("candidate path not found")

    checks = []
    failed = 0

    # Evidence requirement for volatile domains
    volatile = set(policy["required"]["must_have_evidence_for_domains"])
    if args.domain in volatile:
        if not args.evidence:
            checks.append({"check":"evidence_required", "ok": False, "reason":"missing --evidence for volatile domain"})
            failed += 1
        else:
            ev = Path(args.evidence)
            if not ev.exists():
                checks.append({"check":"evidence_required", "ok": False, "reason":"evidence path not found"})
                failed += 1
            else:
                checks.append({"check":"evidence_required", "ok": True, "evidence": str(ev)})
    else:
        checks.append({"check":"evidence_required", "ok": True, "reason":"domain not marked volatile"})

    # Smoke test
    if policy["required"]["must_run_smoke_tests"]:
        smoke_checks, file_count, total_bytes = basic_smoke(candidate_root)
        checks.extend(smoke_checks)
        # smoke failure recorded as any check with ok False
        for c in smoke_checks:
            if c.get("ok") is False:
                failed += 1

    end = time.time()
    latency_ms = int((end - start) * 1000)

    # Pilot outcome
    passed = (failed <= policy["thresholds"]["max_failed_checks"])

    report = {
        "pilot_version":"0.1",
        "trace_id": trace_id,
        "domain": args.domain,
        "start_ts": datetime.utcfromtimestamp(start).isoformat()+"Z",
        "end_ts": datetime.utcfromtimestamp(end).isoformat()+"Z",
        "latency_ms": latency_ms,
        "candidate": str(cand),
        "file_count": file_count,
        "total_bytes": total_bytes,
        "failed_checks": failed,
        "passed": passed,
        "checks": checks,
        "next_action": "eligible_for_promotion" if passed else "quarantine"
    }

    (out_dir / "pilot_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    # Append pilot ledger entry (candidate; promotion can move it)
    ledger_rec = {
        "event":"pilot_run",
        "timestamp": now(),
        "trace_id": trace_id,
        "domain": args.domain,
        "passed": passed,
        "failed_checks": failed,
        "candidate": str(cand),
        "notes": "Fail-closed pilot report"
    }
    (out_dir / "pilot_ledger.ndjson").write_text(json.dumps(ledger_rec)+"\n", encoding="utf-8")

    print(json.dumps({"passed": passed, "trace_id": trace_id, "report": str(out_dir / "pilot_report.json")}, indent=2))

if __name__ == "__main__":
    main()
