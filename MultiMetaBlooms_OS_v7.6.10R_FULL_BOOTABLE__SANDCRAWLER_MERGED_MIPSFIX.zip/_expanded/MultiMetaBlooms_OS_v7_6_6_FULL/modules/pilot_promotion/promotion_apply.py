#!/usr/bin/env python3
"""
Promotion Apply (MetaBlooms) v0.1 — fail-closed.

Inputs:
- --pilot_report: pilot_report.json from pilot_run
- --candidate_root: the same candidate root used in pilot (folder) OR a zip
- --os: metablooms_os root

Behavior:
- Refuses if pilot_report.passed != true
- Refuses if any destination is outside allow_paths
- Copies candidate files into OS destinations (guided by optional manifest in candidate)
- Appends pilot ledger into modules/pilot_promotion/pilot_ledger.ndjson

Candidate manifest (optional):
- promotion_manifest.json:
  { "writes":[ {"src":"relative/path","dst":"modules/..."} ] }

Fail-closed defaults:
- If no manifest: no writes (you must provide manifest).
"""
from __future__ import annotations
import argparse, json, zipfile, shutil
from pathlib import Path
from datetime import datetime
import fnmatch

def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))

def now():
    return datetime.utcnow().isoformat()+"Z"

def unzip_to(tmp: Path, zpath: Path):
    with zipfile.ZipFile(zpath, "r") as z:
        z.extractall(tmp)

def is_zip(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() == ".zip"

def allowed(dst: str, allow_paths):
    return any(dst.startswith(ap) for ap in allow_paths)

def denied(path: str, deny_globs):
    return any(fnmatch.fnmatch(path, g) for g in deny_globs)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pilot_report", required=True)
    ap.add_argument("--candidate_root", required=True)
    ap.add_argument("--os", required=True)
    args = ap.parse_args()

    os_root = Path(args.os)
    pol = load_json(os_root / "modules" / "pilot_promotion" / "policies" / "promotion_policy.json")
    report = load_json(Path(args.pilot_report))

    if not report.get("passed"):
        raise SystemExit("REFUSE: pilot report not passed")

    cand = Path(args.candidate_root)
    work = None
    if is_zip(cand):
        work = Path(args.pilot_report).parent / "_promo_candidate"
        if work.exists():
            shutil.rmtree(work)
        work.mkdir(parents=True, exist_ok=True)
        unzip_to(work, cand)
        candidate_root = work
    else:
        candidate_root = cand

    manifest_path = candidate_root / "promotion_manifest.json"
    if not manifest_path.exists():
        raise SystemExit("REFUSE: missing promotion_manifest.json (fail-closed)")

    manifest = load_json(manifest_path)
    writes = manifest.get("writes", [])
    if not writes:
        raise SystemExit("REFUSE: empty writes list")

    for w in writes:
        src = candidate_root / w["src"]
        dst = w["dst"]
        if not allowed(dst, pol["allow_paths"]):
            raise SystemExit(f"REFUSE: dst not allowed: {dst}")
        if denied(dst, pol["deny_globs"]):
            raise SystemExit(f"REFUSE: dst denied by glob: {dst}")
        dst_path = os_root / dst
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst_path, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst_path)

    # append pilot ledger
    ledger = os_root / "modules" / "pilot_promotion" / "pilot_ledger.ndjson"
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("a", encoding="utf-8") as f:
        f.write(json.dumps({
            "event":"promotion_applied",
            "timestamp": now(),
            "trace_id": report.get("trace_id"),
            "domain": report.get("domain"),
            "candidate": report.get("candidate"),
            "writes": writes
        }, ensure_ascii=False) + "\n")

    print("PROMOTED_OK")

if __name__ == "__main__":
    main()
