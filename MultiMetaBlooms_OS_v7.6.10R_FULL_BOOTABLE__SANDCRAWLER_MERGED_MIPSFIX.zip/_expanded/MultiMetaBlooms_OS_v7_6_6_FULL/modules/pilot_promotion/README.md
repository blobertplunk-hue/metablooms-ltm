# Pilot + Promotion Engine v0.1 (MetaBlooms)
Generated (UTC): 2025-12-31_150234Z

This module implements the mechanism you described:
- **Pilot**: run in a sandbox, collect evidence, compute pass/fail, write ledgers
- **Promotion**: only if the pilot passes, apply changes to the mounted OS (append-only)
- **Fail-closed**: if evidence is missing, tests fail, or policies are violated, promotion is refused

Design reference patterns:
- pipeline quality gates and fail-closed promotion citeturn0search3turn0search7
- feature flags/canary as safe rollout mechanics citeturn0search0turn0search12turn0search16
- trace IDs as baseline observability glue citeturn0search1turn0search5turn0search13

## Files
- `pilot_run.py` — executes pilot, emits `pilot_report.json` and ledgers
- `promotion_apply.py` — applies approved pilot artifacts into OS paths
- `policies/pilot_policy.json` — thresholds + required checks
- `policies/promotion_policy.json` — promotion constraints

## Key rule
**No pilot report → no promotion. No evidence pack for volatile domains → no promotion.**
