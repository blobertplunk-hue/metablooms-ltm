"""Relive v1 — replay a task, capture environment context, and compute deltas.

This is the "make it real" bridge:
- Read an original_context JSON (raw facts about the prior run)
- Re-run the same task through the governed agent loop
- Compare declared expected artifact hashes to current hashes
- Log raw observables to an append-only NDJSON ledger

No scores. No synthesis. Only raw events and deltas.
"""

from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def append_ndjson(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def load_json(p: Path) -> dict:
    return json.loads(p.read_text(encoding='utf-8'))


def main(os_root: Path, original_context_path: Path) -> str:
    sys.path.insert(0, str(os_root))

    from kernel.runtime import agent_loop
    from kernel.runtime.env_snapshot import write as write_env

    ctx = load_json(original_context_path)
    task = ctx.get('task')
    if not isinstance(task, dict):
        raise SystemExit('original_context.task missing or not an object')

    relive_run_id = agent_loop.run(os_root, task, chat_turn_id=ctx.get('chat_turn_id'))

    # Environment snapshot is captured *at relive time*.
    env_path = os_root / 'artifacts' / 'relive' / f'{relive_run_id}.env.json'
    write_env(str(env_path))

    ledger = os_root / 'ledgers' / 'relive.ndjson'
    append_ndjson(ledger, {
        'event_type': 'relive_started',
        'relive_run_id': relive_run_id,
        'original_context_path': str(original_context_path),
        'env_snapshot_path': str(env_path),
    })

    expected = ctx.get('expected_artifacts', [])
    if not isinstance(expected, list):
        expected = []

    for e in expected:
        if not isinstance(e, dict):
            continue
        rel = e.get('path')
        exp = e.get('sha256')
        if not rel or not exp:
            continue
        p = os_root / rel
        obs = {
            'event_type': 'artifact_compared',
            'relive_run_id': relive_run_id,
            'path': rel,
            'expected_sha256': exp,
            'exists': p.exists(),
        }
        if p.exists() and p.is_file():
            obs['observed_sha256'] = sha256_file(p)
            obs['match'] = (obs['observed_sha256'] == exp)
        else:
            obs['observed_sha256'] = None
            obs['match'] = False
        append_ndjson(ledger, obs)

    append_ndjson(ledger, {
        'event_type': 'relive_complete',
        'relive_run_id': relive_run_id,
    })

    return relive_run_id


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--os_root', required=True)
    ap.add_argument('--original_context', required=True)
    args = ap.parse_args()
    rid = main(Path(args.os_root), Path(args.original_context))
    print(rid)
