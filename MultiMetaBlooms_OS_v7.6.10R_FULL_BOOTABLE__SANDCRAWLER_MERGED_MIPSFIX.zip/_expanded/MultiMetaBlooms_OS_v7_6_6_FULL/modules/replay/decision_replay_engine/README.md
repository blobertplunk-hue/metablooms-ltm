# Decision Replay Engine v1 (MetaBlooms)
Generated (UTC): 2025-12-31_150234Z

This upgrades RRE v0 into v1 with:
- trace metadata (aligns with HTDL v1.1)
- conservative decision extraction
- decision typing (gate / policy / playbook / module)
- HTDL seed emission (heuristic_intent + divergence placeholders)
- promotion manifests (optional) to feed Pilot+Promotion Engine

Fail-closed: replay never auto-writes into OS without passing Pilot+Promotion.
