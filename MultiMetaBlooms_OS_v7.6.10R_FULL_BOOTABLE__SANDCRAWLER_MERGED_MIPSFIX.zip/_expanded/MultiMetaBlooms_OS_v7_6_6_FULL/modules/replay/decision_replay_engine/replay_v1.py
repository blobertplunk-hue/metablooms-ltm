#!/usr/bin/env python3
"""
Decision Replay Engine v1 (RRE) — emits:
- decisions.ndjson
- review.md
- htdl_seed.ndjson (v1.1 trace metadata)
- promotion_manifest.json (optional skeleton)

Input: Chat exports (JSON), or folder of JSONs
"""
from __future__ import annotations
import argparse, json, re, uuid
from pathlib import Path
from datetime import datetime

DECISION_PATTERNS = [
    r"\bMUST\b", r"\bSHOULD\b", r"\bNEVER\b", r"\bALWAYS\b",
    r"\bLOCKED\b", r"\bINVARIANT\b", r"\bGATE\b", r"\bFAIL[- ]CLOSED\b",
    r"\bWIRE\b", r"\bPROMOTE\b", r"\bEXPORT\b", r"\bROUTER\b",
    r"\bSANDCRAWLER\b", r"\bPRE\b", r"\bHTDL\b", r"\bREPLAY\b",
]
DECISION_RE = re.compile("|".join(DECISION_PATTERNS), re.IGNORECASE)

TYPE_RULES = [
    ("gate", re.compile(r"\bGATE\b|\bFAIL[- ]CLOSED\b", re.IGNORECASE)),
    ("router", re.compile(r"\bROUTER\b", re.IGNORECASE)),
    ("telemetry", re.compile(r"\bHTDL\b|\bTRACE\b", re.IGNORECASE)),
    ("crawler", re.compile(r"\bSANDCRAWLER\b|\bPRE\b", re.IGNORECASE)),
    ("export", re.compile(r"\bEXPORT\b|\bSNAPSHOT\b", re.IGNORECASE)),
]

def now():
    return datetime.utcnow().isoformat()+"Z"

def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def extract_text(m):
    if not isinstance(m, dict): return None
    if isinstance(m.get("content"), str): return m["content"]
    c = m.get("content")
    if isinstance(c, dict):
        parts = c.get("parts")
        if isinstance(parts, list):
            return "\n".join([p for p in parts if isinstance(p, str)]).strip() or None
        if isinstance(c.get("text"), str): return c.get("text")
    return None

def iter_message_texts(obj):
    if isinstance(obj, dict):
        if "messages" in obj and isinstance(obj["messages"], list):
            for m in obj["messages"]:
                t = extract_text(m)
                if t: yield t
        if "mapping" in obj and isinstance(obj["mapping"], dict):
            for _, node in obj["mapping"].items():
                msg = node.get("message") if isinstance(node, dict) else None
                if msg:
                    t = extract_text(msg)
                    if t: yield t
        for v in obj.values():
            yield from iter_message_texts(v)
    elif isinstance(obj, list):
        for item in obj:
            yield from iter_message_texts(item)

def decision_type(line: str) -> str:
    for t, rx in TYPE_RULES:
        if rx.search(line):
            return t
    return "policy"

def extract_candidates(text: str):
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s: continue
        if DECISION_RE.search(s) and len(s) >= 12:
            out.append(s)
    return out

def iter_inputs(p: Path, recursive: bool):
    if p.is_file():
        yield p
    else:
        it = p.rglob("*.json") if recursive else p.glob("*.json")
        for f in it:
            yield f

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--recursive", action="store_true")
    ap.add_argument("--domain", default="UNKNOWN")
    ap.add_argument("--model_id", default="gpt-5.2")
    args = ap.parse_args()

    in_path = Path(args.input)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    trace_id = str(uuid.uuid4())

    decisions = out_dir / "decisions.ndjson"
    review = out_dir / "review.md"
    htdl_seed = out_dir / "htdl_seed.ndjson"

    with decisions.open("w", encoding="utf-8") as d, review.open("w", encoding="utf-8") as r, htdl_seed.open("w", encoding="utf-8") as h:
        r.write("# Replay Review Queue (v1)\n\n")
        for fpath in iter_inputs(in_path, args.recursive):
            try:
                obj = load_json(fpath)
            except Exception as e:
                r.write(f"## SKIP: {fpath.name} (load error: {e})\n\n")
                continue
            texts = list(iter_message_texts(obj))
            cands = []
            for t in texts:
                cands.extend(extract_candidates(t))
            if not cands:
                continue
            r.write(f"## {fpath.name}\n\n")
            for line in cands:
                did = "DEC-" + uuid.uuid4().hex[:10]
                dtype = decision_type(line)
                rec = {
                    "decision_id": did,
                    "trace_id": trace_id,
                    "timestamp": now(),
                    "domain": args.domain,
                    "decision_type": dtype,
                    "decision_text": line,
                    "promotion_status": "needs_review",
                    "source": str(fpath),
                }
                d.write(json.dumps(rec, ensure_ascii=False) + "\n")
                r.write(f"- [{did}] ({dtype}) {line}\n")

                # Seed HTDL placeholders
                h.write(json.dumps({
                    "heuristic_intent": {
                        "id": "H-"+did,
                        "timestamp": now(),
                        "domain": args.domain,
                        "task_type": "retroactive_replay_candidate",
                        "heuristic_action": line,
                        "confidence": "candidate",
                        "perceived_risk": "unknown",
                        "notes": "Seeded from replay; verify with Sandcrawler if volatile",
                        "trace_id": trace_id,
                        "session_id": "replay_v1",
                        "model_id": args.model_id,
                        "start_ts": now(),
                        "end_ts": now(),
                        "latency_ms": None,
                        "token_estimate": None,
                        "cost_estimate": None
                    },
                    "verified_reality": None,
                    "divergence": None
                }, ensure_ascii=False) + "\n")
            r.write("\n")

    # Optional promotion manifest skeleton for Pilot+Promotion engine
    (out_dir / "promotion_manifest.json").write_text(json.dumps({
        "writes": []
    }, indent=2), encoding="utf-8")

    print(json.dumps({"trace_id": trace_id, "out": str(out_dir)}, indent=2))

if __name__ == "__main__":
    main()
