# HTE Phase 1 — Offline Analysis (Read-Only)

Phase 1 consumes Phase 0 raw observables (`ledgers/hte_raw.ndjson`) and produces derived artifacts under `analysis/`.

Invariant constraints:
- Read-only inputs
- No writes back into runtime ledgers
- No behavior changes or enforcement
- No synthetic scores logged to Phase 0

Outputs produced by the reference analyzer:
- `analysis/tool_invocation_rates.csv`
- `analysis/tool_avoidance.csv`
- `analysis/compliance_latency.csv`
- `analysis/gate_trigger_frequencies.csv`

Run:
- `python scripts/hte_phase1_analyze.py`
