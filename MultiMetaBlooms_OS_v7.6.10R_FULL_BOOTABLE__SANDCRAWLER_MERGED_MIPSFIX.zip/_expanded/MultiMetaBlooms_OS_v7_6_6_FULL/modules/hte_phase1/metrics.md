# Phase 1 Derived Metrics (Definitions)

Computed offline from `ledgers/hte_raw.ndjson`.

1) Tool Invocation Rate
- For each (tool.name), compute:
  tool_call_completed_count / eligibility_assessed_count where eligibility.eligible=true

2) Tool Avoidance
- For each run_id, count eligibility_assessed (eligible=true) events with no subsequent tool_call_* events.
- tool_avoidance_rate = avoided / total_eligible

3) Compliance Latency
- For each compliance.request_id, compute delta between earliest event that records the request and the first event that records fulfillment.
- Export both seconds and event-count latency where possible.

4) Gate Trigger Frequency
- gate_triggered_count / total_events
- plus breakdown by gate.name

No thresholds. No judgments. No enforcement.
