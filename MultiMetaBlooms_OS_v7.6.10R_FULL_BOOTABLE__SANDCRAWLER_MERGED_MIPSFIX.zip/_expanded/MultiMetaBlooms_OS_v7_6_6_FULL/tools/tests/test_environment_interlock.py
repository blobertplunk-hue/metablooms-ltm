"""
Environment Awareness Interlock — Minimal Test Harness

This harness is intentionally conservative: it does NOT attempt to execute fixes.
It only determines whether the interlock should trigger and whether a fail-closed
downgrade is required given a set of environment assumptions and a draft "plan".

Run (optional):
    python tools/tests/test_environment_interlock.py

Outputs:
    PASS/FAIL with reasons.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any, Tuple

ROOT = Path(__file__).resolve().parents[2]  # bundle root
LEDGER_SEED = ROOT / "ledgers" / "ENVIRONMENT_FAILURE_LEDGER.seed.json"

E_P0 = ["E-P0-1","E-P0-2","E-P0-3","E-P0-4","E-P0-5"]

TRIGGER_PATTERNS = [
    r"\btermux\b", r"\bpowershell\b", r"\bandroid\b", r"\bwindows\b",
    r"\bzip\b", r"\bdownload\b", r"\bpath\b", r"~/", r"/storage/emulated/0",
    r"\brun\b", r"\bexecute\b", r"\bcommand\b", r"\bsave\b",
]

@dataclass
class InterlockResult:
    triggered: bool
    ledger_consulted: bool
    stop_path: bool
    reasons: List[str]

def load_seed() -> Dict[str, Any]:
    data = json.loads(LEDGER_SEED.read_text(encoding="utf-8"))
    return data

def interlock_should_trigger(user_request: str) -> bool:
    s = user_request.lower()
    return any(re.search(p, s) for p in TRIGGER_PATTERNS)

def consult_ledger(seed: Dict[str, Any], envs: List[str]) -> List[str]:
    violated = []
    for e in seed.get("entries", []):
        if e.get("environment") in envs:
            v = e.get("violated_invariant")
            if v and v not in violated:
                violated.append(v)
    return violated

def hard_checks(draft_plan: str, previously_violated: List[str]) -> Tuple[bool, List[str]]:
    """
    draft_plan is a plain-language description of what we intend to do.
    If it includes known-risk behaviors, we trip STOP PATH.
    """
    plan = draft_plan.lower()
    reasons = []
    # E-P0-1: assumes local execution
    if "run " in plan or "execute " in plan or "ask user to run" in plan:
        if "E-P0-1" in previously_violated:
            reasons.append("Trips E-P0-1: assumes local execution.")
    # E-P0-2: assumes path
    if "save to" in plan or "use path" in plan or "~/" in plan:
        if "E-P0-2" in previously_violated:
            reasons.append("Trips E-P0-2: assumes filesystem path without verification.")
    # E-P0-3: relies on UI success
    if "link should work" in plan or "download should work" in plan:
        if "E-P0-3" in previously_violated:
            reasons.append("Trips E-P0-3: treats UI success as persistence.")
    # E-P0-4: generalizes shell behavior
    if "same command" in plan or "works in any shell" in plan:
        if "E-P0-4" in previously_violated:
            reasons.append("Trips E-P0-4: generalizes shell behavior.")
    # E-P0-5: ignores permissions
    if "permissions won't be an issue" in plan or "ignore permissions" in plan:
        if "E-P0-5" in previously_violated:
            reasons.append("Trips E-P0-5: ignores permissions as primary failure mode.")
    return (len(reasons) > 0), reasons

def run_case(name: str, user_request: str, envs: List[str], draft_plan: str, expect_stop: bool) -> bool:
    seed = load_seed()
    triggered = interlock_should_trigger(user_request)
    if not triggered:
        # If not triggered, we expect no stop.
        ok = (expect_stop is False)
        print(f"[{name}] triggered={triggered} expect_stop={expect_stop} -> {'PASS' if ok else 'FAIL'}")
        return ok

    violated = consult_ledger(seed, envs)
    stop, reasons = hard_checks(draft_plan, violated)
    ok = (stop == expect_stop)
    print(f"[{name}] triggered={triggered} envs={envs} violated={violated} stop={stop} expect_stop={expect_stop} -> {'PASS' if ok else 'FAIL'}")
    if reasons:
        for r in reasons:
            print(f"  - {r}")
    return ok

def main() -> None:
    cases = [
        (
            "CASE_1_POWERSHELL_EXEC",
            "Can you give me a PowerShell command to split this zip?",
            ["powershell"],
            "Ask user to run a PowerShell command to split the zip.",
            True
        ),
        (
            "CASE_2_TERMUX_PATH",
            "Where should I save this file in Termux?",
            ["termux"],
            "Tell user to save to ~/downloads.",
            True
        ),
        (
            "CASE_3_SANDBOX_ONLY",
            "My download link expired. Can you re-export the zip?",
            ["sandbox"],
            "Create the artifact in sandbox, verify size+hash, and provide a fresh download.",
            False
        ),
        (
            "CASE_4_NO_TRIGGER",
            "Write a lesson plan for TEKS 3.10",
            ["sandbox"],
            "Write lesson plan content only.",
            False
        )
    ]
    results = [run_case(*c) for c in cases]
    if all(results):
        print("ALL TESTS PASS")
    else:
        raise SystemExit("ONE OR MORE TESTS FAILED")

if __name__ == "__main__":
    main()
