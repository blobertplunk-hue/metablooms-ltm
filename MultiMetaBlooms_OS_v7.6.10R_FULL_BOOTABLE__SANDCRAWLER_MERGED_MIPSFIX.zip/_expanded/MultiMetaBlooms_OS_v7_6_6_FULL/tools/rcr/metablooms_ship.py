#!/usr/bin/env python3
"""
MetaBlooms Ship Pipeline (Fail-Closed)
- Runs Export Gate
- If FAIL: runs RCR safe repairs, then reruns gate
- Ships ONLY if gate passes
"""
from __future__ import annotations
import sys, subprocess, tempfile, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent  # .../tools/rcr/ -> bundle root
GATE = ROOT / "tools" / "rcr" / "metablooms_export_gate.py"
RCR  = ROOT / "tools" / "rcr" / "metablooms_rcr.py"

def run(cmd:list[str])->int:
    p = subprocess.run(cmd, text=True)
    return p.returncode

def main(argv:list[str])->int:
    if len(argv)!=2:
        print("Usage: python tools/rcr/metablooms_ship.py <MetaBlooms_OS.zip | extracted_dir>")
        return 2
    target = Path(argv[1]).expanduser().resolve()
    if not target.exists():
        print(f"Not found: {target}")
        return 2

    # 1) Gate
    rc = run([sys.executable, str(GATE), str(target)])
    if rc==0:
        print("SHIP_OK: export gate pass")
        return 0

    print("SHIP_BLOCKED: gate failed; invoking RCR safe repair")
    tmp = Path(tempfile.mkdtemp(prefix="mb_ship_"))
    out = tmp / "REPAIRED.zip"
    rc2 = run([sys.executable, str(RCR), "repair", str(target), "--out", str(out), "--report-dir", str(tmp/"rcr_reports")])
    if rc2!=0:
        print("SHIP_FAILED: RCR could not produce a passing artifact")
        print(f"RCR reports: {tmp/'rcr_reports'}")
        return 2

    # 2) Gate again
    rc3 = run([sys.executable, str(GATE), str(out)])
    if rc3!=0:
        print("SHIP_FAILED: repaired artifact still fails gate")
        print(f"Repaired zip: {out}")
        print(f"RCR reports: {tmp/'rcr_reports'}")
        return 2

    # Move repaired zip next to original name if input was zip
    if target.is_file() and target.suffix.lower()==".zip":
        final = target.parent / (target.stem + "_REPAIRED_GATEPASS.zip")
    else:
        final = Path.cwd() / "MetaBlooms_OS_REPAIRED_GATEPASS.zip"
    shutil.copy2(out, final)
    print(f"SHIP_OK: wrote {final}")
    return 0

if __name__=="__main__":
    raise SystemExit(main(sys.argv))
