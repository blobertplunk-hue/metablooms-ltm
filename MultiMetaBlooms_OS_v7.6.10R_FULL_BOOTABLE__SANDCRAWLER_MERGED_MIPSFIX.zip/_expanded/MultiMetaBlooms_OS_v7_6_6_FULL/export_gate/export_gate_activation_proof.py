#!/usr/bin/env python3
"""
Export Gate: Activation Proof (Fail-Closed)

This gate MUST pass before an OS bundle may be re-shipped.
"""
from __future__ import annotations
from pathlib import Path
import zipfile, json, re, hashlib, time, tempfile

REQUIRED = {"CHM","HEURISTIC_MATRIX","BRIDGE_MAP"}

def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(1024*1024), b""):
            h.update(c)
    return h.hexdigest()

def extract(zp: Path, out: Path):
    with zipfile.ZipFile(zp, "r") as z:
        z.extractall(out)

def required_list(text: str):
    m = re.search(r"REQUIRED\s*:\s*List\[str\]\s*=\s*\[(.*?)\]", text, re.S)
    if not m:
        return None
    return set(re.findall(r'["\']([^"\']+)["\']', m.group(1)))

def activate_all_wired(text: str) -> bool:
    m = re.search(r"def\s+activate_all\s*\(.*?\):(.+)", text, re.S)
    if not m:
        return False
    body = m.group(1)
    return all(r in body for r in REQUIRED)

def main(zip_path: str) -> int:
    zp = Path(zip_path).resolve()
    report = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "zip": str(zp),
        "sha256": sha256(zp),
        "checks": [],
        "pass": True
    }
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        extract(zp, root)

        # Presence
        for rel in [
            "BOOT_METABLOOMS.py",
            "boot_manifest.json",
            "control_plane/boot_activator.py",
            "control_plane/chm_contract.json",
            "control_plane/heuristic_matrix.json",
            "control_plane/bridge_map.json",
        ]:
            ok = (root/rel).exists()
            report["checks"].append({"check": rel, "pass": ok})
            report["pass"] &= ok

        ba = root/"control_plane/boot_activator.py"
        if ba.exists():
            txt = ba.read_text(encoding="utf-8", errors="replace")
            req = required_list(txt)
            ok_req = bool(req) and REQUIRED.issubset(req)
            report["checks"].append({"check": "REQUIRED_LIST", "pass": ok_req, "found": sorted(req) if req else None})
            report["pass"] &= ok_req

            ok_act = activate_all_wired(txt)
            report["checks"].append({"check": "ACTIVATE_ALL_WIRING", "pass": ok_act})
            report["pass"] &= ok_act
        else:
            report["checks"].append({"check": "BOOT_ACTIVATOR_MISSING", "pass": False})
            report["pass"] = False

    Path("EXPORT_GATE_REPORT.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return 0 if report["pass"] else 2

if __name__ == "__main__":
    import sys
    raise SystemExit(main(sys.argv[1]))
