# Export Gate Checklist (Fail-Closed)

This OS may not be re-shipped unless export_gate_activation_proof.py passes.

Required proofs:
- CHM, Heuristic Matrix, BridgeMap are REQUIRED
- activate_all() wires all three
- CHM ledger emits at boot
