#!/usr/bin/env python3
"""
HTE Phase 1 Reference Analyzer (Read-Only)

Consumes: ledgers/hte_raw.ndjson
Produces (under analysis/):
- tool_invocation_rates.csv
- tool_avoidance.csv
- compliance_latency.csv
- gate_trigger_frequencies.csv

This script MUST NOT write back into ledgers/.
"""

from __future__ import annotations
import json, pathlib, datetime, collections
from typing import Any, Dict, List, Optional, Tuple

ROOT = pathlib.Path(__file__).resolve().parents[1]
LEDGER = ROOT / "ledgers" / "hte_raw.ndjson"
OUTDIR = ROOT / "analysis"
OUTDIR.mkdir(parents=True, exist_ok=True)

def parse_iso(ts: str) -> Optional[datetime.datetime]:
    try:
        if ts.endswith("Z"):
            ts = ts[:-1] + "+00:00"
        return datetime.datetime.fromisoformat(ts)
    except Exception:
        return None

def load_events() -> List[Dict[str, Any]]:
    events = []
    if not LEDGER.exists():
        raise SystemExit(f"Missing ledger: {LEDGER}")
    with LEDGER.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            events.append(json.loads(line))
    return events

def write_csv(path: pathlib.Path, rows: List[Dict[str, Any]], fieldnames: List[str]) -> None:
    import csv
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fieldnames})

def main() -> None:
    ev = load_events()

    # Index by run_id, and keep original order
    by_run: Dict[str, List[Dict[str, Any]]] = collections.defaultdict(list)
    for e in ev:
        by_run[e.get("run_id","run-unknown")].append(e)

    # 1) Tool invocation rates
    # Count eligible assessments per run and globally, and completed tool calls by tool name
    eligible_counts = 0
    completed_by_tool = collections.Counter()
    eligibility_by_run = collections.Counter()
    completed_by_tool_by_run = collections.defaultdict(collections.Counter)

    for e in ev:
        if e.get("event_type") == "eligibility_assessed":
            elig = (e.get("eligibility") or {})
            if elig.get("eligible") is True:
                eligible_counts += 1
                eligibility_by_run[e.get("run_id","run-unknown")] += 1
        if e.get("event_type") == "tool_call_completed":
            tool = (e.get("tool") or {})
            name = tool.get("name","tool-unknown")
            completed_by_tool[name] += 1
            completed_by_tool_by_run[e.get("run_id","run-unknown")][name] += 1

    tool_invocation_rows = []
    for tool_name, comp in completed_by_tool.items():
        tool_invocation_rows.append({
            "tool_name": tool_name,
            "tool_call_completed": comp,
            "eligible_assessments": eligible_counts,
            "invocation_rate_per_eligible": (comp / eligible_counts) if eligible_counts else 0.0
        })
    tool_invocation_rows.sort(key=lambda r: (-r["tool_call_completed"], r["tool_name"]))
    write_csv(OUTDIR/"tool_invocation_rates.csv", tool_invocation_rows,
              ["tool_name","tool_call_completed","eligible_assessments","invocation_rate_per_eligible"])

    # 2) Tool avoidance by run
    # If a run has N eligible assessments but zero tool_call_* events after them, mark avoided=N (conservative)
    avoidance_rows = []
    for run_id, events in by_run.items():
        eligible = sum(1 for e in events if e.get("event_type")=="eligibility_assessed" and (e.get("eligibility") or {}).get("eligible") is True)
        any_tool_calls = any(e.get("event_type","").startswith("tool_call_") for e in events)
        avoided = eligible if (eligible and not any_tool_calls) else 0
        avoidance_rows.append({
            "run_id": run_id,
            "eligible_assessments": eligible,
            "any_tool_calls": bool(any_tool_calls),
            "eligible_but_no_tool_calls": avoided,
            "tool_avoidance_rate": (avoided/eligible) if eligible else 0.0
        })
    write_csv(OUTDIR/"tool_avoidance.csv", avoidance_rows,
              ["run_id","eligible_assessments","any_tool_calls","eligible_but_no_tool_calls","tool_avoidance_rate"])

    # 3) Compliance latency (time + event steps)
    # Track first request and first fulfillment for each request_id
    first_req = {}
    first_fulfill = {}
    first_req_idx = {}
    first_fulfill_idx = {}

    for idx, e in enumerate(ev):
        comp = e.get("compliance") or {}
        rid = comp.get("request_id")
        if not rid:
            continue
        ts = parse_iso(e.get("ts_utc_iso",""))
        if rid not in first_req:
            first_req[rid] = ts
            first_req_idx[rid] = idx
        # Fulfillment can be expressed either by compliance.fulfilled True or fulfillment_event_id match
        if comp.get("fulfilled") is True and rid not in first_fulfill:
            first_fulfill[rid] = ts
            first_fulfill_idx[rid] = idx

    compliance_rows = []
    for rid, t0 in first_req.items():
        t1 = first_fulfill.get(rid)
        dt = None
        if t0 and t1:
            dt = (t1 - t0).total_seconds()
        compliance_rows.append({
            "request_id": rid,
            "requested_ts": t0.isoformat() if t0 else "",
            "fulfilled_ts": t1.isoformat() if t1 else "",
            "latency_seconds": dt if dt is not None else "",
            "latency_event_steps": (first_fulfill_idx.get(rid,"") - first_req_idx.get(rid,"")) if (rid in first_fulfill_idx and rid in first_req_idx) else ""
        })
    write_csv(OUTDIR/"compliance_latency.csv", compliance_rows,
              ["request_id","requested_ts","fulfilled_ts","latency_seconds","latency_event_steps"])

    # 4) Gate trigger frequencies
    total = len(ev)
    gate_trig = [e for e in ev if e.get("event_type")=="gate_triggered"]
    by_gate = collections.Counter((e.get("gate") or {}).get("name","gate-unknown") for e in gate_trig)
    gate_rows = [{
        "gate_name": g,
        "gate_triggered": c,
        "total_events": total,
        "trigger_rate": (c/total) if total else 0.0
    } for g,c in by_gate.items()]
    gate_rows.sort(key=lambda r: (-r["gate_triggered"], r["gate_name"]))
    write_csv(OUTDIR/"gate_trigger_frequencies.csv", gate_rows,
              ["gate_name","gate_triggered","total_events","trigger_rate"])

    print("OK: Phase 1 analysis complete.")
    print(f"- {OUTDIR/'tool_invocation_rates.csv'}")
    print(f"- {OUTDIR/'tool_avoidance.csv'}")
    print(f"- {OUTDIR/'compliance_latency.csv'}")
    print(f"- {OUTDIR/'gate_trigger_frequencies.csv'}")

if __name__ == "__main__":
    main()
