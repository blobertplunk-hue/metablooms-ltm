from __future__ import annotations
import json, sys
from collections import Counter

def main(path: str) -> int:
    counts = Counter()
    laws = Counter()
    total = 0
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line:
                continue
            obj = json.loads(line)
            total += 1
            counts[obj.get("classification","UNKNOWN")] += 1
            for law in obj.get("laws_applied", []) or []:
                laws[law] += 1

    print(f"HDL entries: {total}")
    print("Classification counts:")
    for k,v in counts.most_common():
        print(f"  {k}: {v}")
    print("Top laws invoked:")
    for law, n in laws.most_common(10):
        print(f"  {law}: {n}")
    return 0

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python src/trends.py out/hdl.ndjson")
        raise SystemExit(2)
    raise SystemExit(main(sys.argv[1]))
