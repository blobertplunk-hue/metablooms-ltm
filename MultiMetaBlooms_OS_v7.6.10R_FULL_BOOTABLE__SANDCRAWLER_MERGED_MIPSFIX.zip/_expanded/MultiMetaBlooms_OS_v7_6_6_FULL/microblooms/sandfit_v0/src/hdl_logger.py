from __future__ import annotations
import json, time, uuid
from dataclasses import dataclass, asdict
from typing import List

@dataclass
class HDLEntry:
    decision_id: str
    timestamp_utc: str
    engine: str
    domain: str
    task: str
    heuristic_impulse: str
    metablooms_action: str
    laws_applied: List[str]
    classification: str
    outcome: str
    notes: str = ""

def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def new_decision_id(prefix: str="DEC") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"

def classify(outcome: str, metablooms_overrode_heuristic: bool, heuristic_danger: bool, insufficient_info: bool) -> str:
    if insufficient_info:
        return "WALK"
    if heuristic_danger:
        return "RUN"
    ol = (outcome or "").lower()
    good = any(k in ol for k in ["correct", "accepted", "prevented", "fit_found", "fit"])
    bad = any(k in ol for k in ["wrong", "overstrict", "blocked", "missed"])
    if metablooms_overrode_heuristic:
        if good and not bad:
            return "HOLD"
        if bad and not good:
            return "FOLD"
        return "WALK"
    return "HOLD" if good and not bad else "WALK"

def append_ndjson(path: str, entry: HDLEntry) -> str:
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(entry), ensure_ascii=False) + "\n")
    return entry.decision_id
