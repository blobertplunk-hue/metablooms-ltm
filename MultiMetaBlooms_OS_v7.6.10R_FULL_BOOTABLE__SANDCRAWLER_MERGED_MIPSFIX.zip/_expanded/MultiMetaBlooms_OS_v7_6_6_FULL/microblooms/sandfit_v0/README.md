# SandFit v0 Bundle (2025-12-30)

This bundle wires the SandFit engine (internal name) as the companion to SandCrawler and implements:
- SandFit Engine Stub (constraint-fit adjudicator)
- Heuristic Differential Ledger (HDL) + HOLD/FOLD/WALK/RUN classification
- SandCrawler → SandFit interface contract
- Minimal trend summarizer
- Example run output (sample shopping scenario)

User-facing phrasing supported:
- "I'm shopping in SandFit shops"
- "Run this through SandFit"
- "Use SandFit to check this"

## Run (from bundle root)
```bash
python -m examples.example_run
python src/trends.py out/hdl.ndjson
```
