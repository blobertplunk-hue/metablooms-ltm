# Architecture

## Roles
- SandCrawler: discovery layer producing candidates.
- SandFit: constraint-fit adjudicator producing viable + rejected with explicit reasons.

## Arbitration & learning
SandFit logs each decision to HDL, including:
- heuristic impulse (what would normally happen)
- metablooms action (what governance requires)
- HOLD/FOLD/WALK/RUN classification

## v0 scope
- Deterministic constraint checks
- Fail-closed on unverifiable hard constraints
- Append-only NDJSON ledger
