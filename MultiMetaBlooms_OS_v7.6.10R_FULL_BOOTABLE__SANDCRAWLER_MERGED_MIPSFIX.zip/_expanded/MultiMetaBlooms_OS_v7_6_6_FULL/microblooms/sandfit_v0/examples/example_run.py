from __future__ import annotations
import json, os

from src.sandcrawler_adapter import sandcrawler_to_sandfit
from src.sandfit_engine import run_sandfit

def main() -> None:
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    outdir = os.path.join(root, "out")
    os.makedirs(outdir, exist_ok=True)

    # Simulated SandCrawler candidates
    candidates = [
        {"id":"A1","title":"Clear Stackable Bin 12x12x8","source":"target","attributes":{"width_in":12,"depth_in":12,"height_in":8}},
        {"id":"B2","title":"Clear Bin 12x12x14.5","source":"walmart","attributes":{"width_in":12,"depth_in":12,"height_in":14.5}},
        {"id":"C3","title":"Clear Organizer 11.5x11.5 (height unknown)","source":"target","attributes":{"width_in":11.5,"depth_in":11.5}},
        {"id":"D4","title":"Opaque Bin 10x10x8","source":"target","attributes":{"width_in":10,"depth_in":10,"height_in":8}}
    ]

    constraints = {"max_height_in":12.0, "max_width_in":12.75, "max_depth_in":12.75}
    payload = sandcrawler_to_sandfit(
        candidates=candidates,
        constraints=constraints,
        domain="shopping_storage_bins",
        risk_tolerance="low",
        notes="Example run: shelf clearance scenario"
    )

    hdl_path = os.path.join(outdir, "hdl.ndjson")
    result = run_sandfit(payload, hdl_path=hdl_path)

    with open(os.path.join(outdir, "sandfit_input.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    with open(os.path.join(outdir, "sandfit_output.json"), "w", encoding="utf-8") as f:
        json.dump({
            "viable": result.viable,
            "rejected": result.rejected,
            "decision_log_ref": result.decision_log_ref,
            "summary": result.summary
        }, f, indent=2)

    report = []
    report.append("# SandFit Example Report")
    report.append("")
    report.append("## Summary")
    report.append(result.summary)
    report.append("")
    report.append("## Viable")
    if result.viable:
        for v in result.viable:
            report.append(f"- {v['candidate_id']}: {v['title']}")
    else:
        report.append("- (none)")
    report.append("")
    report.append("## Rejected (with reasons)")
    for r in result.rejected:
        report.append(f"- {r['candidate_id']}: {r['reason']}")
    report.append("")
    report.append("## HDL decision reference")
    report.append(f"- {result.decision_log_ref}")

    with open(os.path.join(outdir, "report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(report))

if __name__ == "__main__":
    main()
