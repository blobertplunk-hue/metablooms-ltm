# Egg Juicer — System (EJ-CORE-1.0)

Egg Juicer is a family of extraction engines whose purpose is to **squeeze an input corpus until no useful signal remains unextracted**.

Two distinct systems are maintained:

1) **Egg Juicer (EJ-CORE)** — the umbrella system definition, shared primitives, contracts, output schemas, and integration points.

2) **Chunk Egg Juicer (CEJ)** — a specific Egg Juicer configured for *multi-chunk chat transcript ingestion*, run repeatedly across a numbered chunk series.
   - CEJ is not a metaphor; it is an operational pipeline with mandatory passes CEJ-1 through CEJ-9.

Design intent:
- Prevent “we already did this” loops by producing durable artifacts.
- Prevent silent loss of details by forbidding compression until object exhaustion.
- Separate evidence from inference.
- Produce continuation capsules that keep multi-turn work deterministic.

Scope:
- Works on: chat transcripts, tool logs, code dumps, research dumps.
- Produces: inventories, failure taxonomies, survivor rules, promotion candidates, and continuation capsules.
