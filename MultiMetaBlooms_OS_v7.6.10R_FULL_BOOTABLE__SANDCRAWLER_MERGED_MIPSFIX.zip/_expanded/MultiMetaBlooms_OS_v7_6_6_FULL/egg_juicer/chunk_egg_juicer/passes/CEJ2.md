# CEJ-2 — Evidence Classification Pass

Deliverable: evidence-tagged claims.

Procedure:
- For each object/claim, label evidence_type:
  - user_statement | tool_output | execution_log | artifact_file | inference
- If inference is used, include the exact supporting evidence pointer(s).
- Output: CEJ_chunk_N_evidence_map.json
