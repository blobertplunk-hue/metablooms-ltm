# CEJ-5 — Tooling & Workflow Extraction Pass

Deliverable: reusable tools and workflow patterns.

Fields:
- tool_id, description, where it belongs (MetaBlooms folder), reuse_notes
- Output: CEJ_chunk_N_tooling.json
