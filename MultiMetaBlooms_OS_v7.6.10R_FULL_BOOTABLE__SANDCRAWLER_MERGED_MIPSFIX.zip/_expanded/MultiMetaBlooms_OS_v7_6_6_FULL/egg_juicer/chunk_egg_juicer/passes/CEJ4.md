# CEJ-4 — Success / Survivor Pass

Deliverable: what worked, even once.

Fields:
- survivor_id, success_condition, reproduction_steps, false_positive_risk (especially UI illusion), evidence_pointer
- Output: CEJ_chunk_N_survivors.json + markdown report.
