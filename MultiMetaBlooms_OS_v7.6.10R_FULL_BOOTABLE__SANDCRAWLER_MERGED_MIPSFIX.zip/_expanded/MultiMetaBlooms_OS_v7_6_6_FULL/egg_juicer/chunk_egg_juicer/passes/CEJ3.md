# CEJ-3 — Failure Taxonomy Pass

Deliverable: failure catalog with recovery status.

Fields:
- failure_id, trigger, symptom, permanence (recoverable/permanent), mitigation, evidence_pointer
- Output: CEJ_chunk_N_failures.json + markdown report.
