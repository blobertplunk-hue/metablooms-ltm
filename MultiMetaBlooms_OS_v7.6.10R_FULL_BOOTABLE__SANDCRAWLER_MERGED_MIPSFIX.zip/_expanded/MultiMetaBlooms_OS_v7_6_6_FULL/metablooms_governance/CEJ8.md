## CEJ-8 Promotion Candidates
Enabled vs provisional vs blocked with rationale.
