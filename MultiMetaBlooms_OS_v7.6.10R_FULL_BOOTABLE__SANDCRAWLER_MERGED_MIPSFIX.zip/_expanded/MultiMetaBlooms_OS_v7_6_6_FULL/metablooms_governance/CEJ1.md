## CEJ-1 Inventory Pass
Enumerate all objects; no compression.
