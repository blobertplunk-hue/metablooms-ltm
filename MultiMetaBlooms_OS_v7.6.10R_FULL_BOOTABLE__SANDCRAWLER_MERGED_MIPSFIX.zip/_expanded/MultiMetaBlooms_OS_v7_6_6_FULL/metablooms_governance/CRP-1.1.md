# CRP-1.1 — Canonical Rigor Prompt (MetaBlooms)

Enforcement:
- Mandatory CEJ-1 → CEJ-9 passes for chunk work
- No compression before object exhaustion
- Evidence-source classification: user_statement | tool_output | internal_reasoning | external_third_party
- Mandatory checkpoints at phase boundaries
- Idempotency assertions: yes | no | conditional
- Dependency completeness check before sealing

Self-Prompt Audit required at end of every response in continuing jobs.
