# MEEP-1.0 — MetaBlooms Export Enforcement Prompt

Trigger phrases: export the OS / export project files / give me the zip / bundle everything / ship the system.

Rules:
- Inventory → Eligibility → Completeness self-challenge → Assembly → Diff are mandatory.
- Summaries are forbidden as substitutes for files.
- Silent exclusions are a hard failure.
- Blocked items must list: reason + unblocking condition.
