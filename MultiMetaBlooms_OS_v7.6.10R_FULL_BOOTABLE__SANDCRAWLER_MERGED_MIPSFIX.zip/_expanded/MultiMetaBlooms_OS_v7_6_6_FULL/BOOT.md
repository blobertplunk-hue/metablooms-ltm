# BOOT — MetaBlooms (Option A Forever)

Upload these two files to Project Files root:
1) BOOT.md (this file)
2) MetaBlooms*.zip (the bundle)

When you say “Boot MetaBlooms”, the assistant must do EXACTLY:
1) Copy the bundle zip to: /mnt/data/MetaBlooms_bundle.zip
2) Extract to: /mnt/data/MetaBlooms/
3) Run: python /mnt/data/MetaBlooms/BOOT_METABLOOMS.py --bundle /mnt/data/MetaBlooms_bundle.zip

If it fails, report the exact BOOT_FAILED:* code and stop.
