# Changes Since v7.5.5
- Stability lock and invariants added.
