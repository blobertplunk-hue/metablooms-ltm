import json, hashlib, datetime
from pathlib import Path

def _utc():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def write_deltapack_v1(out_dir: str, author: str, scope: str, operations: list, activation_requirements: dict,
                      chat_session_id: str, chat_turn_id: str, tags: list|None=None) -> str:
    dp = {
        "schema": "MetaBlooms::DeltaPack::v1",
        "delta_id": f"delta_{_utc().replace(':','').replace('-','')}",
        "created_utc": _utc(),
        "author": author,
        "scope": scope,
        "operations": operations,
        "activation_requirements": activation_requirements,
        "links": {
            "chat_session_id": chat_session_id,
            "chat_turn_id": chat_turn_id
        },
        "tags": tags or []
    }
    body = json.dumps({k:v for k,v in dp.items() if k!="hash_sha256"}, sort_keys=True).encode("utf-8")
    dp["hash_sha256"] = hashlib.sha256(body).hexdigest()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{dp['delta_id']}.json"
    path.write_text(json.dumps(dp, indent=2, sort_keys=True), encoding="utf-8")
    return str(path)
