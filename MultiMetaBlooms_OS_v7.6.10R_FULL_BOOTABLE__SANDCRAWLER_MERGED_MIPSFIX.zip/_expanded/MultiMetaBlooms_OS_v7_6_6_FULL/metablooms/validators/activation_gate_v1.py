import json, datetime
from pathlib import Path
from metablooms.validators.validate_deltapack_v1 import validate_deltapack_v1

def activate_deltapack_v1(deltapack_path: str, delta_ledger_path: str) -> dict:
    validate_deltapack_v1(deltapack_path)
    dp = json.loads(Path(deltapack_path).read_text(encoding="utf-8"))
    rec = {
        "schema": "MetaBlooms::DeltaLedger::v1",
        "delta_id": dp["delta_id"],
        "activated_utc": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "scope": dp["scope"],
        "hash_sha256": dp["hash_sha256"],
        "status": "ACTIVE",
        "links": dp.get("links", {}),
        "tags": dp.get("tags", [])
    }
    with Path(delta_ledger_path).open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, sort_keys=True) + "\n")
    return rec
