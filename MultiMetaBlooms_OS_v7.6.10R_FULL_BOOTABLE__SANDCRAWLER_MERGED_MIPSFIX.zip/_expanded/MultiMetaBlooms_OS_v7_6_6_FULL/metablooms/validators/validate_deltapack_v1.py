import json, hashlib, re
from pathlib import Path

REQUIRED = [
  "schema","delta_id","created_utc","author","scope","operations",
  "activation_requirements","links","hash_sha256"
]
LINKS_REQUIRED = ["chat_session_id","chat_turn_id"]

def _hash_body(dp: dict) -> str:
    body = json.dumps({k:v for k,v in dp.items() if k!="hash_sha256"}, sort_keys=True).encode("utf-8")
    return hashlib.sha256(body).hexdigest()

def validate_deltapack_v1(path: str) -> bool:
    p = Path(path)
    if not p.exists():
        raise ValueError(f"DELTA_NOT_FOUND: {path}")
    dp = json.loads(p.read_text(encoding="utf-8"))
    for r in REQUIRED:
        if r not in dp:
            raise ValueError(f"DELTA_INVALID: missing field '{r}'")
    if dp.get("schema") != "MetaBlooms::DeltaPack::v1":
        raise ValueError("DELTA_INVALID: schema mismatch")
    links = dp.get("links") or {}
    for lr in LINKS_REQUIRED:
        if lr not in links or not str(links[lr]).strip():
            raise ValueError(f"DELTA_INVALID: missing links.{lr}")
    # light sanity: turn id looks like t000001, session starts with chat_
    if not str(links["chat_turn_id"]).startswith("t"):
        raise ValueError("DELTA_INVALID: links.chat_turn_id format")
    if not str(links["chat_session_id"]).startswith("chat_"):
        raise ValueError("DELTA_INVALID: links.chat_session_id format")
    h = _hash_body(dp)
    if h != dp["hash_sha256"]:
        raise ValueError("DELTA_INVALID: hash mismatch")
    return True

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    args = ap.parse_args()
    validate_deltapack_v1(args.path)
    print("VALID_OK")
