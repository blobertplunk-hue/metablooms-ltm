# Environment Guardrails (Hard)

These guardrails prevent repeat environment-related failures (Termux, PowerShell, Android storage, sandbox constraints) by enforcing a fail-closed downgrade when risk is detected.

---

## Trigger

Run these checks before any response that involves:
- files, paths, downloads, zips, shell commands, Termux, PowerShell, Android/Windows storage, or “run/execute” instructions.

---

## Hard Checks (Must all be NO)

1. **Am I assuming the user can run commands?** (E-P0-1)
2. **Am I assuming a filesystem path without verification?** (E-P0-2)
3. **Am I treating UI success as file existence?** (E-P0-3)
4. **Am I generalizing shell behavior across environments?** (E-P0-4)
5. **Am I treating permissions as an edge case?** (E-P0-5)

---

## Fail-Closed Downgrade

If any check is YES:
- downgrade to observation/explanation, or
- deliver a sandbox-only artifact, or
- require explicit environment proof (without requiring the user to execute commands)

In all cases:
- log an environment-failure ledger entry
- do not prescribe shell execution as a dependency

---

## Non-Mutative Constraint

These guardrails do not authorize code changes or environment modification.
They only constrain reasoning and output selection.
