# MB_EXPECTED_FAILURES_LAYER_EFL-1.0
**Date:** 2025-12-31
**Status:** Active

# MetaBlooms: Expected Failures Layer (EFL) — “If it’s expected, we pre-plan it” (Spec v0.1)
**Date:** 2025-12-31  
**Problem:** In governed setups (PowerShell, Termux, GitHub UI flows, etc.), an assistant must never *react* to a “known/expected” issue. If it’s expected, the runtime must **anticipate, detect, branch, and log** it before the user hits it.

---

## One-Screen Summary
EFL is a mandatory layer that converts “known issues” into **guarded playbooks**:
1) Maintain a **Known-Issue Catalog** (KIC) with detection + remediation branches.  
2) Require **pre-execution detection checks** for all KIC-triggerable conditions.  
3) Emit **guardrails** into instructions: “If you see X, do Y; if Z, do W.”  
4) Prohibit post-hoc claims like “oh yeah, that’s expected” unless the playbook already contained it.  
5) Log every hit as evidence and update the catalog via DeltaGate.

---

# 1) Where EFL Lives (Relationship to PRE)
You asked whether this is PRE or something else. The correct answer is:

- **PRE (Pre-Flight Reality Engine)** discovers drift, defaults, and failure reality in the environment.
- **EFL (Expected Failures Layer)** takes that discovered failure reality and **hardens it into planned branches**.

**Rule:** PRE discovers; EFL operationalizes.
They are distinct but chained:

`PRE → Known-Issue Candidates → DeltaGate → KIC (Catalog) → EFL Guarded Playbooks`

---

# 2) Definitions

## 2.1 “Expected Failure”
A failure is “expected” if:
- it is documented in official docs OR
- it appears repeatedly in forums/issues OR
- it is a predictable consequence of defaults/permissions/version drift

## 2.2 Guarded Playbook
A playbook is “guarded” if it contains:
- a detection condition (what the user sees / what the system detects)
- a reason (why it happens)
- a remediation step sequence
- a rollback or safe stop
- a logging requirement (trace event + evidence artifact)

---

# 3) Hard Requirements (Fail-Closed)

## R1 — No Post-Hoc “Expected” Claims
If guidance encounters an issue not listed in the playbook:
- the assistant must label it **UNEXPECTED**
- pause automation
- create a quarantined KIC candidate entry
- require review/promotion via DeltaGate before it becomes “expected”

## R2 — KIC Coverage Check
Before giving step-by-step instructions for systems tagged **Shifting** or **Volatile**, EFL must:
- load KIC entries relevant to the system (e.g., PowerShell, Termux)
- inject the top failure branches into the instruction path

## R3 — Detection First
Every KIC entry must specify at least one detection method:
- observed UI symptom (button missing, permission dialog)
- CLI error signature
- environment query (version, policy)
- filesystem probe

## R4 — Evidence Emission
If a branch is taken, the run must emit:
- `expected_failure_hit` event in trace
- pointer to the KIC entry id
- captured artifact (error text, screenshot reference if available)

---

# 4) Minimal Data Model: Known-Issue Catalog (KIC)
A KIC entry includes:
- `id`, `system`, `surface` (ui/cli), `severity`
- `trigger_signatures` (errors/symptoms)
- `prechecks` (what to test before user hits it)
- `remediation_steps`
- `rollback_steps`
- `source_evidence` (where we learned it)
- `last_verified` date
- `status`: active | quarantine | deprecated

See schema in `known_issue_catalog_schema.json`.

---

# 5) How This Solves Your Exact Complaint
Your complaint was:
> “If it’s expected, you should have expected it and planned for it.”

EFL makes that statement literally enforceable:
- “expected” issues **must exist in KIC**
- “planned” means **prechecks + branches are injected**
- no KIC entry → the system may not call it expected

This converts “assistant vibes” into an auditable contract.

---

# 6) Operational Workflow (Append-Only)
1. PRE discovers issues (official + lived reality).  
2. Candidates are written to `memory/quarantine/kic_candidates/`.  
3. DeltaGate reviews: accept → KIC active; reject → archive.  
4. EFL pulls active KIC entries and merges them into playbooks.  
5. Every run logs hits; periodic PRE re-validates recency and deprecates stale KIC entries.

---

# 7) Implementation Hooks (Minimal)
- Add `kic_loader` to runtime boot (loads active KIC JSON)
- Add `playbook_guard` that injects branches into instructions automatically
- Add `expected_failure_hit` trace event
- Add `kic_candidate_create` event when a new unexpected failure occurs

---

# 8) Acceptance Tests
EFL passes if:
- Every setup playbook references a KIC snapshot hash
- No run emits “expected” language without a KIC id
- Every KIC entry has detection + remediation + rollback
- Every KIC hit emits trace + evidence pointer

---

# 9) [ASSUMED] Example Targets (Placeholders Only)
I am **not** asserting these are current issues without a fresh PRE sweep:
- PowerShell execution policy friction
- Termux storage permission friction
These are listed only to show structure; PRE will populate real entries.
