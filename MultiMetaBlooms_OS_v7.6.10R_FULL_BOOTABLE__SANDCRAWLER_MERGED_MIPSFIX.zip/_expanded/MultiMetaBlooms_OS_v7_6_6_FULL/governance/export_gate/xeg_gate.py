#!/usr/bin/env python3
"""
xeg_gate.py — Export Eligibility Gate XEG-1.0
Hard-fail if required systems are missing.
"""

import sys, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

REQUIRED = ['egg_juicer/README.md', 'egg_juicer/EJ_CORE_CONTRACT.md', 'egg_juicer/chunk_egg_juicer/README.md', 'egg_juicer/chunk_egg_juicer/CEJ_CONTRACT.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ1.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ2.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ3.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ4.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ5.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ6.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ7.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ8.md', 'egg_juicer/chunk_egg_juicer/passes/CEJ9.md', 'governance/BOOT_CONTRACT_BC-1.0.md', 'governance/LEARNING_INTEGRATION_LID-1.0.md', 'governance/RCA_BOOT_RCA-BOOT-1.0.md', 'MEEP_Manifest.json']

missing = [p for p in REQUIRED if not (ROOT / p).exists()]

if missing:
    print("EXPORT_FAILED: MISSING_REQUIRED_SYSTEMS")
    for m in missing:
        print(" -", m)
    sys.exit(1)

print("XEG-1.0 PASS: All required systems present.")
