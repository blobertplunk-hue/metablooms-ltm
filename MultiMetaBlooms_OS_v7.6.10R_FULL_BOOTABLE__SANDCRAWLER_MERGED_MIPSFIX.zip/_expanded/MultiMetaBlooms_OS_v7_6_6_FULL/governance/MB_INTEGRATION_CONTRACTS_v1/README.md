# MB_INTEGRATION_CONTRACTS_v1

Canonical integration contracts for MetaBlooms OS.
