# Learning Integration — Tool-on-Demand Doctrine (LID-2.0)

Status: active
Created: 2025-12-29T13:13:08.156260+00:00
Scope: all MetaBlooms engines, especially Lesson Builders, Visual Pipelines, and Export Gates

## What was learned (source: clover mask / visual pipeline incident)

When an output quality dispute persists across >2 iterations, the bottleneck is usually:
- missing ground truth,
- missing instrumentation,
- or an underspecified representation.

In these cases, **the correct move is to build a small purpose-built tool** (Python or pure-HTML) that:
1) externalizes the ambiguous judgment into inspectable signals,
2) produces repeatable artifacts,
3) reduces further iteration cost to parameter tuning.

## Policy (P0)

### Trigger conditions (any one)
- repeated failure cycle: same issue persists across 2+ revisions
- "looks wrong" class feedback without a measurable proxy
- geometry / layout / parsing / extraction ambiguity
- any task where a 10–30 line tool would produce ground truth faster than chat iteration

### Required action
1) Create a tool OR propose a tool spec (for approval) immediately.
2) Tool must include:
   - explicit inputs/outputs
   - a runnable CLI (python tool) OR single-file HTML UI (no deps)
   - at least one validation check / invariant (even if crude)
3) Use the tool to generate the next artifact (do not continue blind edits).

### Approval rule
- If assumptions are *material* (affect semantics or grade-level intent), pause at a **Tool Proposal** and await approval.
- Otherwise, ship the tool and proceed.

## Canonical pattern

**REF → TRANSFORM → VALIDATE → EXPORT**

Examples:
- Visual shapes: reference image → rasterize/fill → downsample grid → gate checks → MASK_GRID export
- Text extraction: pdf/html → parse → normalize → schema validate → json report
- Lesson constraints: requirements → constraint compiler → static checks → lesson html

## Required artifacts when this doctrine is invoked
- Tool artifact under `/tools/` (python) or `/tools/html/` (pure html)
- A short SOP entry under `/sops/ToolOnDemand/`
- A DIFF note under `/docs/DIFF_*`

## Non-goals
- This does not mandate heavyweight frameworks.
- This does not allow hidden dependencies. Prefer stdlib; when not possible, document it.

