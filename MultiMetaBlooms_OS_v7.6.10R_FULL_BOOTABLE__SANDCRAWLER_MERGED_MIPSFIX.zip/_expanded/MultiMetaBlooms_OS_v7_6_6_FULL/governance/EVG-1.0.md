# Existence Verification Gate (EVG) — Doctrine

## Status
P0 Invariant — Mandatory, Fail-Closed

## Purpose
The Existence Verification Gate (EVG) prevents MetaBlooms from reinventing existing solutions by requiring external verification before promoting or locking any infrastructure-class design.

EVG applies to both new builds and major changes. It is promotion-blocking and export-blocking.

### External Justification (Sandcrawler-Verified Pattern)
Engineering and innovation workflows commonly require a systematic check of existing public work (often called a prior-art search or state-of-the-art review) before novelty claims are accepted. Verification workflows also use hard-stop checkpoints (for example, signoff-style verification in complex engineering pipelines) where progress is blocked until required checks are complete. EVG operationalizes these established patterns inside MetaBlooms by requiring an external Sandcrawler (`web.run`) pass and verifiable evidence before promotion.

---

## Provenance and Evidence Policy
MetaBlooms explicitly distinguishes between **external inspiration** and **external evidence**.

- **Inspiration**: talks, videos, informal demonstrations, practitioner workflows. These may seed intuition and may be acknowledged for provenance.
- **Evidence**: externally verifiable sources (papers, official documentation, engineering blogs, repositories) used to justify architectural or governance decisions.

Inspiration sources cannot satisfy EVG or Sandcrawler requirements.

---

## Trigger Conditions (Automatic)
EVG MUST trigger whenever a proposal, delta, or design touches any of the following domains:

- indexing
- retrieval / search
- memory systems
- scheduling / orchestration
- agents / sub-agents
- semantic understanding
- governance frameworks
- code intelligence / navigation
- autonomous execution

Triggering is non-optional and does not require user request.

---

## Required Actions
When EVG triggers, the system MUST:

1. **Classify the problem**
   - One-sentence problem statement
   - Trigger domain(s)

2. **Invoke Sandcrawler (web.run)**
   - External search for existing tools, systems, or papers
   - Minimum: 3 independent sources

3. **Produce an Existing Solutions Brief (ESB)**
   The ESB MUST include:
   - `existing_solution_found`: true/false
   - Named exemplars (tools/systems/papers)
   - Patterns abstracted
   - Explicit statement: "patterns abstracted, products not adopted"

4. **Assess novelty**
   - `novelty_claim_required`: true/false
   - If true, specify the genuinely new contribution

---

## Promotion Rules
- No artifact touching a triggered domain may be promoted to P0 or P1 without a completed EVG record.
- EVG is promotion-blocking and export-blocking.
- Absence of EVG output results in FAIL-CLOSED behavior.

---

## Ledgering
Each EVG run MUST be recorded in a Sandcrawler Value Ledger entry with:
- problem_id
- trigger_domain
- sandcrawler_run_id
- value_delta
- evidence_refs
- promotion_decision

---

## Enforcement
EVG enforcement is owned by:
- Governance Kernel
- Export Gate
- Spec Promotion Pipeline

Any export attempt lacking required EVG artifacts SHALL be rejected.

---

## External Inspiration (Recorded, Non-Evidentiary)
- Web Dev Cody (YouTube): practitioner workflows around agent-assisted navigation of large codebases, ad-hoc memory augmentation, and LLM-based "live documentation" techniques. These materials informed early intuition but do not count as verification.
