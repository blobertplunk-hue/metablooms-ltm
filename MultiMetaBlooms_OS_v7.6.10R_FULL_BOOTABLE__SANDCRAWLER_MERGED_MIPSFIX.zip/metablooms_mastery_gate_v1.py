"""
MetaBlooms Mastery Gate v1

Purpose:
- Enforce governance rules around mastery claims.
- HARD RULE (DEMO DATA RULE): If record.data_class == "DEMO", it may be stored, but it MUST NOT
  be used to satisfy mastery or promotion gates.
- Provide a simple API that can be called by WQI queries and by higher-level engines.

This module does NOT change the ledger (append-only). It only evaluates.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class GateResult:
    decision: str            # "PASS" | "HOLD" | "BLOCK"
    reason: str
    next_required: Optional[str] = None


def is_demo(record: Dict[str, Any]) -> bool:
    return str(record.get("data_class", "")).upper() == "DEMO"


def mastery_gate(record: Dict[str, Any]) -> GateResult:
    """
    Minimal mastery gate:
    - BLOCK if DEMO
    - HOLD if AIL decision isn't PASS
    - PASS otherwise

    Note: This is intentionally conservative and can be strengthened later (e.g., require transfer probes).
    """
    if is_demo(record):
        return GateResult(
            decision="BLOCK",
            reason="DEMO data cannot satisfy mastery or promotion gates.",
            next_required="Provide a REAL (non-demo) source excerpt and re-run MER with transfer probes."
        )

    ail = (record.get("ail") or {})
    if str(ail.get("decision", "")).upper() != "PASS":
        return GateResult(
            decision="HOLD",
            reason=f"AIL decision is {ail.get('decision')}; mastery requires PASS.",
            next_required=str(ail.get("next_required") or "Repair and re-run.")
        )

    return GateResult(decision="PASS", reason="Record is non-demo and AIL=PASS.")


def batch_mastery_gate(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Evaluate many records and return summary counts and per-run results.
    """
    results = []
    counts = {"PASS": 0, "HOLD": 0, "BLOCK": 0}
    for r in records:
        gr = mastery_gate(r)
        counts[gr.decision] += 1
        results.append({"run_id": r.get("run_id"), "decision": gr.decision, "reason": gr.reason, "next_required": gr.next_required})
    return {"counts": counts, "results": results}
