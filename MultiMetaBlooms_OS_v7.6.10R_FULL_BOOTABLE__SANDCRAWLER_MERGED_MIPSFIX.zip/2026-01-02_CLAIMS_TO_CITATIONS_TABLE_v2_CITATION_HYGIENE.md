# 2026-01-02_CLAIMS_TO_CITATIONS_TABLE_v2_CITATION_HYGIENE
## Claims → Citations Table (Publication Hardening, Citation-Hygiene Compliant)

**Purpose:** Bind public-facing claims from the execution-gap brief to external evidence using standard citation hygiene (URLs / DOI links), plus TEKS anchors.

**TEKS anchor note:** Anchors reference the provided Texas ELAR TEKS English I–IV PDF using section IDs (e.g., §110.36(b)(1)–(2)) and approximate PDF viewer page numbers (English I intro p.1; English II p.6; English III p.11; English IV p.16).

---

## Claims Table

| Claim ID | Public Claim (Neutral) | TEKS Anchor (Section/Page) | Evidence (Publication-Style) | Notes / Tightening |
|---|---|---|---|---|
| C1 | Background knowledge (prior knowledge/schema) materially affects reading comprehension. | English I intro: §110.36(b)(1)–(2), PDF p.1 | Smith, R., Snow, P., Serry, T., & Hammond, L. (2021). *The Role of Background Knowledge in Reading Comprehension: A Critical Review.* *Reading Psychology.* https://doi.org/10.1080/02702711.2021.1888348 | Keep “materially affects.” Avoid numeric effect sizes unless extracted and verified from the paper. |
| C2 | Writing about text and teaching writing can improve reading outcomes (including comprehension). | English I integrated strands, PDF p.1 | Graham, S., & Hebert, M. A. (2010). *Writing to Read: Evidence for How Writing Can Improve Reading.* Carnegie Corporation / Alliance for Excellent Education (PDF). https://media.carnegie.org/filer_public/9d/e2/9de20604-a055-42da-bc00-77da949b29d7/ccny_report_2010_writing.pdf ; LINCS TEAL summary: https://lincs.ed.gov/state-resources/federal-initiatives/teal/publications/writing-read | Phrase as “evidence indicates,” not “guarantees.” |
| C3 | Transfer of comprehension strategies across topics/genres is conditional and benefits from explicit instruction and assessment. | English I intro: §110.36(b)(1)–(2), PDF p.1 | (Needs one primary transfer source locked for v2.1) For coherence with v1 memo, use NAS transfer framing from NASEM and/or ERIC-hosted transfer-in-reading work; **to be locked with a primary URL** in the next hardening pass. | Marked as *partially supported* until a primary transfer source URL is locked. |
| C4 | Instructional system coherence (alignment across curriculum, PD, assessment) is a meaningful system property used to improve implementation quality. | English I–IV intros, PDF pp.1/6/11/16 | RAND (2023) *The Improving Instructional System Coherence Toolkit* (page + PDF): https://www.rand.org/pubs/tools/TLA2168-1.html ; https://www.rand.org/content/dam/rand/pubs/tools/TLA2100/TLA2168-1/RAND_TLA2168-1.pdf | Avoid causal language unless design supports it; “used to improve,” “associated with,” “linked to.” |

---

## Evidence Gaps (Next PLAN Step)
1. Lock a **primary transfer** source URL for Claim C3 (no indirect summaries).
2. Add a “claims→citations→brief paragraphs” mapping so each brief paragraph is citation-backed.
3. Optional: extract ≤25-word quotable excerpts for press-ready use (copyright-safe).
