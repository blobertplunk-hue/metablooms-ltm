#!/usr/bin/env python3
"""MetaBlooms System Index Generator.

Goal
- Produce a deterministic, machine-readable index that enables O(1) resolution of key system paths
  and fast search/triage without ad-hoc filesystem walks.

Design constraints
- Deterministic output (stable ordering)
- Safe to run repeatedly
- No external dependencies

Output
- Writes ROOT/SYSTEM_INDEX.json

This generator is intentionally conservative: it indexes *what exists* and does not infer meaning
beyond a small set of canonical boot/runtime artifacts.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parent

CANONICAL_FILES = {
    "BOOT_METABLOOMS.py": {"role": "boot_entrypoint"},
    "RUN_METABLOOMS.py": {"role": "runtime_entrypoint"},
    "boot_manifest.json": {"role": "boot_manifest"},
    "metablooms_core_doctrine.md": {"role": "doctrine"},
}

SKIP_DIRS = {".git", "__pycache__"}

# A small set of patterns to help build a useful index without requiring full semantic parsing.
TAG_PATTERNS: List[Tuple[str, str]] = [
    (r"^logs/", "logs"),
    (r"\.ndjson$", "ndjson"),
    (r"\.json$", "json"),
    (r"\.md$", "markdown"),
    (r"\.zip$", "zip"),
    (r"^202\d-\d{2}-\d{2}_", "dated_artifact"),
]


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def walk_files(root: Path) -> List[Path]:
    out: List[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        # deterministic traversal
        dirnames[:] = sorted([d for d in dirnames if d not in SKIP_DIRS])
        filenames = sorted(filenames)
        for fn in filenames:
            out.append(Path(dirpath) / fn)
    return out


def build_index() -> Dict:
    # Resolve manifest-derived paths where possible (best-effort; gate will enforce correctness).
    manifest = None
    mp = ROOT / "boot_manifest.json"
    if mp.exists():
        try:
            manifest = json.loads(mp.read_text(encoding="utf-8"))
        except Exception:
            manifest = None

    files = walk_files(ROOT)
    rel_files = []
    by_filename: Dict[str, List[str]] = {}

    for p in files:
        rel = p.relative_to(ROOT).as_posix()
        # Do not index the index itself while it is being created (avoids churn loops).
        if rel == "SYSTEM_INDEX.json":
            continue
        if p.is_dir():
            continue
        try:
            st = p.stat()
        except Exception:
            continue

        tags: List[str] = []
        for pat, tag in TAG_PATTERNS:
            if re.search(pat, rel):
                tags.append(tag)

        rec = {
            "path": rel,
            "size": st.st_size,
            "sha256": sha256_file(p),
            "tags": sorted(set(tags)),
        }

        # Canonical roles
        if rel in CANONICAL_FILES:
            rec["role"] = CANONICAL_FILES[rel]["role"]

        rel_files.append(rec)
        by_filename.setdefault(p.name, []).append(rel)

    # Deterministic ordering
    rel_files.sort(key=lambda r: r["path"])
    for k in sorted(by_filename.keys()):
        by_filename[k].sort()

    idx = {
        "schema": "metablooms.system_index.v1",
        "bundle": (manifest or {}).get("metadata", {}).get("bundle_name", "MultiMetaBlooms"),
        "version": (manifest or {}).get("version", "unknown"),
        "root": ".",
        "entrypoints": {
            "boot": "BOOT_METABLOOMS.py",
            "runtime": "RUN_METABLOOMS.py",
        },
        "manifests": {
            "boot_manifest": "boot_manifest.json",
        },
        "doctrine": (manifest or {}).get("doctrine", ["metablooms_core_doctrine.md"]),
        "preflight": (manifest or {}).get("preflight", []),
        "lookup": {
            "by_filename": by_filename,
        },
        "inventory": rel_files,
    }
    return idx


def write_index(out_path: Path | None = None) -> Path:
    out_path = out_path or (ROOT / "SYSTEM_INDEX.json")
    idx = build_index()
    tmp = out_path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(idx, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(out_path)
    return out_path


def main() -> None:
    p = write_index()
    print(f"SYSTEM_INDEX_WRITTEN: {p}")


if __name__ == "__main__":
    main()
