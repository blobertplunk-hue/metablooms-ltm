# Oppositional Audit Report (Build) — Mastery Router Wiring v1

## Scope
Audit the *frozen* mastery routing + mastery gate enforcement:
- DEMO exclusion
- TRANSFER requirement (near + mid)
- Non-bypassability (router dispatch order)
- Schema mismatch fail-close behavior

## Adversarial Questions (Attack Surface)
1. **Bypass risk:** Can any other router command path return “mastery-like” answers without invoking the mastery hook?
2. **DEMO laundering:** Can a record be shaped to appear TRANSFER while actually being DEMO (e.g., missing `data_class`, alternate field, casing)?
3. **Transfer spoofing:** Can `transfer_probe` be set to `True` without any audit trail (no provenance/evidence chain)?
4. **AIL spoofing:** Can `ail.decision` be set to PASS while the underlying AIL evidence is absent?
5. **Schema truncation:** If schema fields are omitted, does the system ever “assume ok” or degrade to PASS?
6. **Dispatch ordering regression:** If the router changes, can mastery hook be skipped?
7. **Error-path leakage:** Do exceptions default to permissive behavior (PASS) rather than HOLD/BLOCK?
8. **Record injection:** Can attacker-controlled JSON cause code execution, path traversal, or import hijacking?

## Findings (Fail-Close Evaluation)
### F1 — DEMO exclusion robustness
- Expected: Any DEMO (or missing/unknown classification) must **BLOCK**.
- Current risk: if `data_class` is absent or malformed and treated as “not DEMO”, laundering is possible.
- Required fix: enforce `data_class` presence + whitelist {TRANSFER, REAL} (or explicit enumerations).

### F2 — Transfer spoofing risk
- Expected: `transfer_probe` must have provenance (hash, run_id, evaluator signature) or default to **HOLD**.
- Current risk: naive boolean fields are spoofable.
- Required fix: require `transfer_probe.provenance` block with at explained minimal fields.

### F3 — AIL spoofing risk
- Expected: `ail` must include a reference to the AIL run artifact or evidence chain pointer.
- Current risk: `ail.decision=PASS` alone is spoofable.
- Required fix: require `ail.provenance` pointer; else HOLD.

### F4 — Dispatch bypass risk
- Expected: any mastery-like decision must flow through mastery hook.
- Required fix: add a router-level rule: “mastery decisions are only emitted by mastery hook”; deny elsewhere.

### F5 — Exception fail-open risk
- Expected: any exception must produce **HOLD/BLOCK**, never PASS.
- Required fix: wrap the handler and enforce conservative default.

## Required Repairs (Append-only, no gate weakening)
1. **Record schema whitelist**: require `data_class` ∈ {TRANSFER, REAL}; missing/unknown → BLOCK.
2. **Provenance required**:
   - `transfer_probe.provenance` minimal fields (run_id, timestamp, evaluator, source_ref/hash)
   - `ail.provenance` minimal fields (run_id, timestamp, evaluator, source_ref/hash)
3. **Router enforcement**: only mastery hook can return mastery decisions; deny similar outputs elsewhere.
4. **Fail-closed exception wrapper** around mastery handler.

## Verification Checklist (Post-repair)
- DEMO laundering attempt → BLOCK
- TRANSFER spoof (no provenance) → HOLD
- AIL spoof (no provenance) → HOLD
- Any handler exception → HOLD/BLOCK
- No other router route emits `mastery_decision`

## Decision Trace
**AUDIT RESULT:** HOLD — The wiring is functionally correct, but *provenance requirements* must be enforced to prevent spoofing.
