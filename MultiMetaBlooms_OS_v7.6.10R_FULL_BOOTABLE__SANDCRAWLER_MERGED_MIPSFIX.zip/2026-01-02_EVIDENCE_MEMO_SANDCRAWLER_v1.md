# 2026-01-02_EVIDENCE_MEMO_SANDCRAWLER_v1
## Evidence Memo (Sandcrawler/web research) — Supporting the Execution-Gap Framing

**Goal:** Provide external evidence that supports the *execution-gap* claims used in the administrative brief: schema/background knowledge importance, writing-to-read linkage, transfer conditionality, and vertical coherence/alignment.

---

## A) Background Knowledge (Schema) and Reading Comprehension

- A critical review specifically examining background knowledge influence on reading comprehension in primary-aged children reports a meaningful relationship between background knowledge and comprehension outcomes. citeturn0search0
- A synthesis-style discussion from Harvard’s Usable Knowledge describes how building background knowledge can improve reading comprehension and highlights background knowledge as a lever for comprehension and transfer. citeturn0search23

**Supports:** The “Schema Gap” finding in the brief (systems must build/verify background knowledge assumptions).

---

## B) Writing-to-Read (Writing Improves Reading)

- The Carnegie Corporation report “Writing to Read” (Graham & Hebert) summarizes meta-analytic evidence that writing about material read and writing instruction can improve reading comprehension (and related reading outcomes). citeturn0search14
- The U.S. Department of Education LINCS/TEAL “Writing to Read” resource similarly summarizes evidence-based writing practices associated with improved reading skills and comprehension. citeturn0search19

**Supports:** The “Causality Gap” / “Evidence Gap” repair principle: pair reading and writing as mastery evidence and as a comprehension lever.

---

## C) Transfer Is Conditional and Must Be Assessed

- An ERIC-hosted paper on teaching/assessing for transfer in reading comprehension notes that successful transfer to other settings is likely to require specific cognitive processes and should be addressed deliberately. citeturn0search15
- The National Academies text on teaching and assessing for transfer emphasizes that complex performance must be assessed (not only developed) within content domains, consistent with transfer being non-automatic. citeturn0search20

**Supports:** The “Transfer Gap” framing: do not assume transfer; require transfer evidence across genres/domains.

---

## D) Vertical Coherence / Alignment and System Coherence

- RAND describes coherence in K–12 instructional systems and suggests ways forward, supporting the view that coherence/alignment is a meaningful system attribute. citeturn0search26
- A RISE working paper quantifies (in)coherence between standards, examinations, and instruction and associates coherence with increased learning, illustrating how misalignment undermines outcomes. citeturn0search22
- NCTM-oriented scholarship on “learning trajectories” explicitly frames vertical coherence as a design goal in PK–12 systems (conceptual support for prerequisite chains and progression). citeturn0search3

**Supports:** The “Vertical Coherence Gap” repair principle: define prerequisite chains and verify them before progression.

---

## Summary of What This Evidence Justifies
1. **Schema matters** for comprehension; implementation must build/verify background knowledge assumptions. citeturn0search0turn0search23  
2. **Writing supports reading**; writing tasks can function as both leverage and evidence of comprehension. citeturn0search14turn0search19  
3. **Transfer is not automatic** and should be deliberately assessed. citeturn0search15turn0search20  
4. **System coherence/alignment** is a measurable property with learning consequences; vertical coherence concepts support prerequisite mapping. citeturn0search26turn0search22turn0search3  

---

## Limits / Scope Notes
- This memo supports the *direction* of the execution-gap framing. It does not, by itself, validate any specific curriculum or program as “the solution.”
- For publication, each claim in the admin brief should be mapped to a citation (claims→citations table) and reviewed for overreach.

