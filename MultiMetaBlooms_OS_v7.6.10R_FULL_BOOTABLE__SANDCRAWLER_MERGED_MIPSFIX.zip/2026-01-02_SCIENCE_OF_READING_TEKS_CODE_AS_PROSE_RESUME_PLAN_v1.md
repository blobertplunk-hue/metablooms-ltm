# Resume Plan v1 — Science of Reading + TEKS Code‑as‑Prose (MultiMetaBlooms)

## What changed (why this is now feasible)
The OS is now **index-first**:
- Canonical structural index + derived views
- Query router with **intent routing** + aliases + templates
- Agentic decomposition: specialized “workers” operate on bounded reading lists (not free-roaming the tree)

This eliminates the previous bottleneck: repeated filesystem rediscovery and context bloat.

## Why responses sometimes come “like lightning”
When I respond quickly inline now, it’s because the work is **lookup + confirm** rather than **search + rediscover**:
- I can resolve “where is X?” by reading the precomputed index JSONs in milliseconds.
- I can route to the right subsystem without scanning directories.
- I can keep the main thread lean because “workers” return compressed findings.

This is deterministic speed from **precomputation + routing**, not guesswork.

---

## Goal
Build a **Science of Reading + TEKS-aligned** instructional layer that:
1) Treats the OS as a readable corpus (**Code-as-Prose**), and  
2) Produces classroom-ready artifacts and mappings (**Prose-as-Code**) that are auditable, versioned, and reproducible.

---

## Deliverables (what “done” means)
### A. Canonical Knowledge Map
A machine-readable map that links:
- TEKS standard → skill/construct → instructional routine → OS artifacts (files, generators, templates)

### B. Reader’s Guides (Code-as-Prose)
Human-readable guides per subsystem/topic, with citations to exact OS paths:
- “Where the literacy scaffolds live”
- “How comprehension routines are generated”
- “How bilingual supports are applied”
- “How assessment items are formed”

### C. Classroom Artifacts (Prose-as-Code outputs)
- CO/LO posters (student-friendly)
- I‑Do/We‑Do/You‑Do lesson skeletons
- practice sets
- checks for understanding
- bilingual scaffolds (English/Spanish)

### D. Governance Requirements
- **EVG** triggers for any new indexing/retrieval/agent mechanisms
- **Sandcrawler** required for external claims about literacy science
- Inspiration vs evidence recorded (provenance)

---

## System Components to Implement

### 1) Instructional Prose Engine (IPE)
**Purpose:** generate prose explanations + teacher materials from code modules, and produce structured maps back to OS paths.

**Inputs:**
- TEKS targets (codes + decomposed skills)
- SoR constructs (phonemic awareness, phonics, fluency, vocab, comprehension)
- audience (teacher / student / bilingual)
- constraints (time, materials, differentiation)

**Outputs:**
- `READERS_GUIDE.md` (human)
- `KNOWLEDGE_MAP.json` (machine)
- `LESSON_PACK.json` (machine)
- `LESSON_PACK.md/pdf` (human)

### 2) TEKS + SoR Crosswalk Layer
A normalized representation:
- TEKS → reading domain → SoR construct(s) → routine archetypes

### 3) Agentic Learning Sweep Orchestrator (ALEO)
Uses the index/router to create bounded reading assignments:
- each agent reads a scoped set of OS files
- returns extracted facts + citations
- orchestrator merges into canonical artifacts

---

## Execution Plan (phased, deterministic)

### Phase 1 — Inventory & Scope Lock
1. Generate a **TEKS target list** (start with Grade 3 ELA: comprehension, vocabulary, author’s purpose, central idea).
2. Define SoR construct tags and routine archetypes.
3. Produce `TEKS_SOR_CROSSWALK_v0.json`.

**Exit criteria:** crosswalk exists and is versioned.

### Phase 2 — OS Anchoring
1. Use query router templates to locate:
   - existing literacy routines
   - any prior “code-as-prose” modules
   - lesson generators / artifact builders
2. Populate `OS_ANCHORS.json` with paths and roles.

**Exit criteria:** all anchor paths resolve via index (no crawling).

### Phase 3 — Build IPE v1
1. Implement schema + validators for:
   - lesson pack
   - readers guide sections
   - map entries
2. Implement a minimal generator that can emit:
   - one TEKS-aligned lesson skeleton
   - bilingual scaffold
   - citations to OS anchors

**Exit criteria:** one end-to-end TEKS lesson generated deterministically.

### Phase 4 — Expand + Harden
- Add more TEKS standards
- Add assessment items + rubrics
- Add differentiation bundles
- Add evidence citations policy enforcement (EVG/Sandcrawler)

**Exit criteria:** multi-standard units, reproducible exports, stable IDs.

---

## Canonical Data Contracts (summary)
See the attached JSON schema file:
- 2026-01-02_SCIENCE_OF_READING_TEKS_CAP_PIPELINE_SCHEMA_v1.json

---

## Immediate Next Actions (recommended)
1) Create `TEKS_SOR_CROSSWALK_v0.json` (initial draft)  
2) Create `OS_ANCHORS_v0.json` via query router  
3) Implement IPE v1 skeleton + validator stubs  
4) Run an agentic learning sweep to fill the first Reader’s Guide

---

## Assumptions / [ASSUMED] gaps
- TEKS text/codes will be provided or imported from your existing OS stores (no web claims unless Sandcrawler is invoked).
- Bilingual scaffolds remain English/Spanish.
- Grade focus starts at Grade 3 unless redirected.
