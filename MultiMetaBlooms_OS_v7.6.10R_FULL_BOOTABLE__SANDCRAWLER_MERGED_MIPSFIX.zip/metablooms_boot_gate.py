#!/usr/bin/env python3
"""BootGate: enforce 'bootable + indexed + routable' before declaring boot success.

Fail-closed:
- SYSTEM_INDEX.json must exist and be non-empty.
  - Supports both the legacy indexer schema (file_count) and the canonical
    metablooms.system_index.v1 schema (inventory).
- query_router.py must exist
 - GULP.md must exist
 - Gap governance doctrine + modules must exist
"""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def fail(msg: str) -> None:
    raise SystemExit(f"BOOTGATE_FAIL: {msg}")

def main() -> None:
    idx_path = ROOT / "SYSTEM_INDEX.json"
    if not idx_path.exists():
        fail("SYSTEM_INDEX.json missing")
    try:
        idx = json.loads(idx_path.read_text(encoding="utf-8"))
    except Exception as e:
        fail(f"SYSTEM_INDEX.json unreadable: {e}")
    schema = str(idx.get("schema", ""))
    if schema == "metablooms.system_index.v1":
        if len(idx.get("inventory", []) or []) <= 0:
            fail("SYSTEM_INDEX.json inventory is empty")
    else:
        # Legacy schema fallback
        if int(idx.get("file_count", 0)) <= 0 and len(idx.get("files", []) or []) <= 0:
            fail("SYSTEM_INDEX.json appears empty")
    if not (ROOT / "query_router.py").exists():
        fail("query_router.py missing")
    if not (ROOT / "GULP.md").exists():
        fail("GULP.md marker missing")
    if not (ROOT / "metablooms" / "governance" / "DOCTRINE_GAP_GOVERNANCE_P0.md").exists():
        fail("Gap governance doctrine missing")
    if not (ROOT / "metablooms" / "governance" / "gapfinder.py").exists():
        fail("gapfinder missing")
    if not (ROOT / "metablooms" / "governance" / "gapfiller.py").exists():
        fail("gapfiller missing")
    print("BOOTGATE_OK")

if __name__ == "__main__":
    main()
