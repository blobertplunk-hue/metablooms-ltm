# 2026-01-02_CLAIMS_TO_CITATIONS_TABLE_v3_LOCKED_TRANSFER
## Claims → Citations Table (Publication Hardening, Citation-Hygiene Compliant)

**Purpose:** Bind public-facing claims from the execution-gap brief to external evidence using standard citation hygiene (URLs / DOI links), plus TEKS anchors.

**TEKS anchor note:** Anchors reference the provided Texas ELAR TEKS English I–IV PDF using section IDs (e.g., §110.36(b)(1)–(2)) and approximate PDF viewer page numbers (English I intro p.1; English II p.6; English III p.11; English IV p.16).

---

## Claims Table

| Claim ID | Public Claim (Neutral) | TEKS Anchor (Section/Page) | Evidence (Publication-Style) | Notes / Tightening |
|---|---|---|---|---|
| C1 | Background knowledge (prior knowledge/schema) materially affects reading comprehension. | English I intro: §110.36(b)(1)–(2), PDF p.1 | Smith, R., Snow, P., Serry, T., & Hammond, L. (2021). *The Role of Background Knowledge in Reading Comprehension: A Critical Review.* *Reading Psychology.* https://doi.org/10.1080/02702711.2021.1888348 | Keep “materially affects.” Avoid numeric effect sizes unless extracted and verified from the paper. |
| C2 | Writing about text and teaching writing can improve reading outcomes (including comprehension). | English I integrated strands, PDF p.1 | Graham, S., & Hebert, M. A. (2010). *Writing to Read: Evidence for How Writing Can Improve Reading.* Carnegie Corporation / Alliance for Excellent Education (PDF). https://media.carnegie.org/filer_public/9d/e2/9de20604-a055-42da-bc00-77da949b29d7/ccny_report_2010_writing.pdf ; LINCS TEAL summary: https://lincs.ed.gov/state-resources/federal-initiatives/teal/teaching-reading/teal-center-fact-sheet-writing-to-read | Use Carnegie PDF for primary evidence; LINCS is a practitioner summary. |
| C3 | Transfer of comprehension (near/mid/far) is conditional; it can be measured and improved with explicit instruction and transfer-aware assessment tasks. | English I intro: §110.36(b)(1)–(2), PDF p.1 | Patton, S. A., et al. (2022). *Is Teaching for Transfer Important?* (ERIC PDF) https://files.eric.ed.gov/fulltext/ED619792.pdf ; (Journal DOI landing) https://journals.sagepub.com/doi/10.1111/ldrp.12276 | Cite the ERIC PDF for accessible primary text; use the DOI as canonical identifier. |
| C4 | Instructional system coherence (alignment across curriculum, PD, assessment) is a meaningful system property used to improve implementation quality. | English I–IV intros, PDF pp.1/6/11/16 | RAND (2023) *The Improving Instructional System Coherence Toolkit* (page + PDF): https://www.rand.org/pubs/tools/TLA2168-1.html ; https://www.rand.org/content/dam/rand/pubs/tools/TLA2100/TLA2168-1/RAND_TLA2168-1.pdf | Avoid causal language unless design supports it; “used to strengthen,” “associated with,” “enables coordination.” |
| C5 | Explicit instruction and structured practice with feedback are supported by the Science of Reading literature as beneficial. | English I intro: §110.36(b)(1)–(2), PDF p.1 | Vaughn, S., et al. (2021). *Explicit Instruction as the Essential Tool for Executing the Science of Reading.* (Open-access) https://pmc.ncbi.nlm.nih.gov/articles/PMC9004595/ | Use this to justify “explicit, modeled, practiced, reviewed.” |

---

## Evidence Fail-Close Status
- **Publishable:** C1, C2, C3, C4, C5 (primary sources linked)
- **Remaining optional hardening:** add short, copyright-safe quotable excerpts (≤25 words) for press use.

