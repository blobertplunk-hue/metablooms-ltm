#!/usr/bin/env python3
"""MetaBlooms smoke test (fail-closed, minimal)."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def fail(msg: str) -> None:
    raise SystemExit(f"SMOKE_TEST_FAIL: {msg}")

def main() -> None:
    mp = ROOT / "boot_manifest.json"
    if not mp.exists():
        fail("boot_manifest.json missing")
    try:
        m = json.loads(mp.read_text(encoding="utf-8"))
    except Exception as e:
        fail(f"boot_manifest.json unreadable: {e}")

    if m.get("entrypoint") != "BOOT_METABLOOMS.py":
        fail(f"entrypoint mismatch: {m.get('entrypoint')!r}")

    for rel in m.get("doctrine", []):
        if not (ROOT / rel).exists():
            fail(f"missing doctrine: {rel}")

    for rel in m.get("preflight", []):
        if not (ROOT / rel).exists():
            fail(f"missing preflight: {rel}")

    # Sanity: payload must include at least one non-boot artifact
    boot_set = {"BOOT_METABLOOMS.py","boot_manifest.json","metablooms_core_doctrine.md","metablooms_smoke_test.py","RUN_METABLOOMS.py"}
    others = [p for p in ROOT.iterdir() if p.is_file() and p.name not in boot_set]
    if not others:
        fail("payload empty")

    print("SMOKE_TEST_OK")

if __name__ == "__main__":
    main()
