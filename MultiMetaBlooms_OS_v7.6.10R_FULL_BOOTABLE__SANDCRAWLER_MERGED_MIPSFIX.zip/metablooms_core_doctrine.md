# MetaBlooms Core Doctrine (Boot Minimal)

## P0 Invariants (Boot)
1. **Fail-Closed Boot**: Missing manifest/doctrine/preflight => stop.
2. **Immutable Entrypoint**: `BOOT_METABLOOMS.py` is the canonical entrypoint filename.
3. **Manifest Authority**: `boot_manifest.json` is the machine-authoritative declaration.
4. **Deterministic Preflight**: Preflight scripts execute in-order; any failure aborts boot.

## Boot Contract
- Verify doctrine files exist/readable.
- Run preflight scripts (Python) in-order.
- Transfer control to `RUN_METABLOOMS.py`.

## Bundle
- Bundle: MultiMetaBlooms OS
- Version: 7.6.8
