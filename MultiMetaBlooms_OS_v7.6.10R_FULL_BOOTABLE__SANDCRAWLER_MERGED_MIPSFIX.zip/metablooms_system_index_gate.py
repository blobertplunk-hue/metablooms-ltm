#!/usr/bin/env python3
"""MetaBlooms System Index Gate (fail-closed preflight).

This gate fixes a specific failure mode:
- "Boot succeeded but I can't instantly resolve where things are." ...

Behavior
1) Validate existing SYSTEM_INDEX.json (fast path).
2) If missing or corrupt, regenerate deterministically using metablooms_system_index.py.
3) Validate minimum required fields and entrypoints.
4) Fail-closed on any deviation.

This script is allowed to write SYSTEM_INDEX.json and append to logs/boot_log.ndjson.
"""

from __future__ import annotations

import datetime
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def fail(msg: str) -> None:
    raise SystemExit(f"SYSTEM_INDEX_GATE_FAIL: {msg}")


def _log(event: str, **fields) -> None:
    try:
        lp = ROOT / "logs" / "boot_log.ndjson"
        lp.parent.mkdir(exist_ok=True)
        rec = {
            "ts": datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z",
            "event": event,
            **fields,
        }
        lp.open("a", encoding="utf-8").write(json.dumps(rec) + "\n")
    except Exception:
        # logging must not block fail-closed logic
        pass


def main() -> None:
    out_path = ROOT / "SYSTEM_INDEX.json"

    # 1) Fast-path validate existing index; only regenerate if missing/corrupt.
    idx = None
    if out_path.exists():
        try:
            idx = json.loads(out_path.read_text(encoding="utf-8"))
        except Exception:
            idx = None

    if idx is None:
        try:
            import metablooms_system_index as gen
        except Exception as e:
            fail(f"cannot import generator: {e}")

        try:
            gen.write_index(out_path)
        except Exception as e:
            fail(f"generation failed: {e}")

        if not out_path.exists():
            fail("SYSTEM_INDEX.json not written")

        try:
            idx = json.loads(out_path.read_text(encoding="utf-8"))
        except Exception as e:
            fail(f"index unreadable after generation: {e}")

    required_top = ["schema", "bundle", "version", "entrypoints", "lookup", "inventory"]
    for k in required_top:
        if k not in idx:
            fail(f"missing top-level field: {k}")

    if idx.get("schema") != "metablooms.system_index.v1":
        fail(f"schema mismatch: {idx.get('schema')!r}")

    ep = idx.get("entrypoints", {})
    if ep.get("boot") != "BOOT_METABLOOMS.py":
        fail(f"entrypoints.boot mismatch: {ep.get('boot')!r}")
    if ep.get("runtime") != "RUN_METABLOOMS.py":
        fail(f"entrypoints.runtime mismatch: {ep.get('runtime')!r}")

    # Ensure canonical files are present in inventory (fast sanity)
    inv_paths = {rec.get("path") for rec in idx.get("inventory", []) if isinstance(rec, dict)}
    for must in ["BOOT_METABLOOMS.py", "RUN_METABLOOMS.py", "boot_manifest.json", "metablooms_core_doctrine.md"]:
        if must not in inv_paths:
            fail(f"inventory missing required path: {must}")

    _log(
        "system_index_ok",
        schema=idx.get("schema"),
        inventory_count=len(idx.get("inventory", [])),
    )

    print("SYSTEM_INDEX_OK")


if __name__ == "__main__":
    main()
