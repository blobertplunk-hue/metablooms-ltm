# EVG Extension v1 — Mandatory Oppositional Audit Gate

## Status
Canonical. Fail-closed.

## Summary
Adds a **non-bypassable Oppositional Auditor Gate** to the Evidence Validation Gate (EVG).

## Trigger Conditions
This gate MUST execute when any of the following are true:
- Canonical promotion requested
- Doctrine/spec changes
- New engines, agents, orchestration, indexing, routing
- Educational frameworks (TEKS, Science of Reading)
- Full OS export

## Gate Logic
1. Check for Oppositional Audit Report
2. Verify verdict ∈ {PASS, CONDITIONAL_PASS}
3. If CONDITIONAL_PASS:
   - All blocking items must be resolved
   - Re-audit required
4. If FAIL or missing report → **HALT**

## Enforcement
- No manual override
- No chat-based justification
- Only artifact-level resolution

## Outputs
- Human-readable audit report (md)
- Machine-readable audit record (json)
