#!/usr/bin/env python3
"""EditorialGovernanceGate: ensure editorial governance doctrine + tests are present and parseable.

Fail-closed:
- governance doctrine must exist
- evidence schema must parse and be JSON-schema-ish
- regression tests must parse and contain required invariant ids
- boot_manifest must include this gate in preflight list (self-consistency check)
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

REQUIRED_TEST_IDS = [
  "T001","T002","T003","T004","T005","T006","T007","T008","T009","T010"
]

def fail(msg: str) -> None:
    raise SystemExit(f"EDITORIALGATE_FAIL: {msg}")

def main() -> None:
    doctrine = ROOT / "metablooms" / "governance" / "DOCTRINE_EDITORIAL_GOVERNANCE_P0.md"
    if not doctrine.exists():
        fail("doctrine missing (DOCTRINE_EDITORIAL_GOVERNANCE_P0.md)")

    schema_p = ROOT / "metablooms" / "governance" / "EDITORIAL_EVIDENCE_SCHEMA.json"
    if not schema_p.exists():
        fail("evidence schema missing (EDITORIAL_EVIDENCE_SCHEMA.json)")
    try:
        schema = json.loads(schema_p.read_text(encoding="utf-8"))
    except Exception as e:
        fail(f"evidence schema unreadable ({e})")
    if not isinstance(schema, dict) or schema.get("type") != "object":
        fail("evidence schema invalid (expected JSON Schema object)")

    tests_p = ROOT / "metablooms" / "governance" / "editorial" / "editorial_governance_tests.json"
    if not tests_p.exists():
        fail("tests missing (editorial_governance_tests.json)")
    try:
        tests = json.loads(tests_p.read_text(encoding="utf-8"))
    except Exception as e:
        fail(f"tests unreadable ({e})")

    # allow either list-of-tests or {"tests":[...]} shapes
    if isinstance(tests, dict) and "tests" in tests:
        tests_list = tests["tests"]
    else:
        tests_list = tests

    if not isinstance(tests_list, list) or not tests_list:
        fail("tests invalid (expected non-empty list)")

    ids=set()
    for t in tests_list:
        if isinstance(t, dict) and "id" in t:
            ids.add(str(t["id"]))
    missing=[i for i in REQUIRED_TEST_IDS if i not in ids]
    if missing:
        fail(f"tests missing invariant ids: {missing}")

    # Self-consistency: ensure this gate is in boot manifest preflight
    mp = ROOT / "boot_manifest.json"
    if not mp.exists():
        fail("boot manifest missing")
    m = json.loads(mp.read_text(encoding="utf-8"))
    preflight = m.get("preflight", [])
    if "metablooms_editorial_governance_gate.py" not in preflight:
        fail("boot manifest missing metablooms_editorial_governance_gate.py in preflight")

    print("EDITORIALGATE_OK")

if __name__ == "__main__":
    main()
