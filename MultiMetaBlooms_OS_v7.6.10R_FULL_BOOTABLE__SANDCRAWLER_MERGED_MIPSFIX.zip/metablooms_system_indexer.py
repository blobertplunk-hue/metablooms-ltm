#!/usr/bin/env python3
"""Generate SYSTEM_INDEX.json (deterministic, fail-closed friendly).

Indexes all files in bundle root and subdirectories, including _expanded, excluding
common transient paths. Produces stable relative paths and sha256.
"""
from __future__ import annotations
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parent
EXCLUDE_DIRS = {".git", "__pycache__"}
EXCLUDE_FILES = {"SYSTEM_INDEX.json"}  # regenerated

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> None:
    files=[]
    for p in sorted(ROOT.rglob("*")):
        if p.is_dir():
            if p.name in EXCLUDE_DIRS:
                continue
            continue
        rel = p.relative_to(ROOT).as_posix()
        if p.name in EXCLUDE_FILES:
            continue
        # skip huge binaries? none expected; still index
        files.append({
            "path": rel,
            "bytes": p.stat().st_size,
            "sha256": sha256(p),
        })
    out = {
        "schema": "metablooms.system_index.v1",
        "generated_utc": __import__("datetime").datetime.utcnow().isoformat() + "Z",
        "file_count": len(files),
        "files": files,
    }
    (ROOT / "SYSTEM_INDEX.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
