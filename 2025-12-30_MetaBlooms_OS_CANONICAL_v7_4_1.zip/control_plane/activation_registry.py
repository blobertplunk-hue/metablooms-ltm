# MetaBlooms Control Plane — Activation Registry (SB-6b+)
# Fail-closed: required subsystems must register ACTIVE during boot.
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional, List
import datetime, json, os

@dataclass
class ActivationRecord:
    name: str
    status: str  # ACTIVE / INACTIVE / ERROR
    detail: Dict[str, Any]
    timestamp_utc: str

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

class ActivationRegistry:
    def __init__(self) -> None:
        self._records: Dict[str, ActivationRecord] = {}

    def set_active(self, name: str, **detail: Any) -> None:
        self._records[name] = ActivationRecord(
            name=name,
            status="ACTIVE",
            detail=detail,
            timestamp_utc=datetime.datetime.utcnow().isoformat() + "Z",
        )

    def set_error(self, name: str, error: str, **detail: Any) -> None:
        d = {"error": error}
        d.update(detail)
        self._records[name] = ActivationRecord(
            name=name,
            status="ERROR",
            detail=d,
            timestamp_utc=datetime.datetime.utcnow().isoformat() + "Z",
        )

    def is_active(self, name: str) -> bool:
        r = self._records.get(name)
        return bool(r and r.status == "ACTIVE")

    def require_active(self, names: List[str]) -> None:
        missing = [n for n in names if not self.is_active(n)]
        if missing:
            raise RuntimeError(f"REQUIRED_SUBSYSTEMS_NOT_ACTIVE: {missing}")

    def to_json(self) -> str:
        return json.dumps({k: v.to_dict() for k, v in sorted(self._records.items())}, indent=2)

    def write_artifact(self, out_dir: str, filename: str = "activation_status.json") -> str:
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.to_json())
        return path
