from pathlib import Path
import json, time

def activate():
    ledger = Path('ledgers/chat_health.ndjson')
    ledger.parent.mkdir(parents=True, exist_ok=True)
    ledger.write_text(json.dumps({
        "ts": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        "health": "GREEN",
        "signals": [],
        "response": "NONE",
        "affected_systems": ["CHM"],
        "notes": "Initial CHM activation at boot"
    }) + "\n", encoding="utf-8")
    return True
