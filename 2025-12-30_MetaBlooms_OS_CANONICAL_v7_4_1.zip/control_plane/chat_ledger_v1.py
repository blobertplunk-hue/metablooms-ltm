import json, hashlib, datetime
from pathlib import Path

LEDGER = Path("/mnt/data/metablooms/ledgers/chat_ledger.jsonl")
TRANSCRIPTS = Path("/mnt/data/metablooms/transcripts")

def _utc():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def _ensure_session(session_id: str) -> Path:
    d = TRANSCRIPTS / session_id
    d.mkdir(parents=True, exist_ok=True)
    t = d / "TRANSCRIPT.md"
    if not t.exists():
        t.write_text(f"# MetaBlooms Chat Transcript\nsession_id: {session_id}\ncreated_utc: {_utc()}\n", encoding="utf-8")
    return t

def _next_turn_id(transcript_path: Path) -> str:
    txt = transcript_path.read_text(encoding="utf-8", errors="replace")
    turns = [ln.strip() for ln in txt.splitlines() if ln.strip().startswith("## t")]
    if not turns:
        return "t000001"
    last = turns[-1].split()[1]  # t000123
    n = int(last[1:]) + 1
    return f"t{n:06d}"

def append_turn(*, session_id: str, role: str, content: str, tags=None, links=None) -> dict:
    if role not in {"user","assistant","system","tool"}:
        raise ValueError("Invalid role")
    tags = tags or []
    links = links or {"deltas": [], "bundles": [], "receipts": []}

    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    TRANSCRIPTS.mkdir(parents=True, exist_ok=True)

    transcript = _ensure_session(session_id)
    turn_id = _next_turn_id(transcript)

    # Append to transcript (human)
    with transcript.open("a", encoding="utf-8") as f:
        f.write(f"\n## {turn_id}\n\n**role:** {role}\n\n{content}\n")

    # Append to ledger (machine)
    rec = {
        "schema": "MetaBlooms::ChatLedger::v1",
        "session_id": session_id,
        "turn_id": turn_id,
        "role": role,
        "created_utc": _utc(),
        "content_sha256": _sha(content),
        "content_len": len(content),
        "transcript_relpath": f"metablooms/transcripts/{session_id}/TRANSCRIPT.md#{turn_id}",
        "links": {
            "deltas": links.get("deltas", []),
            "bundles": links.get("bundles", []),
            "receipts": links.get("receipts", []),
        },
        "tags": tags,
        "redaction": {"applied": False, "notes": ""},
    }
    with LEDGER.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, sort_keys=True) + "\n")
    return rec
