#!/usr/bin/env python3
"""Mandatory Chat Capture Hook (runtime)

Design goal:
- Enforce a non-dormant, always-on record that the current run is associated with a chat context,
  even when the underlying platform does not expose chat transcripts programmatically.

This module produces a *placeholder* capture record that downstream tooling can enrich.
"""

from __future__ import annotations
import json
import os
import time
from typing import Any, Dict


def write_mandatory_chat_capture(state_hub: str, session_id: str, context: Dict[str, Any] | None = None) -> str:
    os.makedirs(state_hub, exist_ok=True)
    payload: Dict[str, Any] = {
        "schema": "MB_MANDATORY_CHAT_CAPTURE_v1",
        "mandatory_chat_capture": True,
        "session_id": session_id,
        "captured_at_unix": int(time.time()),
        "note": "Chat transcript is not accessible from sandbox runtime; this record asserts linkage requirement and provides an enrichment slot.",
        "context": context or {},
    }
    out_path = os.path.join(state_hub, f"chat_capture_{session_id}.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return out_path
