#!/usr/bin/env python3
"""
validate_metablooms_export.py — SB-1 Export Gate

Usage:
  python validate_metablooms_export.py MetaBlooms_OS.zip --expected-boot-sha256 <HASH> --run-smoke

Exit codes:
  0 PASS
  2 FAIL
"""

import argparse, hashlib, sys, zipfile, tempfile, shutil, subprocess
from pathlib import Path

def sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256(); h.update(b); return h.hexdigest()

def fail(msg: str):
    print(f"FAIL: {msg}")
    raise SystemExit(2)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("zip_path")
    ap.add_argument("--expected-boot-sha256", default="")
    ap.add_argument("--run-smoke", action="store_true")
    args = ap.parse_args()

    zp = Path(args.zip_path).expanduser().resolve()
    if not zp.exists():
        fail(f"ZIP not found: {zp}")

    with zipfile.ZipFile(zp, "r") as z:
        names = z.namelist()
        if "BOOT_METABLOOMS.py" not in names:
            fail("BOOT_METABLOOMS.py missing at ZIP root")

        boot_bytes = z.read("BOOT_METABLOOMS.py")
        boot_hash = sha256_bytes(boot_bytes)
        print(f"BOOT_SHA256={boot_hash}")

        if args.expected_boot_sha256 and boot_hash.lower() != args.expected_boot_sha256.lower():
            fail("BOOT_METABLOOMS.py hash mismatch (boot must be immutable)")

        has_run = ("RUN_METABLOOMS.py" in names) or any(n.endswith("/RUN_METABLOOMS.py") for n in names)
        if not has_run:
            fail("RUN_METABLOOMS.py not found (looks like skeleton export)")

    print("STRUCTURE_OK")

    if args.run_smoke:
        tmp = Path(tempfile.mkdtemp(prefix="metablooms_gate_"))
        try:
            with zipfile.ZipFile(zp, "r") as z:
                z.extractall(tmp)

            children = list(tmp.iterdir())
            root = children[0] if len(children) == 1 and children[0].is_dir() else tmp
            boot = root / "BOOT_METABLOOMS.py"
            if not boot.exists():
                fail("Extracted boot not found")

            proc = subprocess.run([sys.executable, str(boot)], cwd=str(root), capture_output=True, text=True)
            out = (proc.stdout or "").strip()
            err = (proc.stderr or "").strip()

            print("---- STDOUT ----")
            print(out)
            if err:
                print("---- STDERR ----")
                print(err)

            if proc.returncode != 0:
                fail(f"Boot execution failed with exit code {proc.returncode}")
            if "BOOT_OK" not in out:
                fail("Boot did not print BOOT_OK")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    print("PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
