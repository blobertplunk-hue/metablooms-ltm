# MetaBlooms RCR Engine (Root Cause & Repair) — Auto

This bundle provides an **automatic** root-cause + repair engine designed to prevent:
- ellipsis/truncation stubs
- `Locked.` placeholders
- `{"status":"locked"}` manifests
- dormant capability (not wired into boot)

## What it does
- Scans a ZIP or extracted directory
- Classifies failures into root-cause buckets
- Applies **safe** auto-repairs:
  - quarantines stub/locked/tiny placeholder files into `stubs_quarantine/`
  - patches `RUN_METABLOOMS.py` to call `boot_activator.activate_all()` and enforce an activation gate
  - adds `EXPORT_EXCLUDE.txt` to ensure quarantined stubs never ship

## Use
Analyze:
```bash
python metablooms_rcr.py analyze MetaBlooms_OS.zip --report-dir rcr_reports
```

Repair:
```bash
python metablooms_rcr.py repair MetaBlooms_OS.zip --out MetaBlooms_OS_REPAIRED.zip --report-dir rcr_reports
```

## Philosophy
Fail-closed. If a capability is shipped, it must be:
- wired
- observable
- testable
Otherwise: quarantine or fail.
