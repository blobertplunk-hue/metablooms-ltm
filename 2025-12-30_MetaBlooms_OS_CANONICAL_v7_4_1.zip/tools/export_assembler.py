#!/usr/bin/env python3
"""
export_assembler.py — Canonical MetaBlooms Export Assembler

This is the ONLY supported way to produce an export ZIP.
"""

import subprocess, sys, zipfile, os
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent / f"MetaBlooms_Export_{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}.zip"

# 1) Run export eligibility gate
gate = ROOT / "governance" / "export_gate" / "xeg_gate.py"
res = subprocess.run([sys.executable, str(gate)], cwd=ROOT)
if res.returncode != 0:
    sys.exit(res.returncode)

# 2) Create ZIP
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for r,_,files in os.walk(ROOT):
        for f in files:
            full = Path(r) / f
            arc = full.relative_to(ROOT)
            z.write(full, arcname=str(arc))

print("EXPORT_OK:", OUT)
