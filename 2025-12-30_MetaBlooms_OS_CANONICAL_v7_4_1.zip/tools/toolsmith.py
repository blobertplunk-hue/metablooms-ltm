"""MetaBlooms ToolSmith (stdlib-only)

Purpose:
- Provide a minimal, repeatable pattern for creating on-demand tools.
- Encourage: load -> transform -> validate -> export.

Usage:
  python tools/toolsmith.py new --name my_tool --kind cli --out /mnt/data/my_tool.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from textwrap import dedent
from datetime import datetime, timezone

TEMPLATE_CLI = """#!/usr/bin/env python3
"""""{name} — MetaBlooms Tool (generated)

Pipeline: LOAD -> TRANSFORM -> VALIDATE -> EXPORT
""""

from __future__ import annotations
import argparse
import json
from pathlib import Path

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="input file")
    ap.add_argument("--out", dest="out", required=True, help="output file")
    args = ap.parse_args()

    inp = Path(args.inp)
    out = Path(args.out)

    # LOAD
    data = inp.read_text(encoding="utf-8")

    # TRANSFORM (TODO)
    result = {{
        "tool": "{name}",
        "ok": True,
        "notes": "TODO: implement transform",
        "input_bytes": len(data.encode("utf-8")),
    }}

    # VALIDATE (fail-closed example)
    if result.get("ok") is not True:
        raise SystemExit("FAIL: validation failed")

    # EXPORT
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"WROTE: {out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
"""

TEMPLATE_HTML = """<!doctype html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{name} — MetaBlooms Tool</title>
<style>
body{{font-family:Arial,sans-serif;padding:16px;background:#f5f5f5}}
.card{{background:#fff;border:1px solid #ddd;border-radius:12px;padding:12px;max-width:900px;margin:0 auto}}
pre{{white-space:pre-wrap;word-break:break-word;background:#111;color:#e8f0ff;padding:10px;border-radius:10px}}
</style></head>
<body>
<div class="card">
<h1>{name}</h1>
<p>TODO: implement UI tool (no dependencies).</p>
<button id="run">Run</button>
<pre id="out"></pre>
</div>
<script>
document.getElementById('run').addEventListener('click', () => {{
  document.getElementById('out').textContent = 'TODO: implement';
}});
</script>
</body>
</html>
"""


def cmd_new(args: argparse.Namespace) -> int:
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).isoformat()

    if args.kind == "cli":
        content = TEMPLATE_CLI.format(name=args.name) + f"\n# generated: {ts}\n"
        out.write_text(content, encoding="utf-8")
    else:
        content = TEMPLATE_HTML.format(name=args.name) + f"\n<!-- generated: {ts} -->\n"
        out.write_text(content, encoding="utf-8")
    print(f"CREATED: {out}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    ap_new = sub.add_parser("new", help="scaffold a new tool")
    ap_new.add_argument("--name", required=True)
    ap_new.add_argument("--kind", choices=["cli", "html"], default="cli")
    ap_new.add_argument("--out", required=True)
    ap_new.set_defaults(func=cmd_new)

    args = ap.parse_args()
    return int(args.func(args))

if __name__ == "__main__":
    raise SystemExit(main())
