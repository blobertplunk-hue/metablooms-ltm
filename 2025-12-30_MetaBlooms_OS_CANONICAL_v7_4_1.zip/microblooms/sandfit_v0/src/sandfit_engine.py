from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Tuple

from src.hdl_logger import HDLEntry, utc_now, new_decision_id, classify, append_ndjson

@dataclass
class SandFitResult:
    viable: List[Dict[str, Any]]
    rejected: List[Dict[str, str]]
    decision_log_ref: str
    summary: str

def _num(v) -> float | None:
    try:
        if v is None:
            return None
        return float(v)
    except (TypeError, ValueError):
        return None

def check_physical_fit(candidate: Dict[str, Any], constraints: Dict[str, Any]) -> Tuple[bool, str]:
    attrs = candidate.get("attributes", {})
    h = _num(attrs.get("height_in"))
    w = _num(attrs.get("width_in"))
    d = _num(attrs.get("depth_in"))
    mh = _num(constraints.get("max_height_in"))
    mw = _num(constraints.get("max_width_in"))
    md = _num(constraints.get("max_depth_in"))

    if mh is not None:
        if h is None:
            return False, "missing height; cannot verify against max_height_in"
        if h > mh:
            return False, f"height {h:.2f}in exceeds max {mh:.2f}in"
    if mw is not None:
        if w is None:
            return False, "missing width; cannot verify against max_width_in"
        if w > mw:
            return False, f"width {w:.2f}in exceeds max {mw:.2f}in"
    if md is not None:
        if d is None:
            return False, "missing depth; cannot verify against max_depth_in"
        if d > md:
            return False, f"depth {d:.2f}in exceeds max {md:.2f}in"
    return True, "meets stated constraints"

def run_sandfit(payload: Dict[str, Any], hdl_path: str) -> SandFitResult:
    candidates = payload.get("candidates", [])
    constraints = payload.get("constraints", {})
    context = payload.get("context", {})

    heuristic_impulse = "Recommend closest match by similarity/popularity without strict constraint enforcement."

    viable: List[Dict[str, Any]] = []
    rejected: List[Dict[str, str]] = []

    insufficient_info = not bool(constraints)
    heuristic_danger = False

    laws_applied = ["Ambiguity Law", "Constraint Law", "Coverage Law"]

    if insufficient_info:
        for c in candidates:
            rejected.append({"candidate_id": c.get("candidate_id",""), "reason": "no constraints provided; cannot adjudicate"})
        metablooms_action = "WALK: request missing constraints before recommending."
        outcome = "needs-clarification"
        metablooms_overrode_heuristic = True
    else:
        for c in candidates:
            ok, reason = check_physical_fit(c, constraints)
            if ok:
                viable.append(c)
            else:
                rejected.append({"candidate_id": c.get("candidate_id",""), "reason": reason})
        metablooms_action = "Fail-closed on any violated or unverifiable hard constraint; provide explicit rejection reasons."
        metablooms_overrode_heuristic = len(rejected) > 0
        outcome = "fit_found" if viable else "correct_rejection"
        heuristic_danger = any("missing" in r["reason"] for r in rejected)

    decision_id = new_decision_id()
    classification = classify(outcome, metablooms_overrode_heuristic, heuristic_danger, insufficient_info)

    entry = HDLEntry(
        decision_id=decision_id,
        timestamp_utc=utc_now(),
        engine="SandFit",
        domain=context.get("domain","shopping"),
        task="sandfit_adjudication",
        heuristic_impulse=heuristic_impulse,
        metablooms_action=metablooms_action,
        laws_applied=laws_applied,
        classification=classification,
        outcome=outcome,
        notes=context.get("notes","")
    )
    append_ndjson(hdl_path, entry)

    if classification == "WALK":
        summary = "I need hard constraints (e.g., max height/width/depth) before I can confirm fit."
    elif viable:
        summary = f"Found {len(viable)} viable option(s); rejected {len(rejected)} that do not meet constraints."
    else:
        summary = f"No viable options met the stated constraints; rejected {len(rejected)} with explicit reasons."

    return SandFitResult(viable=viable, rejected=rejected, decision_log_ref=decision_id, summary=summary)
