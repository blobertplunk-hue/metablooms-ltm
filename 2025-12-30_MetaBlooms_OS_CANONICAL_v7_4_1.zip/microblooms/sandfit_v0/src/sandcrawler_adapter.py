from __future__ import annotations
from typing import List, Dict, Any

def sandcrawler_to_sandfit(candidates: List[Dict[str, Any]], constraints: Dict[str, Any], domain: str="shopping", risk_tolerance: str="low", notes: str="") -> Dict[str, Any]:
    normalized = []
    for c in candidates:
        normalized.append({
            "candidate_id": str(c.get("id") or c.get("candidate_id") or ""),
            "title": c.get("title") or c.get("name") or "Untitled",
            "source": c.get("source","unknown"),
            "attributes": c.get("attributes") or c.get("attrs") or {}
        })
    return {
        "candidates": normalized,
        "constraints": constraints,
        "context": {"domain": domain, "risk_tolerance": risk_tolerance, "notes": notes}
    }
