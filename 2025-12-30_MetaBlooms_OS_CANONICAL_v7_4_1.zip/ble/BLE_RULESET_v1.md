# BLE_RULESET_v1 — Procedural Competence Signals (MetaBlooms)

Status: DRAFT (promote-on-use capable)
Version: 1.0.0
Ruleset ID: BLE_RULESET_v1
Primary goal: Convert build-time friction into *governed*, *auditable* prevention controls.

## Scope
- This ruleset applies to **build sessions** (artifact creation, packaging, bootability, “give me a download”, etc.).
- It is **not** about content knowledge (Article SOP) and **not** about user preference/style (CLH), except where those preferences create build friction (e.g., decision fatigue during build execution).

## Governance contract
- BLE always emits **proposals**.
- Ledger writes happen only if the current learning state permits it.
- Promotion from proposal → guardrail → invariant requires explicit authorization (unless you later enable “promote-on-use”).

### Current system conflict note
If the OS is in **Learning Frozen** state, BLE still works as **proposal generation** and **receipt generation**.
When you unfreeze *only the BLE lane*, BLE can append events to a ledger (append-only).

## Signal format
Each signal definition includes:
- signal_name
- severity: low|med|high
- detection: deterministic triggers (event types + patterns)
- recommendation: default mitigation wording
- candidate_gate_id: optional gate to enforce
- promotion: recommended thresholds (session-aware)

## Session-aware promotion (default)
Promotion thresholds are evaluated across **distinct sessions**, not raw message counts:

- nano_log: first occurrence in any session (recordable)
- micro_log: ≥ 3 distinct sessions within last 30 days
- macro_log: ≥ 7 distinct sessions within last 90 days

(These can be tuned per environment later.)

---

## Signals

### BLE-SIG-001 — link_missing (HIGH)
**Definition:** User requested a download / link, but none was provided, or a “build complete” claim occurred without a link.

**Detectors**
- ConversationEvent.role=user AND regex matches:
  - `\b(download|link)\b` AND (`didn'?t`|`no`|`where`|`didn't give`) within same/next user turn
  - `you didn't give me a link`
- BuildEvent: artifact_created without subsequent “deliver_link” event within session

**Default mitigation**
- Guardrail: “Never declare a build deliverable complete unless a sandbox download link is provided.”
- Candidate gate: `GATE-ARTIFACT-LINK`

**Promotion**
- nano: first hit
- micro: 3 sessions
- macro: 7 sessions

---

### BLE-SIG-002 — artifact_missing (HIGH)
**Definition:** System claimed an artifact exists (ZIP/report/etc.) but the file did not exist at the expected path when checked.

**Detectors**
- BuildEvent: `file_missing(expected_path)` following `artifact_declared(expected_path)`
- ToolError: missing file / not found after “created” event
- ConversationEvent: user says “this isn’t a download”, “it’s not there”, “show receipts”

**Default mitigation**
- Guardrail: “No artifact claims without verification: check existence + size + sha256 before announcement.”
- Candidate gate: `GATE-ARTIFACT-VERIFY`

---

### BLE-SIG-003 — premature_claim (HIGH)
**Definition:** Declared success/completion before the required verification checklist completed.

**Detectors**
- ConversationEvent: assistant says “built/complete/done” and no corresponding BuildEvent `validation_result(pass)` for required checks
- Trace-level: EAT/TraceDiff missing for a run that executed SOPs/gates

**Default mitigation**
- Guardrail: “Announce completion only after verification events: existence, hash, and link.”
- Candidate gate: `GATE-COMPLETION-CLAIM`

---

### BLE-SIG-004 — enforcement_gap (HIGH)
**Definition:** A run executed SOPs/gates but did not emit EAT or did not produce TraceDiff when a baseline exists.

**Detectors**
- BuildEvent: `sop_executed` or `gate_applied` without `eat_emitted`
- Baseline exists AND `eat_emitted` without `tracediff_emitted`

**Default mitigation**
- Guardrail: “EAT mandatory; TraceDiff mandatory when baseline exists.”
- Candidate gate: `GATE-EAT-TRACEDIFF`

---

### BLE-SIG-005 — ambiguity_requires_choice (MED)
**Definition:** System presented multiple choices/options in a build context where best-practice default execution is expected, producing user friction.

**Detectors**
- ConversationEvent: user contains “decision fatigue” OR “stop making me choose” OR “why are you making me make all these choices”
- Near in time to procedure/build task (within same session)

**Default mitigation**
- Guardrail: “In build sessions, default to best-practice path and proceed; ask only one clarification if blocked.”
- Candidate gate: none (behavioral guideline)

---

### BLE-SIG-006 — ordering_violation (MED)
**Definition:** Steps executed out-of-order relative to declared pipeline (e.g., freeze/lock before artifact exists; claim built before zip created).

**Detectors**
- BuildEvent sequence violates checklist ordering:
  - “lock baselines” before “baseline artifacts exist”
  - “zip declared” before “zip created”
- ConversationEvent: user indicates confusion due to ordering (“what do we do next”, “I’m confused”, “why choices”)

**Default mitigation**
- Guardrail: “Use a deterministic build checklist; do not advance phase without passing phase checks.”
- Candidate gate: `GATE-PHASE-CHECKLIST`

---

### BLE-SIG-007 — assumption_invalid (MED)
**Definition:** System assumed existence of file/entrypoint/path/structure without verifying project files or provided inputs.

**Detectors**
- BuildEvent: `assumption_made(key)` followed by `file_missing` or user correction
- ConversationEvent: user “don’t assume”, “project files are authoritative”, “you’re mixing things”

**Default mitigation**
- Guardrail: “Project files are authoritative; verify presence before inference. If uncertain, run minimal inventory.”
- Candidate gate: `GATE-AUTHORITY-INPUTS`

---

## Candidate gates (stubs)
These gates can be implemented later as deterministic checks:

- `GATE-ARTIFACT-LINK`: require that a download link token is present for deliverables
- `GATE-ARTIFACT-VERIFY`: require exists + size>0 + sha256 before announce
- `GATE-COMPLETION-CLAIM`: block “done” phrasing unless required validations passed
- `GATE-EAT-TRACEDIFF`: require EAT and TraceDiff when baselines exist
- `GATE-PHASE-CHECKLIST`: enforce step ordering
- `GATE-AUTHORITY-INPUTS`: block unverified assumptions about inputs

## “Learn from being used” (operational definition)
When enabled (lane-scoped):
- Each signal firing emits a proposal always.
- If learning is unfrozen for BLE lane:
  - append a `BuildLearningEvent` (NDJSON) for nano+
  - increment session counters per signal
  - auto-draft a guardrail on micro, and a candidate invariant on macro
- Nothing is applied automatically without explicit promotion authorization (unless you later enable auto-promotion gates).

End.
