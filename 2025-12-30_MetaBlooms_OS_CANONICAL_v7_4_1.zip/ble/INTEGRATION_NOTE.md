# BLE Integration Note (v1)

This ruleset is designed to be consumed by a deterministic Build Learning Hook (BLH).

Minimum event API (concept):
- observe_build_event({...})
- observe_conversation_event({...})
- end_session(session_id)

Required behaviors:
- Always emit proposals (JSONL) for any matched signal.
- Only append ledger events if BLE lane is unfrozen.
- Session-aware promotion uses distinct session IDs.

Recommended: Treat these signals as candidates for hard gates in the OS only after micro/macro recurrence.
