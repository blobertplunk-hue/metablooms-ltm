## CEJ-2 Evidence Classification
Label claims: user_statement | tool_output | execution_log | artifact_file | inference.
