# CSP-1.1 — Continuation & State Preservation (MetaBlooms)

Continuation Mode triggers whenever work spans turns (default: assume yes).
Every continuing response MUST end with a Continuation Capsule containing:
Job, Mode, State, Artifacts/Objects, Constraints, Next Action, Resume Instruction.

Hard-fail: if missing, reconstruct state immediately.
