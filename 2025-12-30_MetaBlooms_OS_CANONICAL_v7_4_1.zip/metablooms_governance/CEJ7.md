## CEJ-7 Integration Mapping
Map items to control_plane/governance/integrations/sops/baselines.
