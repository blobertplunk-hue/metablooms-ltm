MMT-CHATLEDGER-P0
phase: Integrate
problem: Chat transcripts were not system-of-record; decisions were lost in scrollback.
proposal: Add append-only chat ledger + transcripts; require chat linkage on DeltaPack; enforce capture on boot and delta activation.
expected_gain: Legibility, replayability, auditability; reduces scroll fatigue and orphaned learning.
risk: Increased filesystem writes; mitigated by append-only small records and boundary-only enforcement.
status: IMPLEMENTED (v1)
