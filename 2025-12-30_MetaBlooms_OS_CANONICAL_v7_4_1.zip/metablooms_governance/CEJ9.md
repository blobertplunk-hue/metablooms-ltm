## CEJ-9 Continuation + Audit
Continuation capsule + omission check.
