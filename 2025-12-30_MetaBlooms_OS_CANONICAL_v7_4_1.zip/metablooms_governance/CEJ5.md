## CEJ-5 Tooling/Workflow Extraction
Extract reusable scripts/patterns.
