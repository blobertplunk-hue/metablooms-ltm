# Enabled Systems (Augmentation Layer)

Fully Enabled (Governance Subsystems):
- CRP-1.1 — Rigor enforcement
- CSP-1.1 — Continuation capsules & resumability
- MIHP-1.0 — Identity heartbeat (X=3)

Provisionally Encouraged (Policy):
- Delegation layer (semantic)
- Monetization tier framework
- Gated background execution
- Phase checkpointing (now required by CRP for phased work)
