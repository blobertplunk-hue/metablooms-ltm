# MetaBlooms Boot Contract (FROZEN) — BC-1.0

Status: FROZEN (do not change casually)

Purpose:
- Make boot deterministic, minimal, and context-independent.
- Prevent boot from doing build/audit/repair/learning.

Non‑negotiable invariants:
1) Single authoritative entrypoint file name: `RUN_METABLOOMS.py`
2) Deterministic location: root of extracted bundle
3) Zero inference: boot does not guess alternate entrypoints
4) Boot rules do not depend on chat memory
5) Boot rules must be weaker than environment constraints (project files are flat; ZIP contents invisible until extraction)
6) Failure is observable, not conversational (explicit BOOT_FAILED:* codes)

Phase separation (hard):
- Boot ≠ Audit
- Boot ≠ Normalize
- Boot ≠ Seal
- Boot ≠ Build
Boot may only:
- extract (if bundle is zip)
- read `boot_manifest.json`
- execute declared entrypoint

Allowed companion file (for flat project files):
- `BOOT.md` at project-files root may provide extraction/run instructions.
It does not change the runtime entrypoint contract.

Change control:
- Any change to BC-1.0 requires:
  - version bump (BC-1.1, etc.)
  - explicit rationale
  - compatibility note
