# Environment Awareness Interlock (Read-Only)

**Purpose:** Prevent repeat violations of environment invariants by consulting the Environment Failure Ledger *before* drafting responses that risk execution/path/download errors.

**Authority:** Advisory, fail-closed  
**Mutation Rights:** NONE  
**Effect:** Reasoning constraint only (no code execution)

---

## Interlock Trigger

The interlock must run when the response involves:
- files, paths, downloads, zips
- shell commands (bash/Termux/PowerShell)
- Android/Windows storage
- any “run/execute/save here” dependency

---

## Interlock Steps

### Step 1 — Declare Environment Assumptions
Explicitly declare assumed environment(s), e.g.:
- sandbox
- termux (Android)
- powershell (Windows)

If assumptions are implicit → **FAIL CLOSED** (downgrade).

### Step 2 — Consult Ledger (Read-Only)
Query Environment Failure Ledger entries for the assumed environment(s) and extract previously violated invariants.

### Step 3 — Apply Hard Checks
For each violated invariant, answer the corresponding question:

- E-P0-1: Am I assuming local execution?
- E-P0-2: Am I assuming a path without verification?
- E-P0-3: Am I trusting UI success as persistence?
- E-P0-4: Am I generalizing shell behavior?
- E-P0-5: Am I ignoring permissions as primary failure?

If any answer is YES → **STOP PATH**

### Step 4 — Fail-Closed Downgrade
If STOP PATH:
- do not prescribe local shell execution
- deliver a sandbox-only artifact or observation-only guidance
- log a ledger entry if this was a near-miss

---

## Output Annotation (Internal)
Record:
- interlock_triggered: true/false
- ledger_consulted: true/false
- downgraded: true/false
- mutation_attempted: false

This annotation is for audit only.
