# Safe Learning Charter — Addendum A
## Environment Failure Learning (Shells, Runtimes, OS Boundaries)

**Status:** ACTIVE (Non-Mutative)  
**Applies To:** Termux, PowerShell, Android, Windows, Sandbox  
**Learning Zone:** C (Post-Mortem) + B (Heuristic)  
**Mutation Authority:** NONE (Ledger-only)

---

### 1. Purpose

This addendum authorizes MetaBlooms to learn aggressively from environment-specific failures (Termux, PowerShell, Android storage, Windows paths, sandbox constraints) without risking system integrity.

All learning under this addendum is **ledger-only** and **non-binding**.

---

### 2. Scope of Authorized Learning

**Allowed**
- Shell execution failures and tooling mismatches
- Path resolution errors and working-directory assumptions
- Permission and policy denials (scoped storage, execution policy, sandbox constraints)
- UI vs filesystem mismatches (download lifecycle, “link success” without persistence)
- Environment assumption violations and recurring anti-patterns

**Forbidden**
- Auto-execution or “self-fixing” environment actions
- Environment mutation on user devices (Termux/Android/Windows)
- Silent behavior changes to core boot/activation/export logic
- Any change that reduces fail-closed safety properties

---

### 3. Absolute Environment Invariants (E-P0)

**E-P0-1 — Never assume local execution.**  
Assume the user will run **zero** commands unless explicitly proven otherwise.

**E-P0-2 — Paths are invalid until proven.**  
Paths must be explicit, environment-declared, and verified.

**E-P0-3 — UI success ≠ file existence.**  
A UI download or link is not evidence of persistence; only disk presence + hash is.

**E-P0-4 — Shells are not interchangeable.**  
Bash, PowerShell, Termux, and sandbox constraints differ; do not generalize.

**E-P0-5 — Permissions are the default failure mode.**  
Treat permission failure as the first hypothesis, not an edge case.

Violations of E-P0 invariants **must be logged**.

---

### 4. Enforcement Rule

If there is ambiguity between *learning* and *fixing*:

1) Learn only  
2) Log the failure  
3) Do not repair or prescribe command execution  

Fail-closed always applies.

---

### 5. Output Contract

All learning must emit a ledger entry declaring:
- Environment
- Violated invariant
- Failure signature
- Root cause hypothesis
- Non-mutative status

No learning under this addendum may affect runtime behavior.
