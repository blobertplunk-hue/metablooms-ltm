# Export Eligibility Gate — XEG-1.0 (FROZEN)

Purpose:
Prevent silent omission of required systems at export time.

Rule:
If any required path or file is missing, export MUST FAIL.

Failure code:
EXPORT_FAILED: MISSING_REQUIRED_SYSTEMS

Required systems (minimum):
- Egg Juicer (EJ-CORE)
- Chunk Egg Juicer (CEJ) with passes CEJ1–CEJ9
- Boot Contract BC-1.0
- Learning Integration Doctrine LID-1.0
- RCA_BOOT_RCA-BOOT-1.0.md
- MEEP_Manifest.json

This gate is evaluated BEFORE any ZIP is cut.
