# MB_SESSION_LIFECYCLE_SPEC_v1

Canonical definition of session boundaries for MetaBlooms OS.
