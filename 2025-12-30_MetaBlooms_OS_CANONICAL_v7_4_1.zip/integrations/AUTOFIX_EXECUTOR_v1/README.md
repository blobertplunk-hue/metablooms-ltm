
# AUTOFIX_EXECUTOR_v1

Purpose:
- Consume TTG/TTAF Runner output
- Apply deterministic autofix actions
- Verify and rollback if needed
- Emit execution receipt

Design constraints:
- No semantic changes
- No hidden side effects
- Rollback-first philosophy
- Safe stubbed execution (real execution delegated to integrator)

Usage:
cat ttaf_match.json | python autofix_executor.py
