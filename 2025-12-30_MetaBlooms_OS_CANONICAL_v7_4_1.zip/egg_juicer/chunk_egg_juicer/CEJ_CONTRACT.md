# CEJ Contract — CEJ-1.0 (FROZEN)

Required per chunk run:
1) Execute **all passes CEJ-1..CEJ-9** in order, unless explicitly blocked.
2) Maintain required granularity (e.g., “Chunk-15 forensic granularity”) when specified.
3) Do not “compress” findings until object exhaustion.
4) Produce a continuation capsule at the end of the run.
5) Maintain a strict boundary: do not mix current-chat prompts with historical chunk content (no temporal contamination).
6) When UI behavior is implicated, distinguish:
   - execution-backed evidence
   - UI-illusion evidence
   - user assertion
