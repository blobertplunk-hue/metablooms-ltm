# CEJ-8 — Promotion Candidates Pass

Deliverable: enabled vs provisional vs blocked.

Fields:
- candidate_id, status (enabled/provisional/blocked), rationale, prerequisites
- Output: CEJ_chunk_N_promotion.json
