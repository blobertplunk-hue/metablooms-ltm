# CEJ-6 — Governance Gap Pass

Deliverable: which missing rule allowed the failure.

Fields:
- gap_id, missing_guardrail, consequence, proposed_control, evidence_pointer
- Output: CEJ_chunk_N_gaps.json
