
from tools.rcr.metablooms_ship import main as _ship_main
#!/usr/bin/env python3
"""validate_metablooms_export.py — Export Gate

Verifies:
- control_plane/chat_ledger_v1.py exists (mandatory chat capture)
- BOOT_METABLOOMS.py includes mandatory chat capture hook
- BOOT_METABLOOMS.py exists at ZIP root
- boot_manifest.json exists at ZIP root
- RUN_METABLOOMS.py exists at ZIP root
- Bundle is self-consistent: entrypoint declared exists
Optional:
- --run-smoke: extracts bundle and runs BOOT_METABLOOMS.py against it (sandbox-safe)
"""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

def sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()

def fail(msg: str) -> None:
    print(f"FAIL: {msg}", flush=True)
    raise SystemExit(2)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("zip_path")
    ap.add_argument("--expected-boot-sha256", default="")
    ap.add_argument("--run-smoke", action="store_true")
    args = ap.parse_args()

    zp = Path(args.zip_path).expanduser().resolve()
    if not zp.exists():
        fail(f"ZIP not found: {zp}")

    with zipfile.ZipFile(zp, "r") as z:
        names = set(z.namelist())
        for req in ("BOOT_METABLOOMS.py", "boot_manifest.json", "RUN_METABLOOMS.py"):
            if req not in names:
                fail(f"Missing required file at ZIP root: {req}")

        manifest = json.loads(z.read("boot_manifest.json").decode("utf-8"))
        ep = manifest.get("entrypoint")
        if not ep or ep not in names:
            fail(f"boot_manifest.json entrypoint missing or not present in zip: {ep}")

        boot_bytes = z.read("BOOT_METABLOOMS.py")
        boot_hash = sha256_bytes(boot_bytes)
        print(f"BOOT_SHA256={boot_hash}")

        if args.expected_boot_sha256 and boot_hash.lower() != args.expected_boot_sha256.lower():
            fail("BOOT_METABLOOMS.py SHA256 mismatch vs expected")
        # Export-gate: mandatory chat capture must be wired into runtime (BOOT is immutable by invariant)
        run_bytes = z.read('RUN_METABLOOMS.py')
        run_text = run_bytes.decode('utf-8', errors='replace')
        if 'mandatory_chat_capture' not in run_text and 'write_mandatory_chat_capture' not in run_text:
            raise SystemExit('EXPORT_BLOCKED: RUN_METABLOOMS.py missing mandatory chat capture wiring')


    
    if args.run_smoke:
        with tempfile.TemporaryDirectory(prefix="metablooms_validate_") as td:
            td = Path(td)
            bundle_copy = td / "MetaBlooms_bundle.zip"
            shutil.copy2(zp, bundle_copy)
            # Extract and run stable boot launcher against the bundle
            extract_dir = td / "MetaBlooms"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(bundle_copy, "r") as z:
                z.extractall(extract_dir)

            launcher = extract_dir / "BOOT_METABLOOMS.py"
            cmd = [sys.executable, str(launcher), "--bundle", str(bundle_copy), "--dest", str(td / "Booted")]
            p = subprocess.run(cmd, capture_output=True, text=True)
            print(p.stdout)
            if p.returncode != 0:
                print(p.stderr)
                fail(f"Smoke run failed with code {p.returncode}")
            if "BOOT_OK" not in p.stdout:
                fail("Smoke run did not emit BOOT_OK")

    print("PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
