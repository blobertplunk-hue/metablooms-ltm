#!/usr/bin/env python3
"""ZOOP_INSTALL_METABLOOMS_v2

Installs MetaBlooms OS ZIP into /mnt/data/metablooms/ with a split:
- Bundle root payload -> /mnt/data/metablooms/system/
- Bundle metablooms/ subtree -> /mnt/data/metablooms/ (state + tooling)
"""
import argparse, json, zipfile, hashlib, shutil, datetime, sys
from pathlib import Path

INSTALL_ROOT = Path("/mnt/data/metablooms")
STAGING_ROOT = INSTALL_ROOT / "_staging"
REPORTS = INSTALL_ROOT / "reports"
LEDGERS = INSTALL_ROOT / "ledgers"
BUNDLES = INSTALL_ROOT / "bundles"

REQUIRED_ANY = ["BOOT.md", "boot_manifest.json"]
REQUIRED_ALL = ["BOOT_METABLOOMS.py"]

def utc_compact():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat().replace(":","").replace("-","") + "Z"

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

def fail(msg: str, code: int = 2):
    print(msg, file=sys.stderr)
    raise SystemExit(code)

def ensure_dirs():
    for d in [INSTALL_ROOT, STAGING_ROOT, REPORTS, LEDGERS, BUNDLES, INSTALL_ROOT/"deltas", INSTALL_ROOT/"transcripts"]:
        d.mkdir(parents=True, exist_ok=True)

def verify_bundle(extract_dir: Path):
    present = {p.name for p in extract_dir.iterdir()}
    if not any(x in present for x in REQUIRED_ANY):
        fail(f"INSTALL_BLOCKED: missing one of {REQUIRED_ANY}")
    for r in REQUIRED_ALL:
        if r not in present:
            fail(f"INSTALL_BLOCKED: missing required {r}")

def append_jsonl(path: Path, obj: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, sort_keys=True) + "\n")

def atomic_replace_dir(src: Path, dst: Path):
    if dst.exists():
        backup = dst.with_name(dst.name + f"._bak_{utc_compact()}")
        dst.rename(backup)
    src.rename(dst)

def merge_append_only_jsonl(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not src.exists():
        return
    if not dst.exists():
        shutil.copy2(src, dst)
        return
    # append lines (no dedupe in v2)
    with src.open("r", encoding="utf-8") as fsrc, dst.open("a", encoding="utf-8") as fdst:
        for line in fsrc:
            if line.strip():
                fdst.write(line if line.endswith("\n") else line + "\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", required=True)
    args = ap.parse_args()

    bundle = Path(args.bundle)
    if not bundle.exists():
        fail(f"INSTALL_BLOCKED: bundle not found: {bundle}")

    ensure_dirs()
    install_id = f"install_{utc_compact()}"
    staging = STAGING_ROOT / install_id
    staging.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(bundle) as z:
            z.extractall(staging)
    except Exception as e:
        fail(f"INSTALL_BLOCKED: unzip failed: {e}")

    verify_bundle(staging)

    system_dst = INSTALL_ROOT / "system"
    tmp_system = INSTALL_ROOT / f"_tmp_system_{install_id}"
    if tmp_system.exists():
        shutil.rmtree(tmp_system, ignore_errors=True)
    shutil.copytree(staging, tmp_system, ignore=shutil.ignore_patterns("metablooms"))
    atomic_replace_dir(tmp_system, system_dst)

    # If bundle contains metablooms/ subtree, copy it into INSTALL_ROOT (state/tooling)
    mb_src = staging / "metablooms"
    if mb_src.exists() and mb_src.is_dir():
        for item in mb_src.iterdir():
            dst = INSTALL_ROOT / item.name
            if item.is_dir():
                shutil.copytree(item, dst, dirs_exist_ok=True)
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dst)

        # merge ledgers append-only if provided
        merge_append_only_jsonl(mb_src / "ledgers" / "delta_ledger.jsonl", LEDGERS / "delta_ledger.jsonl")
        merge_append_only_jsonl(mb_src / "ledgers" / "chat_ledger.jsonl", LEDGERS / "chat_ledger.jsonl")
        merge_append_only_jsonl(mb_src / "ledgers" / "os_ledger.jsonl", LEDGERS / "os_ledger.jsonl")

    os_ledger = LEDGERS / "os_ledger.jsonl"
    rec = {
        "schema": "MetaBlooms::OSLedger::v1",
        "event": "INSTALL",
        "install_id": install_id,
        "bundle_path": str(bundle),
        "bundle_sha256": sha256_file(bundle),
        "installed_utc": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "system_path": str(system_dst),
    }
    append_jsonl(os_ledger, rec)

    receipt = {
        "status": "INSTALLED",
        "install_id": install_id,
        "install_root": str(INSTALL_ROOT),
        "system_dir": str(system_dst),
        "bundle": {"path": str(bundle), "sha256": rec["bundle_sha256"]},
        "notes": [
            "Boot from /mnt/data/metablooms/system/BOOT_METABLOOMS.py",
            "Delta enforcement expects /mnt/data/metablooms/ledgers and /mnt/data/metablooms/deltas."
        ],
    }
    receipt_path = REPORTS / f"install_receipt_{install_id}.json"
    receipt_path.write_text(json.dumps(receipt, indent=2), encoding="utf-8")

    print("ZOOP_OK")
    print(f"INSTALL_ID: {install_id}")
    print(f"RECEIPT: {receipt_path}")

if __name__ == "__main__":
    main()
