# DIFF — 2025-12-28 — Stable Boot Merge (SB-1 + MEEP-1.0)

## Added (root)
- BOOT_METABLOOMS.py (immutable entrypoint; smoke test + handoff to RUN_METABLOOMS.py)
- boot_contract.json (pins immutable boot hash; defines required markers)
- validate_metablooms_export.py (export gate; optional smoke execution)

## Added (tools/)
- tools/validate_metablooms_export.py

## Unchanged
- Full MetaBlooms OS contents from MetaBlooms_OS_Full_Export_MEEP-1.0.zip preserved as base.

## Notes
- BOOT_METABLOOMS.py runs RUN_METABLOOMS.py and prints success banner only when child exits 0.
- Boot report written every run to logs/boot/boot_report.json.
