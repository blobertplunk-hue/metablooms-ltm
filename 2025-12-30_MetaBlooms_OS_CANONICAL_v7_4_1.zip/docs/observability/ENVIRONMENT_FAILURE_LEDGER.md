# Environment Failure Ledger (Observability)

This ledger is a first-class observability stream for environment-specific failures and near-misses.

## What it is
A non-mutative, ledger-only record of:
- Termux/Android failures
- PowerShell/Windows failures
- Sandbox constraints and UI lifecycle mismatches

## What it is not
- Not an execution plan
- Not an auto-fix system
- Not a permission to mutate user environments

## Files
- `ENVIRONMENT_FAILURE_LEDGER.schema.json` — contract
- `ENVIRONMENT_FAILURE_LEDGER.seed.json` — seeded entries
- `environment_failures.ndjson` — append-only event stream (optional future)

## Required invariants (E-P0)
E-P0-1..E-P0-5 as defined in the charter addendum.

## Integration
Engines may consult this ledger read-only via the Environment Awareness Interlock.
