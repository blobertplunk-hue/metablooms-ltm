# DIFF — 2025-12-29 Activation Hardening (No Dormant Capability)

## Goal
Ship a bundle where every included capability is:
- wired into runtime
- activated deterministically
- observable via artifacts
- able to fail boot (fail-closed)

## Changes
- Replaced truncated/placeholder `RUN_METABLOOMS.py` with a fail-closed runtime that:
  - loads `control_plane/BOOT_STATE.json`
  - activates all subsystems via `control_plane/boot_activator.py`
  - enforces required subsystem list
  - writes activation + smoke artifacts to `control_plane/state_hub/`
  - prints `BOOT_OK` **only after** activation gates pass

- Replaced truncated/placeholder `BOOT_METABLOOMS.py` with a stable launcher that:
  - extracts bundle zip to destination
  - resolves entrypoint via `boot_manifest.json`
  - runs entrypoint and streams output
  - fails if success signal missing

- Added Control Plane Python modules:
  - `control_plane/activation_registry.py`
  - `control_plane/boot_activator.py`
  - `control_plane/shopping_mode_controller.py`
  - `control_plane/__init__.py`

- `shopping_mode_controller.py` is activated at boot and its JSON tests are executed.
  - Boot fails if Shopping Mode tests fail.

- Replaced truncated `validate_metablooms_export.py` with a working export gate.

## Receipts
On successful boot, `RUN_METABLOOMS.py` writes:
- `control_plane/state_hub/activation_status_<session>.json`
- `control_plane/state_hub/smoke_<session>.json`

and prints:
- `BOOT_OK`
- `ACTIVATION_ARTIFACT: <path>`

