import json, os
from pathlib import Path

class ObservabilityValidationError(RuntimeError):
    pass

HEALTH_ENUM = {"HEALTHY","DEGRADED","FAILED"}

def _read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def validate_observability(install_root: str) -> bool:
    root = Path(install_root)
    mb_root = root / "metablooms"

    required = [
        mb_root / "HEALTH.json",
        mb_root / "STATUS.md",
        mb_root / "WHAT_CHANGED_TODAY.md",
        mb_root / "ACTIVE_STATE.md",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise ObservabilityValidationError(f"Missing required observability outputs: {missing}")

    # HEALTH.json schema sanity
    health = _read_json(mb_root / "HEALTH.json")
    if health.get("status") not in HEALTH_ENUM:
        raise ObservabilityValidationError(f"Invalid health.status: {health.get('status')}")
    if not isinstance(health.get("subsystems"), dict):
        raise ObservabilityValidationError("health.subsystems must be a dict")

    # Invariant: if governance certificate evidence exists, it must be surfaced
    ev_dir = mb_root / "evidence"
    cert_sources = []
    if ev_dir.exists():
        for p in sorted(ev_dir.glob("*.json")):
            try:
                obj = _read_json(p)
            except Exception:
                continue
            if obj.get("kind") == "mips_certificate":
                cert_sources.append(p.name)

    if cert_sources:
        # Must appear in HEALTH.json and STATUS.md
        health_certs = health.get("governance_certifications") or []
        surfaced_sources = {c.get("source") for c in health_certs if isinstance(c, dict)}
        for s in cert_sources:
            if s not in surfaced_sources:
                raise ObservabilityValidationError(
                    f"governance certificate evidence exists but is not surfaced in HEALTH.json: {s}"
                )

        body = (mb_root / "STATUS.md").read_text(encoding="utf-8", errors="ignore")
        for s in cert_sources:
            if s not in body:
                raise ObservabilityValidationError(
                    f"governance certificate evidence exists but is not surfaced in STATUS.md: {s}"
                )

    return True
