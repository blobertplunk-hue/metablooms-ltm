from .generate_health import generate_health
from .generate_status import generate_status
from .generate_changes_today import generate_changes_today
from .generate_active_state import generate_active_state

def generate_all(install_root: str, activation_artifact: str | None = None) -> dict:
    health = generate_health(install_root, activation_artifact=activation_artifact)
    status_path = generate_status(install_root, health)
    changes_path = generate_changes_today(install_root)
    active_state_path = generate_active_state(install_root, health)
    return {
        "health": health,
        "paths": {
            "HEALTH.json": "metablooms/HEALTH.json",
            "STATUS.md": "metablooms/STATUS.md",
            "WHAT_CHANGED_TODAY.md": "metablooms/WHAT_CHANGED_TODAY.md",
            "ACTIVE_STATE.md": "metablooms/ACTIVE_STATE.md",
        },
        "activation_artifact": health.get("activation_artifact"),
    }
