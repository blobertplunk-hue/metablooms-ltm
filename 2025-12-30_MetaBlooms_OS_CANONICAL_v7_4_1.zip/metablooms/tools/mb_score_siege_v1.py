#!/usr/bin/env python3
"""mb_score_siege_v1.py

Compute Siege Scorecard v1 from a receipts directory.
This is intentionally strict: missing evidence = zero points for that line item.
"""
from __future__ import annotations
import argparse, json, os, re
from pathlib import Path

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("receipts_dir")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    rd = Path(args.receipts_dir)
    if not rd.exists():
        raise SystemExit(f"receipts_dir not found: {rd}")

    # heuristics: look for activation_status, evidence log, boot_ok lines in stdout captures
    activation = list(rd.rglob("activation_status_*.json"))
    evidence = list(rd.rglob("evidence_log*.jsonl")) + list(rd.rglob("*evidence*.jsonl"))
    boot_ok = list(rd.rglob("*.md")) + list(rd.rglob("*.txt"))

    def has_boot_ok() -> bool:
        for p in boot_ok:
            try:
                t=p.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            if "BOOT_OK" in t and "MetaBlooms OS READY" in t:
                return True
        return False

    score = {"A":0,"B":0,"C":0,"D":0,"E":0}
    # A
    if activation: score["A"] += 5
    if has_boot_ok(): score["A"] += 5
    if evidence: score["A"] += 5
    # placeholder for "no assumed systems" check: requires a subsystem inventory file
    inv = list(rd.rglob("*inventory*.jsonl"))
    if inv: score["A"] += 5

    total = sum(score.values())
    out = {"schema":"MB_SIEGE_SCORE_v1","score":score,"total":total,
           "signals":{"activation_artifacts":len(activation),"inventory":len(inv),"evidence_logs":len(evidence)}}
    s=json.dumps(out, indent=2)

    if args.out:
        Path(args.out).write_text(s, encoding="utf-8")
    print(s)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
