import json, datetime

def revoke_delta(delta_id: str, ledger_path: str, why: str, owner: str="system") -> dict:
    rec = {
        "delta_id": delta_id,
        "revoked_utc": datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z",
        "status": "REVOKED",
        "why": why,
        "owner": owner,
    }
    with open(ledger_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, sort_keys=True) + "\n")
    return rec
