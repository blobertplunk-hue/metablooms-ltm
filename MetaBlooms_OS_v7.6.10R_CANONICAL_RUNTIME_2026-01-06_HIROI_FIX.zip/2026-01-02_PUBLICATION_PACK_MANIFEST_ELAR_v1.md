# Publication Pack Manifest — ELAR Execution Gap Audit (v1)

This manifest lists the public-facing artifacts suitable for distribution (subject to final review).
All items are designed to be readable without internal system details or tooling references.

## Included artifacts (candidate)
1) Administrative Brief (Anchored)
- File: 2026-01-02_ADMIN_BRIEF_ELAR_TEKS_EXECUTION_GAPS_v2_ANCHORED.md

2) Claims → Citations Table (Anchored)
- File: 2026-01-02_CLAIMS_TO_CITATIONS_TABLE_v4_ANCHORED.md

3) Executive Summary (PD-focused)
- File: 2026-01-02_EXEC_SUMMARY_ELAR_EXEC_GAP_v1.md

4) Evidence Memo (Sandcrawler)
- File: 2026-01-02_EVIDENCE_MEMO_SANDCRAWLER_v1.md

5) Anchor Map (TEKS PDF section → page)
- File: 2026-01-02_TEKS_ELAR_ANCHOR_MAP_v1.md
- File: 2026-01-02_TEKS_ELAR_ANCHOR_MAP_v1.json

## Notes
- Any claim without a primary source must remain excluded (fail-close).
- Anchors are derived from the provided TEKS PDF via text extraction; if a page lacks extractable text, verify via page screenshot before publication.
