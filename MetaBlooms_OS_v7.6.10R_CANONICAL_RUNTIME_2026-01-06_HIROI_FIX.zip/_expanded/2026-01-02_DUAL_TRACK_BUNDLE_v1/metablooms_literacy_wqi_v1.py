"""
MetaBlooms Literacy WQI v1 (Write + Query Interface)

- Append-only NDJSON ledger writer
- Read-only query with simple filters
- Fail-closed semantics for callers (caller should treat exceptions as HOLD)

Ledger path default:
  ledgers/literacy/literacy_runs.ndjson
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional

DEFAULT_LEDGER_PATH = os.path.join("ledgers", "literacy", "literacy_runs.ndjson")


REQUIRED_TOP_LEVEL = [
    "ts_utc",
    "run_id",
    "artifact_id",
    "task_id",
    "target_grade_band",
    "required_schema_set",
    "ail",
]

REQUIRED_AIL_FIELDS = ["decision", "justification", "next_required"]


def _utc_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


def validate_record(record: Dict[str, Any]) -> None:
    """
    Fail-closed validation: raises ValueError if record is missing required fields.
    """
    missing = [k for k in REQUIRED_TOP_LEVEL if k not in record]
    if missing:
        raise ValueError(f"Missing required top-level fields: {missing}")

    ail = record.get("ail", {})
    if not isinstance(ail, dict):
        raise ValueError("Field 'ail' must be an object/dict")

    missing_ail = [k for k in REQUIRED_AIL_FIELDS if k not in ail]
    if missing_ail:
        raise ValueError(f"Missing required ail fields: {missing_ail}")

    if ail["decision"] not in {"PASS", "HOLD", "REPAIR", "BLOCK"}:
        raise ValueError("ail.decision must be one of PASS/HOLD/REPAIR/BLOCK")


def append_run(record: Dict[str, Any], ledger_path: str = DEFAULT_LEDGER_PATH) -> None:
    """
    Append a single NDJSON line to the ledger (append-only).
    """
    record = dict(record)
    record.setdefault("ts_utc", _utc_iso())
    validate_record(record)

    _ensure_dir(ledger_path)
    line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
    with open(ledger_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _match_schema(record: Dict[str, Any], schema_id: str) -> bool:
    """
    Returns True if schema_id appears in required_schema_set or in ssm outputs (if present).
    """
    rs = record.get("required_schema_set") or []
    if schema_id in rs:
        return True
    ssm = record.get("ssm") or []
    # Accept schema entries like {"schema_id": "...", ...}
    for item in ssm:
        if isinstance(item, dict) and item.get("schema_id") == schema_id:
            return True
    return False


def query_runs(
    ledger_path: str = DEFAULT_LEDGER_PATH,
    *,
    artifact_id: Optional[str] = None,
    grade_band: Optional[str] = None,
    schema_id: Optional[str] = None,
    decision: Optional[str] = None,
    failure_signal: Optional[str] = None,
    limit: int = 50,
) -> List[Dict[str, Any]]:
    """
    Read-only bounded query over the NDJSON ledger.
    """
    out: List[Dict[str, Any]] = []
    if not os.path.exists(ledger_path):
        return out

    with open(ledger_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                # fail-closed: skip corrupt lines but caller can detect via len mismatch + later audit
                continue

            if artifact_id and rec.get("artifact_id") != artifact_id:
                continue
            if grade_band and rec.get("target_grade_band") != grade_band:
                continue
            if schema_id and not _match_schema(rec, schema_id):
                continue
            if decision and rec.get("ail", {}).get("decision") != decision:
                continue
            if failure_signal and rec.get("failure_signal") != failure_signal:
                continue

            out.append(rec)
            if len(out) >= limit:
                break

    return out


def query_trace_log(
    trace_path: str,
    query_params: Dict[str, Any],
) -> None:
    """
    Optional: append query parameters to an audit trace file (append-only).
    """
    _ensure_dir(trace_path)
    query_params = dict(query_params)
    query_params.setdefault("ts_utc", _utc_iso())
    line = json.dumps(query_params, ensure_ascii=False, separators=(",", ":"))
    with open(trace_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")


if __name__ == "__main__":
    # Minimal CLI demo (safe): prints last N runs
    import argparse

    p = argparse.ArgumentParser(description="MetaBlooms Literacy WQI v1")
    p.add_argument("--ledger", default=DEFAULT_LEDGER_PATH)
    p.add_argument("--artifact_id")
    p.add_argument("--grade_band")
    p.add_argument("--schema_id")
    p.add_argument("--decision")
    p.add_argument("--failure_signal")
    p.add_argument("--limit", type=int, default=20)
    args = p.parse_args()

    rows = query_runs(
        args.ledger,
        artifact_id=args.artifact_id,
        grade_band=args.grade_band,
        schema_id=args.schema_id,
        decision=args.decision,
        failure_signal=args.failure_signal,
        limit=args.limit,
    )
    print(json.dumps(rows, indent=2, ensure_ascii=False))
