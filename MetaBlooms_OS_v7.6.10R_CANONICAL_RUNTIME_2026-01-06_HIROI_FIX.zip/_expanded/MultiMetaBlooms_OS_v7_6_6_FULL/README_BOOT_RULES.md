# MetaBlooms OS v3.1

Status: Adaptive, Auditable, Operational Kernel

This distribution includes:
- Session lifecycle specification
- Evidence hashing specification
- Integration contracts
- Learning promotion criteria

All learning is governed and reversible.
