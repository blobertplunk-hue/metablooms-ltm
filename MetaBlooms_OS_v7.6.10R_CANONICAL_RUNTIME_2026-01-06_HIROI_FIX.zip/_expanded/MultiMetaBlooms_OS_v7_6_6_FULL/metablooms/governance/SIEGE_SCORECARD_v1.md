# Siege Mode Scorecard (MB_SIEGE_SCORECARD_v1)

Total: 100 points.

## A. Boot & Authority (20)
- Immutable entrypoint discovered + hashed (5)
- No assumed systems (5)
- Fail-closed on ambiguity (5)
- Boot receipts written (5)

## B. Phantom Feature Detection (20)
- Exhaustive subsystem enumeration (5)
- Phantom labeling for unproven claims (5)
- Export blocked on phantom (5)
- Evidence cited (paths + hashes) (5)

## C. Failure Injection (20)
- >=3 real injected failures (6)
- Failure signals explicit + logged (6)
- Correct response (repair/quarantine/halt) (4)
- Evidence logged (4)

## D. Learning Codification (20)
- False assumption identified (5)
- New invariant defined (5)
- Gate/schema updated (5)
- Regression test defined (5)

## E. Adversarial Resistance (20)
- Obfuscation resisted (5)
- Near-miss naming caught (5)
- Authority precedence enforced (5)
- Rollback path deterministic (5)
