# Sentinel Mode Doctrine (MB_SENTINEL_MODE_v1)

Purpose: stop continuous siege loops; preserve integrity while enabling real work.

## Default posture
- Run **light checks** by default (boot + validator).
- Only run Siege Mode on triggers.

## Siege triggers (any → run Siege Mode)
- New subsystem added (new top-level capability)
- New gate introduced or modified
- Ledger drift detected (hash chain break, missing entry)
- Bundle SHA changes without corresponding DeltaPack
- Environment change (different runtime constraints)

## Cadence
- Daily: boot + export validator + activation artifact presence
- Weekly: delta consolidation check (see churn rules)
- Monthly: mini-siege (1–2 injected failures)

## Consolidation rule
If **>10 micro-deltas** exist since last canonical bundle, require consolidation into a single canonical bundle + new baseline hash.

## Fail-closed
Any ambiguity blocks export. Any corruption blocks promotion.
