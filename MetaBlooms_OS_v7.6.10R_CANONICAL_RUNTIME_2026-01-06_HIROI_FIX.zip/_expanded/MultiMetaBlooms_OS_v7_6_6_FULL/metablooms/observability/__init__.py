"""OBSERVABILITY_CORE — mechanically generated control-surface outputs.

Public API:
  - generate_all(install_root: str, activation_artifact: str | None = None) -> dict
  - validate_observability(install_root: str) -> bool (raises on failure)

Invariants:
  - read-only introspection; no state mutation
  - write-only reports under <install_root>/metablooms/
"""

from .generators.generate_all import generate_all
from .validators.validate_observability import validate_observability, ObservabilityValidationError
