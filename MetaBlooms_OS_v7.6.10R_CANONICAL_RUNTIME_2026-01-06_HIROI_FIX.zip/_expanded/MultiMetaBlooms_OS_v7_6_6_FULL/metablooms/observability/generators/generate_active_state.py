import os, glob, json
from datetime import datetime, timezone

def _utc_now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def _load_template(install_root: str, name: str) -> str:
    tpath = os.path.join(install_root, "metablooms", "observability", "templates", name)
    with open(tpath, "r", encoding="utf-8") as f:
        return f.read()

def _read_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _scan_active_deltas(deltas_dir: str):
    if not deltas_dir or not os.path.isdir(deltas_dir):
        return ["(none)"]
    items=[]
    for p in sorted(glob.glob(os.path.join(deltas_dir,"delta_*.json"))):
        items.append(os.path.basename(p))
    return items or ["(none)"]

def generate_active_state(install_root: str, health: dict | None = None) -> str:
    mb_root = os.path.join(install_root, "metablooms")
    tpl = _load_template(install_root, "ACTIVE_STATE.md.template")

    # governance flags (best-effort, no inference)
    flags=[]
    # P0 zero local execution rule presence
    p0 = os.path.join(install_root,"governance","P0_ZERO_LOCAL_EXECUTION_RULE.json")
    if os.path.exists(p0):
        flags.append("P0_ZERO_LOCAL_EXECUTION: ENFORCED")
    else:
        flags.append("P0_ZERO_LOCAL_EXECUTION: (unknown)")

    # invariants list
    inv_list_path=os.path.join(mb_root,"invariants","ACTIVE_INVARIANTS.json")
    if os.path.exists(inv_list_path):
        try:
            invs=_read_json(inv_list_path)
            flags.append(f"ACTIVE_INVARIANTS: {len(invs)}")
        except Exception:
            flags.append("ACTIVE_INVARIANTS: (unreadable)")
    else:
        flags.append("ACTIVE_INVARIANTS: (none)")

    # governance certifications from HEALTH.json (truthful)
    certs="(none)"
    if health is not None:
        try:
            arr=health.get('governance_certifications') or []
            if arr:
                cert_lines=[]
                for c in arr:
                    cert_lines.append(f"- {c.get('kind')}: {c.get('status')} ({c.get('source')})")
                certs="\n".join(cert_lines)
        except Exception:
            pass
    health_path=os.path.join(mb_root,"HEALTH.json")
    if health is None and os.path.exists(health_path):
        try:
            h=_read_json(health_path)
            arr=h.get("governance_certifications") or []
            if arr:
                cert_lines=[]
                for c in arr:
                    cert_lines.append(f"- {c.get('kind')}: {c.get('status')} ({c.get('source')})")
                certs="\n".join(cert_lines)
        except Exception:
            certs="(unreadable)"

    active_deltas="\n".join(f"- {d}" for d in _scan_active_deltas(os.path.join(mb_root,"deltas")))
    content=tpl.format(
        generated_utc=_utc_now_iso(),
        boot_id="(see STATUS.md)",
        governance_certs=certs,
        governance_flags="\n".join(f"- {x}" for x in flags),
        active_deltas=active_deltas,
        current_mode="(unknown)",
        phase="(unknown)"
    )
    out_path=os.path.join(mb_root,"ACTIVE_STATE.md")
    with open(out_path,"w",encoding="utf-8") as f:
        f.write(content)
    return out_path
