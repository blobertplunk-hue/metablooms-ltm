import json, os, glob
from datetime import datetime, timezone

HEALTH_ENUM = {"HEALTHY","DEGRADED","FAILED"}

def _utc_now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def _read_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _count_lines(path: str) -> int:
    # Safe for moderate file sizes; these ledgers are expected to be append-only logs.
    n = 0
    with open(path, "rb") as f:
        for _ in f:
            n += 1
    return n


def _list_delta_files(deltas_dir: str):
    """Return sorted list of delta json filenames (absolute paths), excluding schemas/helpers."""
    if not deltas_dir or not os.path.isdir(deltas_dir):
        return []
    paths = []
    for p in glob.glob(os.path.join(deltas_dir, "delta_*.json")):
        base = os.path.basename(p)
        if base.startswith("deltapack_"):
            continue
        paths.append(p)
    return sorted(paths)



def _extract_mips_certs_from_obj(obj, source_name: str):
    certs = []
    if isinstance(obj, dict):
        if obj.get("kind") == "mips_certificate":
            certs.append(obj)
        # batchpack style: mips_header/body/files
        body = obj.get("body")
        if isinstance(body, dict) and "files" in body and isinstance(body.get("files"), list):
            for f in body.get("files"):
                content = f.get("content")
                if isinstance(content, str):
                    try:
                        content = json.loads(content)
                    except Exception:
                        content = None
                certs.extend(_extract_mips_certs_from_obj(content, f.get("name") or source_name))
        # embedded bodies style
        if isinstance(body, dict) and isinstance(body.get("embedded_bodies"), dict):
            for name, payload in body["embedded_bodies"].items():
                if isinstance(payload, str):
                    try:
                        payload = json.loads(payload)
                    except Exception:
                        payload = None
                certs.extend(_extract_mips_certs_from_obj(payload, name))
    elif isinstance(obj, list):
        for it in obj:
            certs.extend(_extract_mips_certs_from_obj(it, source_name))
    return certs

def _scan_governance_certificates(evidence_dir: str):
    """Scan evidence_dir for governance certificates (currently: mips_certificate).
    Supports:
      - direct certificate json (kind=mips_certificate)
      - BatchPack containers (mips_header/body/files with embedded json strings)
      - embedded_bodies containers
    Returns a list of dicts with minimally required fields.
    """
    if not evidence_dir or not os.path.isdir(evidence_dir):
        return []
    out = []
    for p in sorted(glob.glob(os.path.join(evidence_dir, "*.json"))):
        base = os.path.basename(p)
        try:
            obj = _read_json(p)
        except Exception:
            continue
        for c in _extract_mips_certs_from_obj(obj, base):
            out.append({
                "kind": c.get("kind"),
                "status": c.get("status"),
                "source": base,
                "timestamp": c.get("timestamp"),
                "councils": c.get("auditor_councils") or c.get("councils"),
                "guarantees": c.get("scorecard") or c.get("guarantees"),
                "sha256": c.get("sha256"),
                "artifact_id": c.get("artifact_id"),
                "subject": c.get("subject"),
            })
    return out

def generate_health(install_root: str, activation_artifact: str | None = None) -> dict:
    """Generate HEALTH.json under <install_root>/metablooms/HEALTH.json.

    This function must not guess. Unknowns become null and may downgrade to DEGRADED.
    """
    mb_root = os.path.join(install_root, "metablooms")
    if not os.path.isdir(mb_root):
        raise FileNotFoundError(f"metablooms root not found: {mb_root}")

    # Resolve activation artifact
    if activation_artifact is None:
        # Prefer most recent activation_status_*.json in control_plane/state_hub
        state_hub = os.path.join(install_root, "control_plane", "state_hub")
        candidates = sorted(glob.glob(os.path.join(state_hub, "activation_status_*.json")))
        if not candidates:
            raise FileNotFoundError("No activation_status_*.json found in control_plane/state_hub")
        activation_artifact = candidates[-1]

    activation = _read_json(activation_artifact)

    subsystems = {}
    boot_id = None
    os_version = None

    # activation is expected to be a dict of subsystem entries
    for name, payload in activation.items():
        if isinstance(payload, dict) and "status" in payload:
            subsystems[name] = payload.get("status")
        else:
            subsystems[name] = "UNKNOWN"

        # boot/session id may appear inside smoke/activation artifacts; best-effort extraction without guessing
        if isinstance(payload, dict):
            d = payload.get("detail") or {}
            if isinstance(d, dict):
                boot_id = boot_id or d.get("session_id") or d.get("boot_id")

    # Ledger counts
    ledger_dir = os.path.join(mb_root, "ledgers")
    ledger_counts = {"os": 0, "delta": 0, "chat": 0, "diff": 0}
    ledgers_found = {}
    if os.path.isdir(ledger_dir):
        # look for canonical ledger filenames (allow variants; do not guess content)
        for key in ["os","delta","chat","diff"]:
            matches = sorted(glob.glob(os.path.join(ledger_dir, f"*{key}*.*")))
            if matches:
                # pick most recent by mtime
                matches.sort(key=lambda p: os.path.getmtime(p))
                ledgers_found[key] = matches[-1]
                try:
                    ledger_counts[key] = _count_lines(matches[-1])
                except Exception:
                    ledger_counts[key] = None
            else:
                ledger_counts[key] = 0
    else:
        # ledgers missing is a P0 failure per contract
        raise FileNotFoundError(f"Ledger directory missing: {ledger_dir}")

    # Deltas active
    deltas_dir = os.path.join(install_root, "metablooms", "deltas")
    delta_files = _list_delta_files(deltas_dir)
    deltas_active = len(delta_files)
    last_delta = os.path.basename(delta_files[-1]) if delta_files else None
    deltas_dir = os.path.join(mb_root, "deltas")
    if os.path.isdir(deltas_dir):
        # count json files as a conservative proxy
        deltas_active = len(glob.glob(os.path.join(deltas_dir, "*.json")))
    else:
        deltas_dir = os.path.join(install_root, "metablooms", "deltas")
    delta_files = _list_delta_files(deltas_dir)
    deltas_active = len(delta_files)
    last_delta = os.path.basename(delta_files[-1]) if delta_files else None

    # mode/last activity are optional unless declared by system; do not infer
    current_mode = None
    last_activity = None

    # Determine health status: HEALTHY only if all subsystems ACTIVE and required counts are not None
    # If any subsystem is FAILED/INACTIVE/UNKNOWN -> DEGRADED unless a hard failure condition is hit.
    health_status = "HEALTHY"
    for s in subsystems.values():
        if s != "ACTIVE":
            health_status = "DEGRADED"
            break

    # If any required ledger count is None, degrade.
    if any(v is None for v in ledger_counts.values()):
        health_status = "DEGRADED"

    health = {
        "status": health_status,
        "timestamp": _utc_now_iso(),
        "boot_id": boot_id,
        "os_version": os_version,
        "activation_artifact": os.path.relpath(activation_artifact, install_root),
        "subsystems": subsystems,
        "deltas_active": deltas_active,
        "last_delta": last_delta,
        "ledger_counts": ledger_counts,
        "current_mode": current_mode,
        "last_activity": last_activity,
        "governance_certifications": _scan_governance_certificates(os.path.join(mb_root, "evidence")),
    }

    out_path = os.path.join(mb_root, "HEALTH.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(health, f, indent=2, sort_keys=True)
    return health
