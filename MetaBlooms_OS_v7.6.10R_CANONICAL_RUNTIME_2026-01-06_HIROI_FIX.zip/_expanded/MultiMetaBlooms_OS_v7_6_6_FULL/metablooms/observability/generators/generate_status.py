import os
from datetime import datetime, timezone
import json

def _utc_now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def _load_template(install_root: str, name: str) -> str:
    tpath = os.path.join(install_root, "metablooms", "observability", "templates", name)
    with open(tpath, "r", encoding="utf-8") as f:
        return f.read()

def _subsystems_table(subsystems: dict) -> str:
    lines = ["| Subsystem | Status |", "|---|---|"]
    for k in sorted(subsystems.keys()):
        lines.append(f"| {k} | {subsystems.get(k)} |")
    return "\n".join(lines)

def generate_status(install_root: str, health: dict) -> str:
    mb_root = os.path.join(install_root, "metablooms")
    tpl = _load_template(install_root, "STATUS.md.template")

    ledger_counts = health.get("ledger_counts") or {}
    ledger_lines = []
    for k in ["os","delta","chat","diff"]:
        ledger_lines.append(f"- {k}: {ledger_counts.get(k)}")
    ledger_counts_md = "\n".join(ledger_lines)

    last_delta = health.get("last_delta")

    certs = health.get("governance_certifications") or []
    if certs:
        lines = []
        for c in certs:
            lines.append(f"- {c.get('kind')}: {c.get('status')} ({c.get('source')})")
        governance_certs = "\n".join(lines)
    else:
        governance_certs = "(none)"

    content = tpl.format(
        generated_utc=_utc_now_iso(),
        boot_id=health.get("boot_id"),
        os_version=health.get("os_version"),
        health_status=health.get("status"),
        subsystems_table=_subsystems_table(health.get("subsystems") or {}),
        ledger_counts=ledger_counts_md,
        deltas_active=health.get("deltas_active"),
        current_mode=health.get("current_mode"),
        last_activity=health.get("last_activity"),
        last_delta=last_delta,
        governance_certs=governance_certs,
    )

    out_path = os.path.join(mb_root, "STATUS.md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)
    return out_path
