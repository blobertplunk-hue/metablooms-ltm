import os, glob, json
from datetime import datetime, timezone

def _utc_now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def _utc_date():
    return datetime.now(timezone.utc).date().isoformat()

def _load_template(install_root: str, name: str) -> str:
    tpath = os.path.join(install_root, "metablooms", "observability", "templates", name)
    with open(tpath, "r", encoding="utf-8") as f:
        return f.read()

def _read_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _iter_ledger_events(ledger_path: str, date_utc: str):
    # ledger entries are expected to be jsonl with ts_utc or timestamp fields
    if not ledger_path or not os.path.exists(ledger_path):
        return []
    out = []
    with open(ledger_path, "r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line:
                continue
            try:
                obj=json.loads(line)
            except Exception:
                continue
            ts=obj.get("ts_utc") or obj.get("timestamp") or obj.get("ts")
            if isinstance(ts,str) and ts.startswith(date_utc):
                out.append(obj)
    return out

def generate_changes_today(install_root: str) -> str:
    mb_root = os.path.join(install_root, "metablooms")
    tpl = _load_template(install_root, "WHAT_CHANGED_TODAY.md.template")
    date_utc = _utc_date()

    events_lines = []

    # Ledger-derived events (preferred)
    ledgers_dir = os.path.join(mb_root, "ledgers")
    if os.path.isdir(ledgers_dir):
        for name in ["os_ledger.jsonl","delta_ledger.jsonl","chat_ledger.jsonl","diff_ledger.jsonl","invariant_ledger.jsonl"]:
            lp=os.path.join(ledgers_dir,name)
            for ev in _iter_ledger_events(lp, date_utc):
                et=ev.get("event") or ev.get("type") or "EVENT"
                events_lines.append(f"LEDGER:{name} {et} {json.dumps(ev, sort_keys=True)}")

    # Filesystem scans (truthful fallback)
    # Deltas applied/present
    deltas_dir = os.path.join(mb_root, "deltas")
    if os.path.isdir(deltas_dir):
        for p in sorted(glob.glob(os.path.join(deltas_dir, "delta_*.json"))):
            events_lines.append(f"DELTA_PRESENT: {os.path.basename(p)}")

    # Governance evidence present
    ev_dir = os.path.join(mb_root, "evidence")
    if os.path.isdir(ev_dir):
        for p in sorted(glob.glob(os.path.join(ev_dir, "*.json"))):
            try:
                obj=_read_json(p)
            except Exception:
                continue
            if obj.get("kind") == "mips_certificate":
                events_lines.append(f"GOVERNANCE_EVIDENCE: {os.path.basename(p)} status={obj.get('status')}")

    if not events_lines:
        events_lines = ["(no events detected)"]

    content = tpl.format(
        date_utc=date_utc,
        generated_utc=_utc_now_iso(),
        events="\n".join(f"- {l}" for l in events_lines),
    )
    out_path = os.path.join(mb_root, "WHAT_CHANGED_TODAY.md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)
    return out_path
