#!/usr/bin/env python3
"""Generate MetaBlooms OS indexes.

Deterministic traversal with optional hashing.

Outputs (relative to repo root):
- metablooms/indexing/OS_INDEX_CANONICAL.json
- metablooms/indexing/OS_INDEX_VIEWS.json
- metablooms/indexing/OS_INDEX.md

Usage:
  python metablooms/indexing/generate_os_index.py

Notes:
- Hashing is skipped for files larger than MAX_HASH_BYTES.
- Files under ".git" are ignored if present.
"""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT_DIR = ROOT / 'metablooms' / 'indexing'
MAX_HASH_BYTES = 20 * 1024 * 1024  # 20 MB

def sha256_file(path: Path, chunk: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def classify(rel_path: str) -> tuple[str, list[str], str]:
    parts = rel_path.split('/')
    tags: set[str] = set()
    risk = 'low'
    lower = rel_path.lower()
    if parts and parts[0] in ('governance',):
        tags.add('governance')
        risk = 'high'
    if 'export' in lower:
        tags.add('export')
        risk = 'high'
    if 'boot' in lower:
        tags.add('boot')
        risk = 'high'
    if rel_path.startswith('metablooms/'):
        tags.add('runtime')
    if 'sandcrawler' in lower:
        tags.add('sandcrawler')
        risk = 'high'
    if 'ledger' in lower:
        tags.add('ledger')
    if 'validator' in lower or 'validate' in lower:
        tags.add('validation')
        risk = 'high'
    if 'governance' in tags:
        subsystem = 'governance'
    elif 'boot' in tags:
        subsystem = 'boot'
    elif 'export' in tags:
        subsystem = 'export'
    elif 'sandcrawler' in tags:
        subsystem = 'sandcrawler'
    elif 'ledger' in tags:
        subsystem = 'ledgers'
    elif 'validation' in tags:
        subsystem = 'validators'
    else:
        subsystem = 'core'
    return subsystem, sorted(tags), risk

def build_index(root: Path) -> list[dict]:
    entries: list[dict] = []
    for p in sorted(root.rglob('*')):
        if p.is_dir():
            continue
        rel = p.relative_to(root).as_posix()
        if rel.startswith('.git/'):
            continue
        size = p.stat().st_size
        digest = sha256_file(p) if size <= MAX_HASH_BYTES else None
        subsystem, tags, risk = classify(rel)
        entries.append({
            'path': rel,
            'bytes': size,
            'sha256': digest,
            'subsystem': subsystem,
            'tags': tags,
            'risk': risk,
        })
    return entries

def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    entries = build_index(ROOT)
    generated_at = datetime.now(timezone.utc).isoformat()
    canonical = {
        'generated_at': generated_at,
        'root': '.',
        'entry_count': len(entries),
        'entries': entries,
    }
    (OUT_DIR / 'OS_INDEX_CANONICAL.json').write_text(json.dumps(canonical, indent=2), encoding='utf-8')

    views = defaultdict(list)
    for e in entries:
        views[e['subsystem']].append(e['path'])
    views_doc = {
        'generated_at': generated_at,
        'views': {k: v for k, v in sorted(views.items())},
    }
    (OUT_DIR / 'OS_INDEX_VIEWS.json').write_text(json.dumps(views_doc, indent=2), encoding='utf-8')

    md_lines = [
        '# MetaBlooms OS Index (Generated)',
        '',
        f'Generated: {generated_at}',
        f'Entries: {len(entries)}',
        '',
        '## Views (by subsystem)',
        '',
    ]
    for k, v in sorted(views.items()):
        md_lines.append(f'### {k} ({len(v)})')
        for p in v[:80]:
            md_lines.append(f'- `{p}`')
        if len(v) > 80:
            md_lines.append(f'- ... ({len(v)-80} more)')
        md_lines.append('')
    (OUT_DIR / 'OS_INDEX.md').write_text('\n'.join(md_lines), encoding='utf-8')

    print('OK: generated OS indexes in', OUT_DIR)

if __name__ == '__main__':
    main()
