import json, os, datetime
from pathlib import Path

BASE = Path("/mnt/data/metablooms")

def _read_jsonl(p: Path):
    if not p.exists():
        return []
    out=[]
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line=line.strip()
        if not line: 
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            continue
    return out

def write_dashboard():
    ledgers = BASE / "ledgers"
    reports = BASE / "reports"
    reports.mkdir(parents=True, exist_ok=True)

    os_ledger = _read_jsonl(ledgers / "os_ledger.jsonl")
    delta_ledger = _read_jsonl(ledgers / "delta_ledger.jsonl")
    chat_ledger = _read_jsonl(ledgers / "chat_ledger.jsonl")

    active = [r for r in delta_ledger if r.get("status")=="ACTIVE"]
    revoked = {r.get("delta_id") for r in delta_ledger if r.get("status")=="REVOKED"}
    active_ids=[r.get("delta_id") for r in active if r.get("delta_id") not in revoked]

    status = f"""# MetaBlooms STATUS

Updated: {datetime.datetime.utcnow().replace(microsecond=0).isoformat()}Z

## Installed
- OS installs recorded: {len(os_ledger)}

## Deltas
- ACTIVE (net): {len(active_ids)}
- REVOKED: {len(revoked)}

## Chat ledger
- Records: {len(chat_ledger)}

## Pointers
- /mnt/data/metablooms/system (runnable payload)
- /mnt/data/metablooms/ledgers (append-only truth)
- /mnt/data/metablooms/deltas (DeltaPacks)
- /mnt/data/metablooms/transcripts (chat transcripts)
"""
    (BASE / "STATUS.md").write_text(status, encoding="utf-8")

    (reports / "ACTIVE_DELTAS.md").write_text("# Active Deltas\n\n" + "\n".join(f"- {d}" for d in active_ids) + "\n", encoding="utf-8")

    return str(BASE/"STATUS.md")
