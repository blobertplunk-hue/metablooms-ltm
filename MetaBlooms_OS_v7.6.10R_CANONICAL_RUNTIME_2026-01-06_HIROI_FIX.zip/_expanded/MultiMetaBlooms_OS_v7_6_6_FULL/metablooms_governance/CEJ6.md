## CEJ-6 Governance Gap
What rule was missing that allowed drift/failure.
