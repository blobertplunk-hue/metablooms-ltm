## CEJ-3 Failure Taxonomy
Trigger, symptom, permanence, mitigation, evidence pointer.
