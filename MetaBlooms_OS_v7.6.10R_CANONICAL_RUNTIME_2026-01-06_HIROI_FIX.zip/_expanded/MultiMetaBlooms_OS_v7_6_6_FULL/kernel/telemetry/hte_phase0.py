#!/usr/bin/env python3
"""HTE Phase 0 — Raw Observables logger.

Phase 0 logs only raw, observable events to NDJSON:
- tool lifecycle
- gate lifecycle
- eligibility assessment
- draft lifecycle counts (optional)
- temporal refs spans (optional)
- compliance markers

No derived scores. No synthesis.
"""

from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, uuid, datetime, hashlib, os
from typing import Any, Dict, Optional

def utc_now_iso() -> str:
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def _ensure_parent(p: Path) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)

def append_ndjson(path: Path, obj: Dict[str, Any]) -> None:
    _ensure_parent(path)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def new_event_id(prefix: str = "HP0") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"

def sha256_text(text: str) -> str:
    h = hashlib.sha256()
    h.update(text.encode("utf-8"))
    return "sha256:" + h.hexdigest()

def sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return "sha256:" + h.hexdigest()

def emit(os_root: Path, event: Dict[str, Any], ledger_rel: str = "ledgers/hte_raw.ndjson") -> None:
    """Emit a Phase 0 event to the raw ledger."""
    if "event_id" not in event:
        event["event_id"] = new_event_id()
    if "ts_utc_iso" not in event:
        event["ts_utc_iso"] = utc_now_iso()
    append_ndjson(os_root/ledger_rel, event)
