# POINTER — kernel/runtime

Runtime kernels (agent loop, tool registry, time sentinels, chat time gates).
