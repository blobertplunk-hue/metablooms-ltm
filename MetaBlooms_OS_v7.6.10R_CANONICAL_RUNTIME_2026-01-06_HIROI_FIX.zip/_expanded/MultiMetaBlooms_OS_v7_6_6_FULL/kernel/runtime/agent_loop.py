#!/usr/bin/env python3
"""MetaBlooms Agent Runtime Loop — v1.1 (deterministic, telemetry-wired)

This is a minimal, *working* runtime that demonstrates interleaving:
- The "planner" (LLM) is represented by a task contract (JSON) that lists steps.
- Python executes steps deterministically and logs raw observables (HTE Phase 0).
- Governance gates are logged (Phase 0), but enforcement is minimal here.

This file is intentionally dependency-free.
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Optional
import json, uuid, time

from kernel.runtime.common import append_ndjson, utc_now_iso
from kernel.telemetry.hte_phase0 import emit
from kernel.runtime.tool_registry import call_tool

def load_task(task_path: Path) -> Dict[str, Any]:
    return json.loads(task_path.read_text(encoding="utf-8"))

def run(os_root: Path, task: Dict[str, Any], *, chat_turn_id: Optional[str]=None) -> str:
    ledgers = os_root/"ledgers"
    run_id = task.get("run_id") or f"run-{uuid.uuid4().hex[:10]}"
    append_ndjson(ledgers/"agent.ndjson", {"event":"agent_start","run_id":run_id,"ts_utc_iso":utc_now_iso(),"task":task.get("objective")})

    # minimal eligibility + gate logic: mark eligible if step declares needs_web or needs_citations
    for i, step in enumerate(task.get("steps", [])):
        span_id = f"span-{i:04d}"
        step_type = step.get("type","note")

        # Eligibility assessment (raw)
        eligible = bool(step.get("eligible_tool", False) or step.get("needs_web", False) or step.get("needs_citations", False))
        reason_codes = []
        if step.get("needs_web"): reason_codes.append("RECENCY_RISK_OR_WEB_NEEDED")
        if step.get("needs_citations"): reason_codes.append("EMPIRICAL_CLAIM_DETECTED")
        if step.get("eligible_tool"): reason_codes.append("TOOL_ELIGIBLE")
        emit(os_root, {
            "run_id": run_id,
            "chat_turn_id": chat_turn_id,
            "span_id": span_id,
            "parent_event_id": None,
            "event_type": "eligibility_assessed",
            "actor": "kernel",
            "tool": None,
            "eligibility": {"eligible": eligible, "reason_codes": reason_codes, "policy_ref": "HTE-PHASE0"},
            "gate": None,
            "draft": None,
            "temporal_refs": None,
            "compliance": None,
            "note": f"step_index={i}, step_type={step_type}"
        })

        # Governance gate example (raw)
        if step.get("needs_citations"):
            emit(os_root, {
                "run_id": run_id,
                "chat_turn_id": chat_turn_id,
                "span_id": span_id,
                "parent_event_id": None,
                "event_type": "gate_triggered",
                "actor": "gate",
                "tool": None,
                "eligibility": None,
                "gate": {"name": "CitationRequired", "policy_ref": "CEEL-v0", "result": "WARN", "error_code": None},
                "draft": None,
                "temporal_refs": None,
                "compliance": None,
                "note": "Raw gate trigger only; enforcement occurs in higher layers."
            })

        # Execute step (minimal)
        append_ndjson(ledgers/"agent.ndjson", {"event":"step_execute","run_id":run_id,"ts_utc_iso":utc_now_iso(),"step_index":i,"step":step})

        if step_type == "tool_call":
            tool_name = step.get("tool_name","filesystem.noop")
            provider = step.get("provider","local")
            request_id = step.get("request_id")
            _ = call_tool(os_root, run_id=run_id, chat_turn_id=chat_turn_id, span_id=span_id,
                          tool_name=tool_name, provider=provider, args=step.get("args",{}),
                          request_id=request_id, allow_external=bool(step.get("allow_external", False)))
        else:
            # note only
            emit(os_root, {
                "run_id": run_id,
                "chat_turn_id": chat_turn_id,
                "span_id": span_id,
                "parent_event_id": None,
                "event_type": "note",
                "actor": "assistant",
                "tool": None,
                "eligibility": None,
                "gate": None,
                "draft": None,
                "temporal_refs": None,
                "compliance": None,
                "note": step.get("note") or f"step_type={step_type}"
            })

        time.sleep(0.005)

    append_ndjson(ledgers/"agent.ndjson", {"event":"agent_complete","run_id":run_id,"ts_utc_iso":utc_now_iso(),"status":"ok"})
    return run_id

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--os_root", default=".", help="MetaBlooms OS root path")
    ap.add_argument("--task", required=True, help="Path to task json")
    ap.add_argument("--chat_turn_id", default=None)
    args = ap.parse_args()
    run(Path(args.os_root), load_task(Path(args.task)), chat_turn_id=args.chat_turn_id)

if __name__ == "__main__":
    main()
