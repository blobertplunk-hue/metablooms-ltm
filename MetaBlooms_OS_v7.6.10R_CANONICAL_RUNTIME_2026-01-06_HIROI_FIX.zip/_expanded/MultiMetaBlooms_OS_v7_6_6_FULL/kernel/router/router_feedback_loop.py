#!/usr/bin/env python3
"""
Router Feedback Loop v0.1
Reads HTDL + Pilot ledger and computes domain risk hints.
Writes kernel/router/domain_risk.json (append-only overwrite allowed as derived view).
"""
from __future__ import annotations
import json
from pathlib import Path
from collections import defaultdict

OS_ROOT = Path(__file__).resolve().parents[2]
HTDL = OS_ROOT / "kernel" / "telemetry" / "htdl" / "htdl.ndjson"
PILOT = OS_ROOT / "modules" / "pilot_promotion" / "pilot_ledger.ndjson"
OUT = OS_ROOT / "kernel" / "router" / "domain_risk.json"

def iter_ndjson(p: Path):
    if not p.exists():
        return
    with p.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except Exception:
                continue

def main():
    stats = defaultdict(lambda: {
        "htdl_events": 0,
        "catastrophic_miss": 0,
        "high_severity": 0,
        "pilot_pass": 0,
        "pilot_fail": 0,
    })

    for rec in iter_ndjson(HTDL):
        stats[rec.get("heuristic_intent", {}).get("domain","UNKNOWN")]["htdl_events"] += 1
        div = rec.get("divergence")
        if div:
            sev = div.get("severity")
            if sev == "high":
                stats[div.get("domain","UNKNOWN")]["high_severity"] += 1
            if div.get("match_type") == "catastrophic_miss":
                stats[div.get("domain","UNKNOWN")]["catastrophic_miss"] += 1

    for rec in iter_ndjson(PILOT):
        d = rec.get("domain","UNKNOWN")
        if rec.get("event") == "promotion_applied":
            # promotion implies pilot passed earlier; keep simple
            stats[d]["pilot_pass"] += 1
        if rec.get("event") == "pilot_run":
            if rec.get("passed"):
                stats[d]["pilot_pass"] += 1
            else:
                stats[d]["pilot_fail"] += 1

    # derived risk score (simple v0)
    derived = {}
    for d, s in stats.items():
        risk = 0
        risk += 3 * s["catastrophic_miss"]
        risk += 2 * s["high_severity"]
        risk += 2 * s["pilot_fail"]
        risk -= 1 * s["pilot_pass"]
        derived[d] = {**s, "risk_score": max(risk, 0)}

    OUT.write_text(json.dumps({
        "version":"0.1",
        "derived": derived
    }, indent=2), encoding="utf-8")

    print(f"Wrote {OUT}")

if __name__ == "__main__":
    main()
