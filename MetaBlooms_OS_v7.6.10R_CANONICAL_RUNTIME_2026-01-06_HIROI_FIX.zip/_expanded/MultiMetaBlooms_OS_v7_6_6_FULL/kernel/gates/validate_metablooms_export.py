#!/usr/bin/env python3
"""
MetaBlooms Export Validator (Fail-Closed) — v0.6
Generated UTC: 2025-12-31_161317Z
"""
from pathlib import Path
import argparse, json, hashlib

REQUIRED_FILES = [
  "START_HERE.md","README.md","INVARIANTS.json","EXPORT_CHECKLIST.md","CHANGES_SINCE_LAST.md",
  "manifests/MANIFEST_SYSTEM_INDEX.json","manifests/MANIFEST_KERNEL.json","manifests/MANIFEST_MODULES.json",
  "config/TIME_SOURCE_POLICY_v1.json",
  "kernel/runtime/time_sentinel.py",
  "kernel/runtime/chat_time_gate.py"
]

REQUIRED_GOV = [
  "governance/MB_PREFLIGHT_REALITY_ENGINE_PRE-1.0.md",
  "governance/MB_SYSTEM_LEVEL_GRABBER_SLG-1.0.md",
  "governance/MB_EXPECTED_FAILURES_LAYER_EFL-1.0.md",
  "governance/MB_MEMORY_PROMOTION_CONTRACT_MPC-1.0.md",
  "export_gate/EXPORT_GATE_MINIMUMS.json",
  "governance/kic/KIC_SCHEMA.json"
]

def sha256(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def map_files(root):
    return {str(p.relative_to(root)):sha256(p) for p in root.rglob("*") if p.is_file()}

def fail(msg):
    print("VALIDATION_FAIL:", msg); raise SystemExit(2)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--os",required=True)
    ap.add_argument("--prev")
    args=ap.parse_args()
    os_root=Path(args.os)

    for f in REQUIRED_FILES:
        if not (os_root/f).exists(): fail(f"missing {f}")
    for f in REQUIRED_GOV:
        if not (os_root/f).exists(): fail(f"missing {f}")

    # README coverage marker
    readme=(os_root/"README.md").read_text()
    if "## README coverage index (completeness gate)" not in readme:
        fail("README coverage marker missing")

    # Wayfinding
    sh=(os_root/"START_HERE.md").read_text()
    for tok in ["README.md","MANIFEST_SYSTEM_INDEX.json","validate_metablooms_export.py","versions/"]:
        if tok not in sh: fail("START_HERE missing pointer")

    for d in [p for p in os_root.iterdir() if p.is_dir()]:
        if not (d/"POINTER.md").exists(): fail(f"missing POINTER.md in {d.name}")

    if args.prev:
        prev=Path(args.prev)
        removed=set(map_files(prev))-set(map_files(os_root))
        if removed: fail("removed files detected")

    print("VALIDATION_PASS")

if __name__=="__main__": main()
