# MetaBlooms — Entry Point (Merged Canonical v4)

This ZIP is your existing MetaBlooms OS bundle (v3.3 runnable) with governance subsystems added:
- CRP-1.1 (Rigor)
- CSP-1.1 (Continuation)
- MIHP-1.0 (Identity Heartbeat, X=3)

## Runtime entrypoint
- Primary executable entrypoint remains: `RUN_METABLOOMS.py` (root)

## How to start (chat-side governance)
1. Paste `metablooms_governance/CRP-1.1.md`
2. Paste `metablooms_governance/CSP-1.1.md`
3. Paste `metablooms_governance/MIHP-1.0.md`
4. Declare Job + Mode, then proceed.

## Notes
- This bundle does NOT replace MetaBlooms OS. It augments it.
- All original files from the runnable OS bundle are preserved.


---

## Standing invariant
This bundle enforces P0: **Zero Local Execution by User**. See `docs/STANDING_INVARIANTS.md`.
