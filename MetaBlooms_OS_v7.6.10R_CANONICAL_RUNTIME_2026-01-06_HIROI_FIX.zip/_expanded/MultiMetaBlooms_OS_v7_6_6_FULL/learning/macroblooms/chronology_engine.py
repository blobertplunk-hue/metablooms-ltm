"""MetaBlooms Chronology Engine (P0) — v2

Design goals:
- Append-only NDJSON event log (streamable, resilient).
- Dual time: physical UTC timestamp + logical (Lamport-style) clock for causality.
- Tamper-evident integrity via hash chaining.
- Gates that *refuse* time/duration/order claims without CEO evidence.

Files (relative to provided root):
  _TDL/chronology/chronology.ndjson        (append-only log)
  _TDL/chronology/chronology.index.json   (optional rebuilt index)
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import uuid
from typing import Any, Dict, Iterable, List, Optional, Tuple


LOG_VERSION = "ceo-v2"
REL_DIR = Path("_TDL/chronology")
LOG_PATH = REL_DIR / "chronology.ndjson"

# In-process logical clock. If you run multiple processes, persist/merge as needed.
_L_CLOCK = 0


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _canonical_json(obj: Dict[str, Any]) -> bytes:
    # Canonical-ish: stable key order, no whitespace
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _ensure_dirs(root: Path) -> Path:
    d = root / REL_DIR
    d.mkdir(parents=True, exist_ok=True)
    return d


def _read_last_line(root: Path) -> Optional[bytes]:
    p = root / LOG_PATH
    if not p.exists() or p.stat().st_size == 0:
        return None
    # Read tail efficiently
    with p.open("rb") as f:
        f.seek(0, 2)
        end = f.tell()
        # read last ~8KB
        chunk = min(8192, end)
        f.seek(-chunk, 2)
        buf = f.read(chunk)
    lines = [ln for ln in buf.splitlines() if ln.strip()]
    return lines[-1] if lines else None


def _get_prev_hash_and_seq(root: Path) -> Tuple[Optional[str], int]:
    last = _read_last_line(root)
    if not last:
        return None, 0
    try:
        rec = json.loads(last.decode("utf-8"))
        return rec.get("hash_self"), int(rec.get("seq", 0)) + 1
    except Exception:
        # If log corrupted, refuse to proceed; caller should repair.
        raise RuntimeError("Chronology log tail is unreadable; refuse append (fail-closed).")


def _tick_lamport(incoming: Optional[int] = None) -> int:
    global _L_CLOCK
    if incoming is None:
        _L_CLOCK += 1
    else:
        _L_CLOCK = max(_L_CLOCK, int(incoming)) + 1
    return _L_CLOCK


@dataclass
class CEO:
    log_version: str
    id: str
    ts_utc: str
    source: str
    actor_id: str
    context: str
    event_name: str
    event_type: str  # internal/external/reconstructed/logical_order
    logical_clock: int
    seq: int
    parent_event_ids: List[str]
    evidence_refs: List[str]
    metadata: Dict[str, Any]
    hash_prev: Optional[str]
    hash_self: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def new_ceo(
    *,
    root: Path,
    event_name: str,
    actor_id: str,
    context: str,
    source: str = "internal",
    event_type: str = "internal",
    evidence_refs: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    parent_event_ids: Optional[List[str]] = None,
    incoming_logical_clock: Optional[int] = None,
) -> CEO:
    """Create a CEO but do not persist it yet."""
    if event_type not in {"internal","external","reconstructed","logical_order"}:
        raise ValueError(f"Invalid event_type: {event_type}")

    evidence_refs = evidence_refs or []
    metadata = metadata or {}
    parent_event_ids = parent_event_ids or []

    prev_hash, seq = _get_prev_hash_and_seq(root)
    l_clock = _tick_lamport(incoming_logical_clock)

    base = {
        "log_version": LOG_VERSION,
        "id": str(uuid.uuid4()),
        "ts_utc": _now_utc_iso(),
        "source": source,
        "actor_id": actor_id,
        "context": context,
        "event_name": event_name,
        "event_type": event_type,
        "logical_clock": l_clock,
        "seq": seq,
        "parent_event_ids": parent_event_ids,
        "evidence_refs": evidence_refs,
        "metadata": metadata,
        "hash_prev": prev_hash,
    }
    # hash_self is hash of canonical JSON including hash_prev, excluding hash_self
    hash_self = _sha256_bytes(_canonical_json(base))
    base["hash_self"] = hash_self
    return CEO(**base)  # type: ignore[arg-type]


def append_ceo(root: Path, ceo: CEO) -> CEO:
    """Append CEO to NDJSON log. Fail-closed if hash chain/seq mismatch."""
    _ensure_dirs(root)
    # Validate tail matches ceo.hash_prev and seq
    prev_hash, expected_seq = _get_prev_hash_and_seq(root)
    if ceo.hash_prev != prev_hash:
        raise RuntimeError("Hash chain mismatch; refuse append (fail-closed).")
    if ceo.seq != expected_seq:
        raise RuntimeError("Sequence mismatch; refuse append (fail-closed).")

    line = _canonical_json(ceo.to_dict()) + b"\n"
    with (root / LOG_PATH).open("ab") as f:
        f.write(line)
    return ceo


def iter_ceos(root: Path) -> Iterable[Dict[str, Any]]:
    p = root / LOG_PATH
    if not p.exists():
        return []
    def _gen():
        with p.open("rb") as f:
            for raw in f:
                raw = raw.strip()
                if not raw:
                    continue
                yield json.loads(raw.decode("utf-8"))
    return _gen()


def build_index(root: Path) -> Dict[str, Any]:
    """Rebuild an index for fast lookup; does not change the append-only log."""
    ceos = list(iter_ceos(root))
    by_id = {c["id"]: c for c in ceos}
    index = {
        "generated_at_utc": _now_utc_iso(),
        "count": len(ceos),
        "by_id_keys": len(by_id),
        "last_seq": ceos[-1]["seq"] if ceos else None,
        "last_hash": ceos[-1]["hash_self"] if ceos else None,
    }
    idx_path = root / REL_DIR / "chronology.index.json"
    idx_path.write_text(json.dumps(index, indent=2), encoding="utf-8")
    return index


# -------------------------
# Gates (P0)
# -------------------------

def gate_require_events(root: Path, event_ids: List[str]) -> Tuple[bool, str]:
    by_id = {c["id"]: c for c in iter_ceos(root)}
    missing = [eid for eid in event_ids if eid not in by_id]
    if missing:
        return False, f"Missing CEO ids: {missing}"
    return True, "ok"


def _parse_ts(ts: str) -> datetime:
    # Python 3.11: fromisoformat supports offsets; ensure timezone-aware
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        raise ValueError("timestamp missing tzinfo")
    return dt.astimezone(timezone.utc)


def gate_duration(
    root: Path,
    start_id: str,
    end_id: str,
    *,
    min_seconds: Optional[float] = None,
    max_seconds: Optional[float] = None,
) -> Tuple[bool, str, Optional[float]]:
    """Fail-closed duration gate: no CEOs => no duration claims."""
    by_id = {c["id"]: c for c in iter_ceos(root)}
    if start_id not in by_id or end_id not in by_id:
        return False, "missing start/end CEO", None

    s = _parse_ts(by_id[start_id]["ts_utc"])
    e = _parse_ts(by_id[end_id]["ts_utc"])
    delta = (e - s).total_seconds()

    if delta < 0:
        return False, "negative duration (time travel)", delta
    if min_seconds is not None and delta < min_seconds:
        return False, f"duration {delta}s < min {min_seconds}s", delta
    if max_seconds is not None and delta > max_seconds:
        return False, f"duration {delta}s > max {max_seconds}s", delta
    return True, "ok", delta


def gate_order(
    root: Path,
    before_id: str,
    after_id: str,
    *,
    require_lamport: bool = False,
) -> Tuple[bool, str]:
    """Fail-closed ordering gate using physical time and optional Lamport clock."""
    by_id = {c["id"]: c for c in iter_ceos(root)}
    if before_id not in by_id or after_id not in by_id:
        return False, "missing before/after CEO"

    b = by_id[before_id]
    a = by_id[after_id]
    bt = _parse_ts(b["ts_utc"])
    at = _parse_ts(a["ts_utc"])
    if bt > at:
        return False, "timestamp order violated"
    if require_lamport and int(b["logical_clock"]) > int(a["logical_clock"]):
        return False, "lamport order violated"
    return True, "ok"


# -------------------------
# External evidence capture (web.run integration pattern)
# -------------------------

def make_external_ceo_from_webrun(
    *,
    root: Path,
    actor_id: str,
    context: str,
    query: str,
    parsed_ts_utc: str,
    web_source_ref: str,
    evidence_url: Optional[str] = None,
    notes: Optional[str] = None,
) -> CEO:
    """Create a CEO for an external timestamp, anchored to a web.run source ref id."""
    meta = {
        "query": query,
        "parsed_ts_utc": parsed_ts_utc,
        "web_source_ref": web_source_ref,
        "evidence_url": evidence_url,
        "notes": notes,
    }
    ceo = new_ceo(
        root=root,
        event_name=f"external_time:{query}",
        actor_id=actor_id,
        context=context,
        source="web.run",
        event_type="external",
        evidence_refs=[web_source_ref] + ([evidence_url] if evidence_url else []),
        metadata=meta,
    )
    # overwrite physical ts_utc with parsed external ts, but keep ingestion time in metadata
    d = ceo.to_dict()
    d["metadata"]["ingested_at_utc"] = d["ts_utc"]
    d["ts_utc"] = parsed_ts_utc
    # recompute hash_self because ts_utc changed
    base = dict(d)
    base.pop("hash_self", None)
    base["hash_self"] = _sha256_bytes(_canonical_json({k: base[k] for k in base if k != "hash_self"}))
    return CEO(**base)  # type: ignore[arg-type]
