def enforce(intent: str):
    if 'os' in intent.lower() or 'boot' in intent.lower():
        return {'required_primary_artifact': 'full_os_zip', 'pass': True}
    return {'pass': True}
