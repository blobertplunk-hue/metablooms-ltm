"""P0 Intent-to-Artifact Lock

Purpose:
- Infer and LOCK primary artifact class at the earliest moment.
- Prevent mid-conversation artifact drift.

Rules:
- If intent implies OS/boot/release, primary artifact is FULL_OS_ZIP.
- Once locked, cannot be downgraded.
"""

LOCKED = None

def infer_and_lock(intent: str):
    global LOCKED
    if LOCKED:
        return LOCKED
    intent_l = intent.lower()
    if any(k in intent_l for k in ["os", "boot", "release", "ship"]):
        LOCKED = "FULL_OS_ZIP"
    else:
        LOCKED = "NON_OS"
    return LOCKED

def enforce(current_output_class: str):
    if LOCKED == "FULL_OS_ZIP" and current_output_class != "FULL_OS_ZIP":
        return {
            "pass": False,
            "reason": "Primary artifact contract violated: OS requested."
        }
    return {"pass": True}
