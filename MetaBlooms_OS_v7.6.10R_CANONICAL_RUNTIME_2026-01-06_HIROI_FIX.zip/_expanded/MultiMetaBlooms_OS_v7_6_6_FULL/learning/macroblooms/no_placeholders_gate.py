def validate_sources(sources):
    if not sources:
        return {'status': 'info'}
    return {'status': 'ok'}
