from pathlib import Path
import zipfile, time
def build_release(root: Path, out_zip: Path):
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in root.rglob('*'):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(root)))
    return {'output': str(out_zip), 'generated_at': time.time()}
