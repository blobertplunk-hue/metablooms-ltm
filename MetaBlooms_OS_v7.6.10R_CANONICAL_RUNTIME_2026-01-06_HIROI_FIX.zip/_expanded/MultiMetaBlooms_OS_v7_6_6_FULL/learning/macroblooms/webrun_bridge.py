"""MetaBlooms Chronology ↔ web.run Bridge (P0)

IMPORTANT CONSTRAINT:
- Runtime Python in the sandbox has NO internet access.
- Therefore, the Chronology Engine cannot call web.run directly.
- Integration is *orchestrated*: the caller (assistant) runs web.run,
  extracts/normalizes a timestamp, then calls `make_external_ceo_from_webrun`.

This file defines:
- a minimal "ResolvedExternalTime" payload contract
- helpers to normalize ISO-8601 timestamps
- a strict builder that refuses to create an external CEO if evidence is incomplete
"""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Dict, Any


@dataclass
class ResolvedExternalTime:
    query: str
    parsed_ts_utc: str              # ISO 8601 UTC, e.g. 2025-10-21T00:00:00+00:00
    web_source_ref: str             # e.g. turn3search2 (or equivalent evidence handle)
    evidence_url: Optional[str] = None
    evidence_snippet: Optional[str] = None
    extractor: Optional[str] = None # how parsing occurred (regex/dateutil/manual)
    confidence: str = "high"        # high/medium/low


def normalize_iso_utc(dt_str: str) -> str:
    """Normalize an ISO-ish timestamp to timezone-aware UTC ISO format.

    Accepts common variants like 'Z' suffix.
    """
    dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        # Fail-closed: external timestamps must be timezone-aware
        raise ValueError("External timestamp missing timezone info")
    return dt.astimezone(timezone.utc).isoformat()


def require_resolved(payload: Dict[str, Any]) -> ResolvedExternalTime:
    """Validate an orchestration-provided resolved-time payload."""
    for k in ("query","parsed_ts_utc","web_source_ref"):
        if not payload.get(k):
            raise ValueError(f"Missing required field: {k}")
    parsed = normalize_iso_utc(str(payload["parsed_ts_utc"]))
    return ResolvedExternalTime(
        query=str(payload["query"]),
        parsed_ts_utc=parsed,
        web_source_ref=str(payload["web_source_ref"]),
        evidence_url=payload.get("evidence_url"),
        evidence_snippet=payload.get("evidence_snippet"),
        extractor=payload.get("extractor"),
        confidence=payload.get("confidence","high"),
    )
