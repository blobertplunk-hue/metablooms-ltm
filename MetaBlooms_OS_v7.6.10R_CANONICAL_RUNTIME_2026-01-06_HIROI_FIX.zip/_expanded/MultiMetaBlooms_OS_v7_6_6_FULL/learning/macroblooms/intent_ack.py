"""Intent Lock Acknowledgment (User-visible)

This module provides a single canonical function to emit a user-visible
acknowledgment and to persist the lock state as artifacts.

Outputs (under root/_TDL/):
- intent_lock_status.json
- intent_lock_status.md
"""

from pathlib import Path
import json, time

def acknowledge(root: Path, locked_class: str, intent: str, extra=None):
    out_dir = root / "_TDL"
    out_dir.mkdir(exist_ok=True)

    payload = {
        "locked_primary_artifact": locked_class,
        "intent": intent,
        "generated_at": time.time()
    }

    (out_dir / "intent_lock_status.json").write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8"
    )

    md = (
        "# Intent Lock Status\n\n"
        f"- Locked primary artifact: **{locked_class}**\n"
        f"- Intent: `{intent}`\n"
        f"- Generated at (unix): `{payload['generated_at']}`\n"
    )
    (out_dir / "intent_lock_status.md").write_text(md, encoding="utf-8")

    # Also return a short string intended to be printed to console/logs
    return f"PRIMARY_ARTIFACT_LOCKED={locked_class}"
