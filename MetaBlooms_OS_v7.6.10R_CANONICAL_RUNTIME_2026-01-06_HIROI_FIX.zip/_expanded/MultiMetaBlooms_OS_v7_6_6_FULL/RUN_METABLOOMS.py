#!/usr/bin/env python3
"""RUN_METABLOOMS.py — Canonical runtime entrypoint

Fail-closed invariants:
- BOOT_OK is printed ONLY after:
    * control plane loads
    * all shipped subsystems activate
    * required subsystems are ACTIVE
    * activation status artifact is written
    * smoke test record is written
"""

import datetime
import json
import os
import sys
from control_plane.mandatory_chat_capture import write_mandatory_chat_capture

from control_plane.activation_registry import ActivationRegistry
from control_plane.boot_activator import activate_all, required_list

SUCCESS_SIGNAL = "BOOT_OK"
FAILURE_SIGNAL = "BOOT_FAILED"

def boot_fail(code: str, detail: str = "") -> None:
    print(f"{FAILURE_SIGNAL}: {code}", flush=True)
    if detail:
        print(detail, flush=True)
    raise SystemExit(1)

def main() -> int:
    # 1) Load control plane boot state (hard requirement)
    try:
        with open(os.path.join("control_plane", "BOOT_STATE.json"), "r", encoding="utf-8") as f:
            boot_state = json.load(f)
    except Exception as e:
        boot_fail("CONTROL_PLANE_ERROR", str(e))

    # 2) Activate all subsystems (no dormant capability)
    registry = ActivationRegistry()
    activation_report = activate_all(registry)

    # 3) Enforce required subsystems
    try:
        registry.require_active(required_list())
    except Exception as e:
        boot_fail("ACTIVATION_GATE_FAILED", str(e))

    # 4) Write artifacts (observable receipts)
    state_hub = os.path.join("control_plane", "state_hub")
    os.makedirs(state_hub, exist_ok=True)

    session_id = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    # 0) Mandatory chat capture hook (non-dormant)
    try:
        _cc_path = write_mandatory_chat_capture(state_hub, session_id, context={"invocation": "RUN_METABLOOMS"})
    except Exception as e:
        boot_fail("CHAT_CAPTURE_ERROR", str(e))

    activation_path = registry.write_artifact(state_hub, filename=f"activation_status_{session_id}.json")

    smoke_record = {
        "session_id": session_id,
        "timestamp_utc": datetime.datetime.utcnow().isoformat() + "Z",
        "task": "boot_smoke_test",
        "result": "success",
        "boot_state_keys": sorted(list(boot_state.keys())) if isinstance(boot_state, dict) else [],
        "activation_artifact": activation_path,
    }
    with open(os.path.join(state_hub, f"smoke_{session_id}.json"), "w", encoding="utf-8") as f:
        json.dump(smoke_record, f, indent=2)

    # 5) Success signals (only now)
    print(SUCCESS_SIGNAL, flush=True)
    print("MetaBlooms OS READY", flush=True)
    print(f"ACTIVATION_ARTIFACT: {activation_path}", flush=True)
    print("TASK_EXECUTED: boot_smoke_test", flush=True)

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
