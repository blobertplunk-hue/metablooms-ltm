
import json, os, hashlib

def enforce_active_deltas(ledger_path, deltas_dir):
    if not os.path.exists(ledger_path):
        return []
    active = []
    revoked = set()
    with open(ledger_path) as f:
        for line in f:
            rec = json.loads(line)
            if rec.get("status") == "REVOKED":
                revoked.add(rec["delta_id"])
            elif rec.get("status") == "ACTIVE":
                active.append(rec)
    enforced = []
    for rec in active:
        if rec["delta_id"] in revoked:
            continue
        path = os.path.join(deltas_dir, rec["delta_id"] + ".json")
        if not os.path.exists(path):
            raise SystemExit(f"DELTA_MISSING: {rec['delta_id']}")
        with open(path) as f:
            dp = json.load(f)
        body = json.dumps({k:v for k,v in dp.items() if k!="hash_sha256"}, sort_keys=True).encode()
        if hashlib.sha256(body).hexdigest() != rec["hash_sha256"]:
            raise SystemExit(f"DELTA_TAMPERED: {rec['delta_id']}")
        enforced.append(rec["delta_id"])
    return enforced
