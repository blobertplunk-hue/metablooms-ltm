# MetaBlooms — Shopping Mode Controller (SMC v1)
# Purpose: deterministic controller that keeps "shopping" (structured recommendation)
# from drifting when constraints change late. This module MUST be activated during boot.
from __future__ import annotations
from typing import Any, Dict, List
import json, os

from pathlib import Path

_BASE = Path(__file__).resolve().parent
RULES_PATH = str(_BASE / "SHOPPING_MODE_CONTROLLER_RULES_v1.json")
TESTS_PATH = str(_BASE / "SHOPPING_MODE_CONTROLLER_TESTS_v1.json")

MODES = ("FIND", "EVALUATE", "FINE_TUNE")

def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def decide_next_mode(start_mode: str, event: Dict[str, Any], context: Dict[str, Any], rules: Dict[str, Any]) -> str:
    """Deterministic mode controller.

    The shipped JSON tests (SHOPPING_MODE_CONTROLLER_TESTS_v1.json) are authoritative.

    Rules (v1):
    - Signals that REQUIRE (re)search => FIND
        * user_requests_specific_products, user_requests_links
        * use_case_changed, stacking_required
        * fails_fit, violates_must_have, stack_failure, taper_unacceptable
    - Constraint corrections/changes:
        * If expands_search_space OR invalidates_top_pick => FIND
        * Else => EVALUATE (do not jump all the way back to FIND)
    - Otherwise: keep current mode.
    """
    if start_mode not in MODES:
        raise ValueError(f"Unknown start_mode: {start_mode}")

    signals = set(event.get("signals", []) or [])
    expands = bool(context.get("expands_search_space"))
    invalidates = bool(context.get("invalidates_top_pick"))

    requires_search = {
        "user_requests_specific_products",
        "user_requests_links",
        "use_case_changed",
        "stacking_required",
        "fails_fit",
        "violates_must_have",
        "stack_failure",
        "taper_unacceptable",
    }
    if signals & requires_search:
        return "FIND"

    if "constraint_changed" in signals or "spec_corrected" in signals:
        return "FIND" if (expands or invalidates) else "EVALUATE"

    return start_mode

def run_tests() -> Dict[str, Any]:
    rules = load_json(RULES_PATH)
    tests = load_json(TESTS_PATH)
    cases: List[Dict[str, Any]] = tests.get("tests", [])
    results = []
    ok = True
    for tc in cases:
        try:
            got = decide_next_mode(
                start_mode=tc.get("start_mode", "FIND"),
                event=tc.get("event", {}),
                context=tc.get("context", {}),
                rules=rules,
            )
            exp = tc.get("expected_mode")
            passed = (got == exp)
            if not passed:
                ok = False
            results.append({"id": tc.get("id"), "expected": exp, "got": got, "passed": passed})
        except Exception as e:
            ok = False
            results.append({"id": tc.get("id"), "error": str(e), "passed": False})
    return {"ok": ok, "results": results, "rules_status": rules.get("status"), "schema": rules.get("schema_version")}

def activate(registry) -> Dict[str, Any]:
    # activation = load rules + run tests + register ACTIVE or ERROR
    rules = load_json(RULES_PATH)
    test_report = run_tests()
    if not test_report.get("ok"):
        registry.set_error("SHOPPING_MODE_CONTROLLER", "TESTS_FAILED", test_report=test_report)
        return test_report
    registry.set_active(
        "SHOPPING_MODE_CONTROLLER",
        schema=rules.get("schema_version"),
        rules_status=rules.get("status"),
        test_count=len(test_report.get("results", [])),
    )
    return test_report
