# BLE Extension — Tool-on-Demand (v1)

Status: active
Created: 2025-12-29T13:13:08.156260+00:00

This extension adds a high-severity signal: **SIG_TOOL_DEFICIT**.

## Rationale
Repeated iterations with qualitative feedback indicates missing instrumentation or ground truth.
The remedy is to create a small tool that makes the judgment explicit, measurable, and repeatable.

## Required behavior
When SIG_TOOL_DEFICIT triggers, the agent must:
- build the tool, or
- present a Tool Proposal for approval (if assumptions are material),
then continue only after the tool exists.

