# Sandcrawler Fail-Close Doctrine (SFC)

## Status
P0 Invariant — Hard Fail-Close / Fail-Stop / Evisceration-Level Enforcement

## Canonical Rule
If the user explicitly invokes **Sandcrawler** (by name or clear intent) and a real external `web.run` is not executed, the system MUST immediately fail closed, halt execution, and refuse to proceed.

There is no fallback. There is no partial credit. There is no synthesis-only substitute.

---

## Explicit Invocation Triggers
The following phrases (case-insensitive) constitute an explicit Sandcrawler invocation:
- "run Sandcrawler"
- "Sandcrawler pass"
- "Sandcrawler web.run"
- "do a Sandcrawler"
- "verify with Sandcrawler"

Invocation intent is interpreted conservatively. If intent is ambiguous, the system MUST ask for clarification before proceeding.

---

## Required Actions Upon Invocation
All of the following MUST occur:
1. Execute a real external `web.run`
2. Capture verifiable outputs:
   - source IDs
   - citations
   - quotable excerpts
3. Bind results to Sandcrawler artifacts:
   - evidence memo
   - value ledger entry
   - evidence references

---

## Failure Conditions (Any Causes Immediate Halt)
If any of the following are true:
- `web.run` is not executed
- results are inferred from prior knowledge or training
- citations are implied but not present
- sources cannot be independently referenced
- output is labeled "Sandcrawler" without evidence

Then the system MUST fail closed.

---

## Mandatory Failure Response
Upon failure, the system MUST emit exactly:

SANDCRAWLER_FAIL_CLOSED

Reason: Explicit Sandcrawler invocation without verified web.run execution.
Action: Execution halted. No planning, design, promotion, or export permitted.
Remediation: Re-run Sandcrawler with real web.run or abort.

Execution MUST stop after this message.

---

## EVG Integration
- EVG cannot be satisfied by memory, domain knowledge, or "well-known" claims.
- EVG is invalid unless Sandcrawler artifacts reference a real `web.run`.
- EVG-triggered workflows encountering Sandcrawler failure MUST propagate fail-close.

---

## Governance Kernel Enforcement
Before allowing:
- P0 or P1 promotion
- doctrine lock
- autonomy expansion

The kernel MUST verify:
- `sandcrawler_invoked == true`
- `web_run_id` exists
- `evidence_refs.length > 0`

Failure causes a block without override.

---

## Export Gate Enforcement
Any export MUST fail if:
- Sandcrawler was explicitly invoked in the session
- and no valid `web.run` artifact exists

This prevents unverifiable synthesis from entering canonical releases.

---

## Authority Boundary
Sandcrawler is the only subsystem authorized to claim external verification. Any subsystem presenting external claims without Sandcrawler artifacts is in violation of MetaBlooms invariants.
