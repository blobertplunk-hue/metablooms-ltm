# MB_MEMORY_PROMOTION_CONTRACT_MPC-1.0
**Date:** 2025-12-31  
**Status:** Active  

## Principle
No artifact becomes **Active Long-Term Memory** unless it is:
- contract-compliant (runtime + sandbox)
- evidence-backed
- convergence-qualified
- explicitly promoted (DeltaGate)

## Eligible Artifact Classes
- primitives
- policies
- runtime contracts
- sandbox policies
- known-issue catalogs (KIC)
- system-level grabber schemas/validators

## Ineligible (Never Auto-Promote)
- raw chat
- speculative notes
- single-source claims
- unverifiable UI walkthroughs

## Required Promotion Evidence
- `trace.ndjson` with a `memory_promotion_event`
- `evidence_log.ndjson` entry for the promoted artifact
- hash of artifact + hash of KIC snapshot used during generation
- rollback plan (git revert)

## Write Targets
- Quarantine: `/memory/quarantine/`
- Active: `/memory/active/`

## Fail-Closed Rules
- Missing contracts → refuse promotion
- Missing evidence → refuse promotion
- Missing rollback path → refuse promotion
