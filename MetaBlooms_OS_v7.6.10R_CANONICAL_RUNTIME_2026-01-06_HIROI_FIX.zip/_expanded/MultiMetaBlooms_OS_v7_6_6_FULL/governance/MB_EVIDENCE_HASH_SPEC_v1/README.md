# MB_EVIDENCE_HASH_SPEC_v1

Canonical evidence hashing rules for MetaBlooms OS.
