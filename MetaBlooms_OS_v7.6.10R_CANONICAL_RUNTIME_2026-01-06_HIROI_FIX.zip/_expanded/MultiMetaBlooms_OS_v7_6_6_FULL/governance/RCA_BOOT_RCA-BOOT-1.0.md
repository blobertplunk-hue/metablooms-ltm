# RCA — Boot Failures (P0) — RCA-BOOT-1.0

Summary:
- Failures like BOOT_FAILED: NO_ENTRYPOINT were not implementation bugs; they were boot-contract violations.
- Primary causes: authority ambiguity, entrypoint instability, fail-closed rules applied to incomplete artifacts, and context-scoped visibility mismatch (flat project files vs zip contents).

Corrective actions (implemented in this OS):
1) BC-1.0 frozen boot contract added (see governance/BOOT_CONTRACT_BC-1.0.md)
2) Option A “forever” boot kit required for flat project files: BOOT.md at root (present)
3) Boot launcher exists to provide time/retries for extraction without changing the entrypoint contract (BOOT_METABLOOMS.py).
4) CEJ1–CEJ9 included as artifacts under metablooms_governance/ (present)

Non-actions (explicitly avoided):
- No boot-time inference of multiple entrypoints beyond allowlisted launcher behavior.
- No combining boot with audit/build/seal.

Evidence:
- Root contains RUN_METABLOOMS.py and boot_manifest.json
- Root contains BOOT.md and BOOT_METABLOOMS.py
- governance contains BOOT_CONTRACT_BC-1.0.md and LEARNING_INTEGRATION_LID-1.0.md
