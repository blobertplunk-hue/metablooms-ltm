# PRE_GITHUB_DRIFT_REPORT — Personal Mode (Snapshot 2025-12-31)

## Drift-Impacted Areas
1. **Workflow permissions**: Explicit UI setting determines whether GITHUB_TOKEN is restricted or read/write by default. citeturn0search0turn0search9
2. **Secrets scopes**: Secrets are defined at repository, organization, or environment scope; workflows must explicitly reference them. citeturn0search13
3. **Branch governance**: **Rulesets** coexist with branch protection rules and may apply additional constraints. citeturn0search7

## Operational Implication
Any setup playbook must be guarded by EFL and KIC prechecks prior to giving click-path instructions.
