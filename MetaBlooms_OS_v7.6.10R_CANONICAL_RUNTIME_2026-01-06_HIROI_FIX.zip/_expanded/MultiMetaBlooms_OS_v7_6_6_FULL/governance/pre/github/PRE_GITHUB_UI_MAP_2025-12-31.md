# PRE_GITHUB_UI_MAP — Personal Mode (Snapshot 2025-12-31)

This map is derived from current GitHub documentation that describes the *current* Settings sidebar navigation
(e.g., “In the left sidebar, click Actions, then click General”). citeturn0search0

## Key Navigation Anchors (Repository)
- Repository **Settings** (tab may be behind a dropdown in some layouts). citeturn0search0
- **Actions → General** contains **Workflow permissions** (GITHUB_TOKEN default permissions). citeturn0search0turn0search9
- **Security → Secrets and variables → Actions** contains repository and environment secrets/variables guidance. citeturn0search2turn0search13
- Branch protection and/or rulesets are managed under repository branch configuration docs (protected branches; rulesets). citeturn0search3turn0search7

## Drift Note
GitHub’s branch governance now includes **rulesets** in addition to classic branch protection rules. citeturn0search7
