# Learning Integration Doctrine — LID-1.0

This document enforces that hard-won learnings (RCAs, failure modes, contract corrections) are *persisted into the OS* rather than living only in chat.

Required learning artifacts per P0 incident:
- RCA_<slug>.md (root cause analysis)
- Contract update (if applicable): BC-* document
- Tooling update (if applicable): boot kit / launcher / manifest update
- Evidence pointer: which artifact(s) prove the correction exists

Export rule:
- Any OS export MUST include all P0 learning artifacts produced since the last export.
- Silent omission is an export failure under MEEP.

Minimum checklist before exporting:
- [ ] RCA present in /governance or /sops
- [ ] Contract present (BOOT_CONTRACT_BC-1.0.md or newer)
- [ ] BOOT.md present (Option A compatibility) OR doctrine explicitly supports single-zip boot
- [ ] Entrypoint stable and present (RUN_METABLOOMS.py)
- [ ] Manifest updated (MEEP_Manifest.json) with new file hashes


## Required systems
- Egg Juicer (EJ-CORE) must be present in `/egg_juicer/`.
- Chunk Egg Juicer (CEJ) must be present in `/egg_juicer/chunk_egg_juicer/` with CEJ-1..CEJ-9 passes.
