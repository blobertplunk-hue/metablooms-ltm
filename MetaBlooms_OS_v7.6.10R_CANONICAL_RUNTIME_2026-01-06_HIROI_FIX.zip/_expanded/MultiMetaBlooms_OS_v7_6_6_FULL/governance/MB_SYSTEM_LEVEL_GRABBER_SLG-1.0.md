# MB_SYSTEM_LEVEL_GRABBER_SLG-1.0
**Date:** 2025-12-31
**Status:** Active

# MetaBlooms: System‑Level Grabber (SLG) — Research → Primitives Extraction Engine (Spec v0.1)
**Date:** 2025-12-31  
**Goal:** Automatically convert research outputs (docs, threads, notes) into **system primitives** and **governance-ready deltas**, by forcing “structural convergence extraction” as a default step after any research.

---

## One‑Screen Summary
SLG runs after every research sweep and produces:
1) a **Mechanism Inventory** per system,  
2) a **Convergence Map** across systems,  
3) **Candidate Runtime Primitives**,  
4) **Promotion Decisions** (P0/P1/P2 + reject),  
5) an **Append‑Only Delta Pack** proposal for MetaBlooms.

---

# 1) Inputs, Outputs, and Placement

## 1.1 Inputs
SLG consumes a normalized “Research Packet”:
- one or more source notes (web excerpts, vendor docs summaries, X thread summaries)
- optional structured extractions (tables, bullet points)
- provenance metadata (URL, date, system name, document type)

## 1.2 Outputs (Artifacts)
SLG must emit (append-only):
- `mechanisms.ndjson` (per-system mechanism extractions)
- `convergence.json` (cross-system convergence + confidence)
- `primitives.md` (candidate runtime primitives + justification)
- `delta_proposal.md` (MetaBlooms append-only patch plan)
- `evidence_log.ndjson` entry

## 1.3 Where it lives in MetaBlooms
Add SLG as a **mandatory post-processing stage** in the Research pipeline:
`Sandcrawler/Fitcrawler → Research Packet → SLG → DeltaGate → Export`

---

# 2) Core Concepts

## 2.1 Mechanism
A “mechanism” is an operational capability described in sources that is:
- observable in behavior (not marketing),
- located at a specific system layer (context, tool bus, sandbox, eval, trace),
- actionable as a software component.

Examples: “working set selection”, “approval-gated terminal tool”, “skills folder packaging”, “MCP tool discovery”, “undo last edit”, “sandbox network deny by default”.

## 2.2 Primitive (MetaBlooms Candidate)
A “primitive” is a **mechanism promoted** to an OS-level reusable module because:
- it appears independently in ≥2 systems **or**
- it is required for safe autonomy (policy sandbox, trace)
- it can be specified as a stable interface and validated.

## 2.3 Convergence
Convergence is measured as:
- **breadth:** count of independent systems exhibiting a mechanism
- **independence:** vendor diversity (avoid single-vendor echo)
- **evidence:** quality of sources (primary docs > blogs > threads)
- **enforceability:** can MetaBlooms enforce it at runtime?

---

# 3) SLG Algorithm (Fail-Closed)

## 3.1 Step A — Extract Mechanisms Per System
For each system S in the research packet:
- parse statements into mechanism candidates
- assign to layer(s): `context | toolbus | sandbox | eval | trace | workflow | ui`
- record evidence pointers + dates
- classify risk and operational role

Output: `mechanisms.ndjson` (one row per mechanism)

## 3.2 Step B — Normalize / Deduplicate
- canonicalize names (“undo last edit” == “checkpoint revert”)
- cluster synonyms
- track alias list

## 3.3 Step C — Build Convergence Graph
- nodes: mechanisms
- edges: shared across systems
- compute convergence score

## 3.4 Step D — Promote to Candidate Primitives
Promotion rule (default):
- Promote if **(systems_count ≥ 2 AND evidence_weight ≥ medium)** OR **(is_safety_critical == true)**

Reject rule:
- Reject if single-system only AND low evidence OR not enforceable in runtime.

## 3.5 Step E — Emit Delta Proposal
For each promoted primitive:
- propose module path
- propose artifact contracts (schemas)
- propose trace events
- propose gate requirements
- assign P0/P1/P2

SLG must end with a **promotion table** and **append-only patch plan**.

---

# 4) Scoring Model (Deterministic)

## 4.1 Evidence Weight
- high: primary docs / official repos / release notes
- medium: reputable secondary sources corroborated by at least one primary
- low: single-thread anecdotes / uncorroborated posts

## 4.2 Convergence Score (0–100)
Recommended weights:
- breadth (0–40): number of distinct systems
- independence (0–20): vendor diversity
- evidence (0–25): evidence weight + recency
- enforceability (0–15): runtime implementability

Promotion thresholds:
- P0: score ≥ 75 OR safety-critical
- P1: score ≥ 55
- P2: score ≥ 40
- Reject: < 40

---

# 5) Governance Hooks (MetaBlooms Integration)

## 5.1 DeltaGate Interface
SLG output is only a proposal. DeltaGate decides:
- accept / reject / quarantine
- required tests
- required trace proofpoints
- version bump rules

## 5.2 Trace Requirements
SLG must declare what new events are required per primitive.
Example:
- `tool_call`, `tool_result` for ToolBus
- `checkpoint_create`, `checkpoint_restore` for Undo/Checkpoint
- `eval_result` for Evaluation Harness

---

# 6) Minimal Canonical Primitive Registry (Seed Set)
From the 2025 coding-agent research, SLG should already recognize these as “known primitives”:
- ToolBus (MCP adapter)
- Policy Sandbox (network deny default, write scope, approvals)
- Working Set / Context Selector
- Replayable Trace (event-sourced NDJSON)
- Evaluation Harness (tests/linters/typecheckers as evidence)
- Workflow Packaging (“skills” folder spec)
- Undo/Checkpoint
- Headless NDJSON mode

---

# 7) Acceptance Tests (Preflight)
SLG must pass these tests before output is considered valid:
1) Every promoted primitive has ≥1 evidence pointer and date.
2) Every primitive has a proposed interface and trace event list.
3) Delta proposal is append-only (no destructive edits required).
4) All rejected mechanisms include a reason code.
5) Output schemas validate (JSON schema check).

---

# 8) Deliverable Contract (What “Done” Means)
SLG is “done” when it produces:
- a complete convergence map,
- a prioritized primitives list,
- and a delta proposal that DeltaGate can evaluate without interpretation.

