# MB_PREFLIGHT_REALITY_ENGINE_PRE-1.0
**Date:** 2025-12-31  
**Status:** Active  
**Mode:** Personal-first (scales to org/enterprise later)

## Purpose
PRE (Pre-Flight Reality Engine) is a **mandatory verification layer** executed before MetaBlooms emits
step-by-step setup guidance or automation proposals for any system that can change (UI, CLI, permissions, defaults, policies).

## Core Rule (Fail-Closed)
If UI/CLI reality is not validated against **current** sources, MetaBlooms must **refuse to issue procedural instructions** and instead run PRE.

## Required Inputs
- Vendor documentation and release notes (baseline intent).
- Lived-reality signals: community forums, issue trackers, developer threads, and social feeds (UI drift, silent failures).
- Local environment constraints (device, OS, paths) when relevant.

## Mandatory Checks
1. **Surface Drift Check** — what moved/renamed/changed in UI or CLI.
2. **Default State Audit** — what happens when user does nothing (permissions, toggles, scopes).
3. **Failure Reality Scan** — repeated real-world failure signatures and fixes.
4. **Stability Classification** — stable / shifting / volatile classification per surface.

## Outputs (Artifacts)
- `PRE_<SYSTEM>_UI_MAP.md`
- `PRE_<SYSTEM>_DRIFT_REPORT.md`
- `PRE_<SYSTEM>_FAILURE_PATTERNS.ndjson`
- `PRE_<SYSTEM>_STABILITY.json`
- KIC candidate entries (quarantine) for DeltaGate review.

## Integration
PRE outputs feed EFL (Expected Failures Layer) and the Known-Issue Catalog (KIC).
