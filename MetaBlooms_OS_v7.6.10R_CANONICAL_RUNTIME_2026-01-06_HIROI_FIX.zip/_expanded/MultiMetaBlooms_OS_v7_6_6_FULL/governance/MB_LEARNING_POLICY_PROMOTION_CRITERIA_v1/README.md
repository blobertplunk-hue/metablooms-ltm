# MB_LEARNING_POLICY_PROMOTION_CRITERIA_v1

Canonical promotion rules for MetaBlooms learning lanes.
