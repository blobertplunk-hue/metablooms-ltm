# MB_ENVIRONMENT_FAILURE_LEARNING_ADDENDUM_v1

This directory contains the machine-readable policy that enforces Environment Failure Learning as a **non-mutative** learning surface.

- The policy is advisory + fail-closed.
- It authorizes **ledger-only** capture of environment failures (Termux/PowerShell/Android/Windows/Sandbox).
- It explicitly forbids auto-fixes, local-execution dependencies, and changes to boot/activation/export logic.

Files:
- `MB_ENVIRONMENT_FAILURE_LEARNING_ADDENDUM_v1.json`
