#!/usr/bin/env python3
"""
MetaBlooms System-Level Grabber (SLG) — stub reference implementation.

This is intentionally minimal: it validates a Research Packet against schema,
groups mechanisms, and emits placeholder convergence scoring.

Usage:
  python slg_stub.py input_research_packet.json out_dir/

Outputs:
  mechanisms.ndjson
  convergence.json
  primitives.md
  delta_proposal.md
"""
from __future__ import annotations
import json, sys, os, hashlib
from dataclasses import dataclass
from typing import Dict, List, Any, Tuple
from pathlib import Path

LAYER_ORDER = ["context","toolbus","sandbox","eval","trace","workflow","ui"]

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def norm_name(name: str) -> str:
    return " ".join(name.lower().strip().split())

def load_json(p: Path) -> Any:
    return json.loads(p.read_text(encoding="utf-8"))

def write_text(p: Path, s: str) -> None:
    p.write_text(s, encoding="utf-8")

def write_ndjson(p: Path, rows: List[Dict[str, Any]]) -> None:
    with p.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def compute_score(systems_count: int, evidence_weight: str, enforceable: bool, safety: bool) -> int:
    # Deterministic toy scoring (replace with real scoring model)
    w = {"high": 25, "medium": 15, "low": 5}.get(evidence_weight, 5)
    score = min(40, systems_count * 20) + w + (15 if enforceable else 0) + (25 if safety else 0)
    return min(100, score)

def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: python slg_stub.py input_research_packet.json out_dir/")
        return 2

    inp = Path(sys.argv[1]).resolve()
    out_dir = Path(sys.argv[2]).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    packet = load_json(inp)

    # Minimal validation (schema validation would be added in full implementation)
    for k in ["research_packet_id","systems","extractions"]:
        if k not in packet:
            raise SystemExit(f"Missing required key: {k}")

    systems = {s["system_id"]: s for s in packet["systems"]}
    rows = []

    # Mechanism extraction rows (normalized)
    for ex in packet["extractions"]:
        m = norm_name(ex["mechanism"])
        layer = ex["layer"]
        ev = ex["evidence"]
        # evidence weight heuristic
        source_types = {e["source_type"] for e in ev}
        if "vendor_doc" in source_types or "repo" in source_types or "release_note" in source_types:
            weight = "high"
        elif "blog" in source_types:
            weight = "medium"
        else:
            weight = "low"

        row = {
            "system_id": ex["system_id"],
            "vendor": systems.get(ex["system_id"], {}).get("vendor",""),
            "surface": systems.get(ex["system_id"], {}).get("surface",""),
            "mechanism": ex["mechanism"],
            "mechanism_norm": m,
            "layer": layer,
            "safety_critical": bool(ex.get("safety_critical", False)),
            "enforceable": bool(ex.get("enforceable", True)),
            "evidence_weight": weight,
            "evidence": ev,
        }
        rows.append(row)

    write_ndjson(out_dir / "mechanisms.ndjson", rows)

    # Convergence map
    by_mech: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        key = r["mechanism_norm"]
        ent = by_mech.setdefault(key, {
            "mechanism_norm": key,
            "aliases": set(),
            "layers": set(),
            "systems": set(),
            "evidence_weights": set(),
            "safety_critical": False,
            "enforceable": True,
        })
        ent["aliases"].add(r["mechanism"])
        ent["layers"].add(r["layer"])
        ent["systems"].add(r["system_id"])
        ent["evidence_weights"].add(r["evidence_weight"])
        ent["safety_critical"] = ent["safety_critical"] or r["safety_critical"]
        ent["enforceable"] = ent["enforceable"] and r["enforceable"]

    conv = []
    for key, ent in by_mech.items():
        systems_count = len(ent["systems"])
        # pick best evidence weight present
        ew = "low"
        if "high" in ent["evidence_weights"]:
            ew = "high"
        elif "medium" in ent["evidence_weights"]:
            ew = "medium"
        score = compute_score(systems_count, ew, ent["enforceable"], ent["safety_critical"])
        conv.append({
            "mechanism_norm": key,
            "aliases": sorted(ent["aliases"]),
            "layers": sorted(ent["layers"], key=lambda x: LAYER_ORDER.index(x) if x in LAYER_ORDER else 999),
            "systems_count": systems_count,
            "systems": sorted(ent["systems"]),
            "evidence_weight": ew,
            "enforceable": ent["enforceable"],
            "safety_critical": ent["safety_critical"],
            "convergence_score": score,
            "promotion": "P0" if (score >= 75 or ent["safety_critical"]) else ("P1" if score >= 55 else ("P2" if score >= 40 else "REJECT")),
        })

    conv.sort(key=lambda x: (-x["convergence_score"], x["mechanism_norm"]))
    (out_dir / "convergence.json").write_text(json.dumps(conv, indent=2), encoding="utf-8")

    # primitives.md + delta_proposal.md (placeholders)
    prim_lines = ["# Candidate Primitives (Auto-generated)\\n"]
    delta_lines = ["# Delta Proposal (Auto-generated)\\n"]
    for c in conv:
        if c["promotion"] == "REJECT":
            continue
        prim_lines.append(f"- **{c['aliases'][0]}** ({c['promotion']}, score={c['convergence_score']}) — layers: {', '.join(c['layers'])}; systems: {', '.join(c['systems'])}")
        delta_lines.append(f"## {c['aliases'][0]} — {c['promotion']}\\n- Proposed module: TBD\\n- Required trace events: TBD\\n- Required gates: TBD\\n")

    write_text(out_dir / "primitives.md", "\\n".join(prim_lines) + "\\n")
    write_text(out_dir / "delta_proposal.md", "\\n".join(delta_lines) + "\\n")

    print(f"OK: wrote outputs to {out_dir}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
