# Egg Juicer Core Contract — EJ-CORE-1.0 (FROZEN)

Non-negotiables:
1) **Exhaustiveness first**: extract before summarizing. Summaries are allowed only after object exhaustion.
2) **Evidence labeling**: every claim must be tagged as one of:
   - user_statement
   - tool_output
   - execution_log
   - artifact_file
   - inference (must be explicit)
3) **No silent exclusions**: if a pass is skipped, it must be declared and justified.
4) **Idempotent continuation**: each run must produce a continuation capsule enabling deterministic resume.
5) **Cross-domain reuse**: Egg Juicer variants share core fields; variant-specific fields are allowed.
6) **Artifacts are the memory**: output must be written to files when operating inside MetaBlooms OS.

Change control:
- Any change requires a version bump and an explicit compatibility note.
