#!/usr/bin/env python3
"""
Fail-closed CEJ autorun orchestrator.

- Automatically selects CEJ passes for requests like: "do cej on this"
- ALWAYS includes optional precision passes (CEJ-8/CEJ-9) unless --no_precision is set
- Produces deterministic JSON outputs + run metadata
- Bundles outputs into a zip by default

NOTE: This is the *selection + orchestration* layer. Wire `run_pass()` to your actual CEJ implementations.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


DEFAULT_POLICY = "/mnt/data/CEJ_AUTORUN_POLICY_v1.json"


def _sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()


def load_policy(path: str) -> Dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def detect_artifact_type(path: Optional[str], content: str) -> str:
    if path:
        ext = Path(path).suffix.lower()
        if ext in [".html", ".htm"]:
            return "html"
        if ext in [".py", ".js", ".ts", ".css"]:
            return "code"
        if ext == ".json":
            if '"$schema"' in content or '"additionalProperties"' in content:
                return "json_schema"
            if any(k in content.upper() for k in ["KERNEL", "ENV_SPEC", "INSTALL_PACKET", "BOOT"]):
                return "kernel_or_spec"
            return "json"
        if ext in [".md", ".txt"]:
            return "doc"
        if ext == ".zip":
            return "zip"
    s = content.lstrip()
    if s.startswith("<!DOCTYPE html") or s.startswith("<html"):
        return "html"
    if s.startswith("{") or s.startswith("["):
        return "json"
    return "unknown"



def find_prepass_report(prepass_dir: str, stem: str, report_suffix: str = ".report.json") -> Path:
    """
    Locate Freeze-First Prepass report for the given input stem.
    Convention: <prepass_dir>/<stem><report_suffix>
    """
    p = Path(prepass_dir) / f"{stem}{report_suffix}"
    return p


def load_prepass_status(report_path: Path, status_field: str = "status") -> str:
    try:
        data = json.loads(report_path.read_text(encoding="utf-8"))
        return str(data.get(status_field, "")).strip()
    except Exception:
        return ""


def enforce_freeze_guard(policy: Dict, in_path: Optional[str], stem: str, artifact_type: str, allow_unfrozen: bool) -> Dict:
    """
    Fail-closed unless a Freeze-First Prepass report exists for certain artifact types.
    Returns a dict with keys:
      - ok (bool)
      - report_path (str|None)
      - status (str|None)
      - reason (str|None)
    """
    fg = policy.get("freeze_guard", {}) or {}
    if not fg.get("enabled", False):
        return {"ok": True, "report_path": None, "status": None, "reason": None}

    required_types = [t.lower() for t in fg.get("required_for_artifact_types", [])]
    if artifact_type.lower() not in required_types:
        return {"ok": True, "report_path": None, "status": None, "reason": None}

    if allow_unfrozen:
        return {"ok": True, "report_path": None, "status": None, "reason": "override_allow_unfrozen"}

    prepass_dir = fg.get("prepass_report_dir", "/mnt/data/eggjuicer_prepass_out")
    report_suffix = fg.get("report_suffix", ".report.json")
    status_field = fg.get("status_field", "status")
    allowed_status_any = [s.upper() for s in fg.get("allowed_status_any", [])]

    rp = find_prepass_report(prepass_dir, stem, report_suffix=report_suffix)
    if not rp.exists():
        return {"ok": False, "report_path": str(rp), "status": None, "reason": "missing_prepass_report"}

    status = load_prepass_status(rp, status_field=status_field)
    if not status:
        return {"ok": False, "report_path": str(rp), "status": None, "reason": "missing_status_field"}

    if allowed_status_any and status.upper() not in allowed_status_any:
        return {"ok": False, "report_path": str(rp), "status": status, "reason": "status_not_allowed"}

    return {"ok": True, "report_path": str(rp), "status": status, "reason": None}


def choose_passes(policy: Dict, intent: str, artifact_type: str, always_include_optional_precision: bool = True) -> List[str]:
    prof = policy["selection_profiles"]["auto"]
    intent_l = (intent or "").lower()
    included: List[str] = []
    optional: List[str] = []

    def matches(rule_when: Dict) -> bool:
        ia = rule_when.get("intent_any", [])
        aa = rule_when.get("artifact_any", [])
        if ia and any(k.lower() in intent_l for k in ia):
            return True
        if aa and any(a.lower() == artifact_type.lower() for a in aa):
            return True
        return False

    for rule in prof["rules"]:
        if matches(rule.get("when", {})):
            for p in rule.get("include_passes", []):
                if p not in included:
                    included.append(p)
            for p in rule.get("optional_precision_passes", []):
                if p not in optional:
                    optional.append(p)
            break

    if not included:
        for p in prof["fallback"]["include_passes"]:
            if p not in included:
                included.append(p)
        for p in prof["fallback"].get("optional_precision_passes", []):
            if p not in optional:
                optional.append(p)

    if always_include_optional_precision:
        for p in optional:
            if p not in included:
                included.append(p)

    order = [x["pass_id"] for x in policy["pass_registry"]]
    included.sort(key=lambda p: order.index(p) if p in order else 999)
    return included


# -------------------------
# Placeholder executors
# -------------------------
def run_pass(pass_id: str, content: str, meta: Dict) -> Dict:
    """Replace this with your real CEJ logic."""
    if pass_id == "CEJ-3":
        return {"failures": [], "notes": "STUB: wire to CEJ-3 failure extractor."}
    if pass_id == "CEJ-4":
        return {"survivors": [], "notes": "STUB: wire to CEJ-4 survivor extractor."}
    if pass_id == "CEJ-5":
        return {"tools": [], "notes": "STUB: wire to CEJ-5 tool extractor."}
    if pass_id == "CEJ-6":
        return {"gaps": [], "notes": "STUB: wire to CEJ-6 gap extractor."}
    if pass_id == "CEJ-8":
        return {"constraints": [], "notes": "STUB: CEJ-8 precision constraints."}
    if pass_id == "CEJ-9":
        return {"tests": [], "notes": "STUB: CEJ-9 test vectors/acceptance."}
    if pass_id == "CEJ-1":
        return {"context": {"artifact_type": meta.get("artifact_type"), "intent": meta.get("intent")}, "notes": "STUB: CEJ-1."}
    if pass_id == "CEJ-2":
        return {"claims": [], "notes": "STUB: CEJ-2 claims."}
    if pass_id == "CEJ-7":
        return {"integration_map": [], "notes": "STUB: CEJ-7 mapping."}
    return {"notes": f"Unknown pass {pass_id}."}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", default=DEFAULT_POLICY)
    ap.add_argument("--intent", default="", help="e.g., 'do cej on this', 'root cause', 'freeze boundary'.")
    ap.add_argument("--input", dest="in_path", default=None, help="Input file path.")
    ap.add_argument("--stdin", action="store_true", help="Read content from stdin.")
    ap.add_argument("--out_dir", default=None, help="Override output dir.")
    ap.add_argument("--no_precision", action="store_true", help="Disable CEJ-8/CEJ-9.")
    ap.add_argument("--allow_unfrozen", action="store_true", help="Override Freeze-First guard (not recommended).")
    ap.add_argument("--bundle", action="store_true", help="Force zip bundle (default on per policy).")
    args = ap.parse_args()

    policy = load_policy(args.policy)
    out_root = args.out_dir or policy["defaults"]["output_dir"]
    always_precision = policy["defaults"].get("always_include_optional_precision", True) and (not args.no_precision)

    if args.stdin:
        content = sys.stdin.read()
        in_path = None
        stem = "stdin"
        source_kind = "stdin"
    elif args.in_path:
        in_path = args.in_path
        content = Path(in_path).read_text(encoding="utf-8", errors="replace")
        stem = Path(in_path).stem
        source_kind = "file"
    else:
        raise SystemExit("Fail-closed: Provide --input FILE or --stdin.")

    artifact_type = detect_artifact_type(in_path, content)
    freeze_guard_result = enforce_freeze_guard(policy, in_path, stem, artifact_type, allow_unfrozen=args.allow_unfrozen)
    if not freeze_guard_result.get('ok', False):
        msg = (policy.get('freeze_guard', {}) or {}).get('fail_closed_message', 'BLOCKED: missing freeze prepass report')
        # Emit deterministic JSON error payload
        err = {
            'error': 'FREEZE_GUARD_BLOCKED',
            'message': msg,
            'input_path': in_path,
            'stem': stem,
            'artifact_type': artifact_type,
            'expected_report_path': freeze_guard_result.get('report_path'),
            'status': freeze_guard_result.get('status'),
            'reason': freeze_guard_result.get('reason'),
        }
        print(json.dumps(err, indent=2, ensure_ascii=False))
        raise SystemExit(2)

    content_sha = _sha256_bytes(content.encode("utf-8", errors="replace"))

    passes = choose_passes(policy, args.intent, artifact_type, always_include_optional_precision=always_precision)

    ts = time.strftime("%Y%m%dT%H%M%S")
    run_id = f"cej_{ts}_{stem}_{content_sha[:8]}"
    run_dir = Path(out_root) / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    meta = {
        "run_id": run_id,
        "timestamp": ts,
        "intent": args.intent,
        "artifact_type": artifact_type,
        "source_kind": source_kind,
        "input_path": in_path,
        "content_sha256": content_sha,
        "selected_passes": passes,
        "policy_version": policy.get("version"),
        "always_include_optional_precision": always_precision,
        "freeze_guard": freeze_guard_result
    }

    (run_dir / "cej_run.meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    outputs = {"meta": str(run_dir / "cej_run.meta.json"), "artifacts": {}}
    for p in passes:
        out = run_pass(p, content, meta)
        fpath = run_dir / f"{p}.json"
        fpath.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
        outputs["artifacts"][p] = str(fpath)

    do_bundle = args.bundle or policy["defaults"].get("bundle_outputs", True)
    if do_bundle:
        bundle_path = Path(out_root) / f"CEJ_{ts}_{stem}.zip"
        with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for fp in run_dir.glob("*.json"):
                z.write(fp, arcname=f"{run_id}/{fp.name}")
        outputs["bundle"] = str(bundle_path)

    print(json.dumps(outputs, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
