# CEJ Autorun (Sandbox)

Usage:
python3 egg_juicer/chunk_egg_juicer/autorun/cej_autorun.py --input <file> --intent "do cej on this"

Notes:
- Runs in sandbox
- Auto-selects CEJ passes
- Always includes precision passes unless --no_precision
- Outputs to /mnt/data/cej_out


## Freeze-First Guard (fail-closed)
For artifact types like HTML/code/schemas/specs/zips, CEJ autorun will refuse to run unless a Freeze-First Prepass report exists:
- default report dir: /mnt/data/eggjuicer_prepass_out
- expected name: <stem>.report.json

Override (not recommended):
  --allow_unfrozen
