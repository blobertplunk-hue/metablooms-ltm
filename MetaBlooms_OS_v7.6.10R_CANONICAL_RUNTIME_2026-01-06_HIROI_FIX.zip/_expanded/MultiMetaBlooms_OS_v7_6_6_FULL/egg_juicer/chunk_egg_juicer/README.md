# Chunk Egg Juicer — CEJ (Chat Transcript Multi-Chunk) — CEJ-1.0

Chunk Egg Juicer (CEJ) is the configured Egg Juicer used to ingest a **series of numbered chunks** (e.g., Chunk 1 … Chunk 15).

It exists because chunk-series work fails in three predictable ways:
- detail loss (compression too early)
- drift (passes skipped or merged silently)
- state loss (UI resets, session illusion)

CEJ fixes this by enforcing:
- mandatory passes CEJ-1 → CEJ-9
- high granularity (“Chunk-15 granularity” when specified)
- continuation capsule every run
- evidence-first weighting (execution/logs > user recollection > assistant inference)

Inputs:
- `chunk_N.json` or transcript text
- optional prior artifacts for continuity

Outputs (minimum):
- `CEJ_chunk_N_report.md`
- `CEJ_chunk_N_objects.json`
- updated registry entries (survivor rules, failure taxonomy) when applicable
- continuation capsule

CEJ is a *process* and a *packaged set of templates/scripts*; it is not just a concept.
