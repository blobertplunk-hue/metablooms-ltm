# CEJ-9 — Continuation Capsule + Audit Pass

Deliverable: continuation capsule + self-audit.

Required checks:
- Did any pass skip objects? If yes, restart the relevant pass.
- Are any claims unlabeled? If yes, fix.
- Is there any temporal contamination? If yes, mark and purge.

Output:
- CEJ_chunk_N_continuation.txt
- CEJ_chunk_N_audit.md
