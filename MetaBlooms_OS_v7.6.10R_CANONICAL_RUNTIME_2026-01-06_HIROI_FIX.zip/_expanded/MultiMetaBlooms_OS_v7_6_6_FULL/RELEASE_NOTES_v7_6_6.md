# Release Notes — v7.6.6 (MultiMetaBlooms)

Date: 2026-01-02

## What Changed
- Added EVG (Existence Verification Gate) as a P0, fail-closed governance gate.
- Added Sandcrawler Fail-Close (SFC) as a P0, fail-stop trust boundary.
- Added Inspiration vs Evidence rubric and provenance recording (inspiration cannot satisfy EVG).
- Added OS Indexing subsystem: canonical index, views, and deterministic generator.

## Notes
This release is intended to make verification and navigation deterministic across exports.
