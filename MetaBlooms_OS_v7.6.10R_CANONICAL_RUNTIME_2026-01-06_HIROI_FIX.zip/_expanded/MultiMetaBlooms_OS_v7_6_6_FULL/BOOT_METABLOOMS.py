#!/usr/bin/env python3
"""BOOT_METABLOOMS.py — Stable Boot Launcher (Immutable entrypoint)

Responsibilities:
- Extract a MetaBlooms bundle zip to a destination folder
- Resolve entrypoint using boot_manifest.json (authoritative)
- Execute entrypoint and stream its stdout/stderr
- Fail-closed if:
    * no entrypoint
    * entrypoint exits non-zero
    * success signal not present in output
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ALLOWLIST = ["RUN_METABLOOMS.py", "MetaBlooms.py"]

def load_manifest(root: Path) -> dict:
    p = root / "boot_manifest.json"
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))

def resolve_entrypoint(root: Path, manifest: dict) -> Path | None:
    ep = manifest.get("entrypoint") if isinstance(manifest, dict) else None
    if ep:
        p = root / ep
        if p.exists() and p.is_file():
            return p
    for name in ALLOWLIST:
        p = root / name
        if p.exists() and p.is_file():
            return p
    return None

def extract_zip(bundle: Path, dest: Path, clean: bool = True) -> None:
    if clean and dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle, "r") as z:
        z.extractall(dest)

def run_entrypoint(ep: Path) -> tuple[int, str]:
    cmd = [sys.executable, str(ep)] if ep.suffix == ".py" else [str(ep)]
    p = subprocess.Popen(cmd, cwd=str(ep.parent), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    out_lines = []
    assert p.stdout is not None
    for line in p.stdout:
        out_lines.append(line)
        print(line.rstrip("\n"), flush=True)
    rc = p.wait()
    return rc, "".join(out_lines)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", required=True, help="Path to MetaBlooms bundle zip")
    ap.add_argument("--dest", default="/mnt/data/MetaBlooms", help="Extraction destination")
    ap.add_argument("--no-clean", action="store_true", help="Do not delete dest before extracting")
    ap.add_argument("--settle-seconds", type=float, default=0.2, help="Small delay after extraction")
    args = ap.parse_args()

    bundle = Path(args.bundle).expanduser().resolve()
    if not bundle.exists():
        print("BOOT_FAILED: BUNDLE_NOT_FOUND", flush=True)
        return 10

    dest = Path(args.dest).expanduser().resolve()
    extract_zip(bundle, dest, clean=(not args.no_clean))
    time.sleep(max(0.0, float(args.settle_seconds)))

    manifest = load_manifest(dest)
    success_signal = manifest.get("success_signal", "BOOT_OK")
    ep = resolve_entrypoint(dest, manifest)
    if not ep:
        print("BOOT_FAILED: NO_ENTRYPOINT", flush=True)
        return 11

    rc, out = run_entrypoint(ep)
    if rc != 0:
        print("BOOT_FAILED: ENTRYPOINT_EXIT_NONZERO", flush=True)
        return rc if rc > 0 else 12

    if success_signal not in out:
        print("BOOT_FAILED: SUCCESS_SIGNAL_MISSING", flush=True)
        return 13

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
