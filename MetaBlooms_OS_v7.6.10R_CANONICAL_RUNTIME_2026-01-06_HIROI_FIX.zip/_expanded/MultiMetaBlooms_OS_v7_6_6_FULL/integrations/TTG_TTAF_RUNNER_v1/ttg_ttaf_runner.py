
#!/usr/bin/env python3
"""
TTG/TTAF Runner v1
Deterministic Toolchain Truth Autofix Executor

Inputs:
  --env <environment_id>
  --stderr <stderr_text_file>
  --script <script_file_optional>

Outputs (JSON to stdout):
  - matched_rule_id
  - applied_fix
  - verification_action
  - rollback_action
"""

import argparse, json, re, sys, copy

def load_ruleset(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", required=True)
    ap.add_argument("--stderr", required=True)
    ap.add_argument("--ruleset", required=True)
    args = ap.parse_args()

    ruleset = load_ruleset(args.ruleset)
    env = args.env
    stderr_text = open(args.stderr, 'r', encoding='utf-8').read()

    env_rules = ruleset.get("environments", {}).get(env)
    if not env_rules:
        print(json.dumps({"status":"no_match","reason":"unknown_environment"}, indent=2))
        sys.exit(0)

    for rule in env_rules.get("autofix_rules", []):
        pattern = rule["match"]["stderr_regex"]
        if re.search(pattern, stderr_text, re.IGNORECASE):
            out = {
                "status": "match",
                "environment": env,
                "rule_id": rule["rule_id"],
                "cause_class": rule["cause_class"],
                "fix": rule["fix"],
                "verification": rule["verification"],
                "rollback": rule["rollback"]
            }
            print(json.dumps(out, indent=2))
            sys.exit(0)

    print(json.dumps({"status":"no_match","reason":"no_rule_matched"}, indent=2))

if __name__ == "__main__":
    main()
