
# TTG / TTAF Runner v1

Purpose:
- Deterministically match toolchain stderr against the TOOLCHAIN_TRUTH_AUTOFIX_RULESET.
- Emit the canonical fix + verification + rollback instructions.
- Does NOT execute fixes itself (safety by separation).

Usage:
python ttg_ttaf_runner.py --env termux:bash --stderr error.txt --ruleset TOOLCHAIN_TRUTH_AUTOFIX_RULESET_v1.json

This runner is designed to be embedded inside MetaBlooms OS pipelines.
