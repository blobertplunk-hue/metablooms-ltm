# FAILURE_FACTOR_REGISTRY_v1

Canonical causal learning registry for MetaBlooms OS v3.x.
