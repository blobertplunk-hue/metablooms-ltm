# SOP: Shopping Mode Controller (Sandcrawler) — v1
Date: 2025-12-29
Status: DRAFT (append-only; no changes to locked manifests)

## Purpose
Prevent “mode drift” during product research by automatically switching between:
- **FIND**: broad discovery; SKU-exhaustive; multi-retailer; pattern harvesting
- **EVALUATE**: shortlist comparison; evidence-weighted tradeoffs
- **FINE_TUNE**: fit planning (space/stack/layout), quantities, final buy list

This SOP formalizes automatic **backtracking** when new constraints invalidate a shortlist.

## Definitions
### Modes
- **FIND**: discover candidate product families and *enumerate all viable SKUs/variants*; collect usage patterns from reviews/Q&A; build shortlist.
- **EVALUATE**: compare a small shortlist (<= 5) using normalized factors; produce 1 primary + 1 fallback recommendation with links.
- **FINE_TUNE**: apply exact space constraints, stacking plan, quantities, and shopping list; output “buy-ready” instructions.

### Blocking Constraint
A constraint that changes feasibility (fit, compliance, required feature) or materially alters ranking:
- dimensional envelope (W/D/H)
- must-have features (clear-only, lid/no lid, stackability)
- behavior constraints (won’t stack high, needs grab access)
- retailer constraints (Target-only, Walmart-only)
- corrected spec (12" not 12.75")

## Automatic Mode Switching (Core Rule)
**If a blocking constraint is introduced or discovered, backtrack at least one mode:**
- Fine-tune → Evaluate
- Evaluate → Find (when shortlist viability collapses)
- Fine-tune → Find (when product class was wrong)

## Triggers
### T1 — Constraint change or correction (HARD)
Examples:
- “Shelf can handle 12 inches” (constraint change)
- “It’s 12\", not 12.75\",” (spec correction)
- “No lids” (requirement change)

**Action:** Recompute feasibility.  
If the change expands the search space or invalidates chosen SKU(s): **switch to FIND**.  
If it only changes ranking within an intact shortlist: **switch to EVALUATE**.

### T2 — Disqualifying mismatch discovered late (HARD)
Examples:
- fails depth/height fit
- violates clear-only
- stacking stability fails
- taper unacceptable
- not used as assumed (behavior mismatch)

**Action:** If top pick fails and viable shortlist < 2 → **switch to FIND**.  
Else → **switch to EVALUATE**.

### T3 — User friction / “no homework” signal (HARD)
Examples:
- “Specific products.”
- “Links.”
- “I don’t want to have to find…”

**Action:** **switch to FIND**, run SKU-complete enumeration, output linked buy list.

### T4 — Evidence insufficiency (MED)
Examples:
- dimensions missing / multiple variants unclear
- conflicting specs across sources

**Action:** **switch to FIND** and seek alternate sources/retailers OR require a single user measurement to lock it.

### T5 — Behavioral reclassification (HARD)
Examples:
- “Top shelves: stacking options”
- “Project crap: open dump bin”
- “Not stacking 14.5 inches high”

**Action:** If current shortlist was optimized for the wrong behavior class → **switch to FIND** for the correct class.

## Output Contracts
### FIND mode deliverable
- Retailer-agnostic sweep across: Target, Walmart, Amazon, Container Store (and others if needed)
- **SKU family expansion:** enumerate viable size variants in the product line(s)
- Normalize to a single comparison table (W/D/H, clear-only yes/no, stackability, price, rating)
- Provide links for all finalists
- Return: shortlist of 3–7 viable candidates

### EVALUATE mode deliverable
- Compare shortlist on: fit, stack stability, rigidity, taper, usability, price, return friction
- Return: **1 primary + 1 fallback**, with links and a brief rationale

### FINE_TUNE mode deliverable
- Exact layout (counts per shelf/bay), stacking plan (max stack height), labels/categories
- Shopping list: quantities by SKU + links

## Governance Notes (MetaBlooms)
- This SOP is **append-only**; do not modify locked control_plane manifests.
- Use EvidenceChain: each recommendation must cite a product page link and a dimension source.
- If product dimensions conflict, mark *SpecConflict* and fall back to measurement or alternate retailer listing.

