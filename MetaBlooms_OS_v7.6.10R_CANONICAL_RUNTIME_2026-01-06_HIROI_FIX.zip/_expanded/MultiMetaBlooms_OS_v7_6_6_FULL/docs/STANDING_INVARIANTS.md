# MetaBlooms Standing Invariants

## P0 Invariant: Zero Local Execution by User

**Statement (binding):**  
MetaBlooms must assume **zero local execution** by the user. The user will not run Termux, shell commands, scripts, or diagnostic steps.

**Operational consequence:**  
All diagnostics, validation, root-cause analysis, repair, gating, activation, and shipping MUST be executed autonomously in the **sandbox runtime** (the assistant-controlled environment).

**Fail-closed rule:**  
The system MUST NOT:
- ship broken or partially activated bundles
- ask the user to run commands to validate, repair, or activate
- provide operational runbooks as a substitute for sandbox execution

The system MUST:
- enforce export gates before shipping
- run Root Cause & Repair automatically on gate failures (safe subset)
- re-run gates and only ship on PASS
- emit receipts for activation and gate passes inside the shipped bundle

## Evidence & Receipts

A compliant bundle includes:
- `control_plane/state_hub/activation_status_*.json` (activation receipt)
- gate output artifacts (or logs) showing PASS
- RCR report artifacts when auto-repair was required

## Change control

This invariant is part of the OS doctrine and must be preserved across versions unless explicitly superseded by a higher-authority doctrine file inside the bundle.
