# PATTERN: Runtime Governance with Control Surface (MetaBlooms)

## Purpose
Capture the architectural pattern demonstrated by MetaBlooms: runtime governance that is *observable*, *auditable*, and *fail-closed*.

This pattern closes the common “research loop” gap by ensuring findings become:
1) a concrete, versioned DeltaPack, and
2) an observable change surfaced via OBSERVABILITY_CORE outputs.

## Core Elements (as implemented)
- **Immutable entrypoint:** `BOOT_METABLOOMS.py`
- **Boot enforcement:** activation + validation gates
- **ExportGate:** exports must satisfy invariants (fail-closed)
- **OBSERVABILITY_CORE:** generates `HEALTH.json` + `STATUS.md` + daily changes + active state

## Control Surface Contract
A system is not operable unless it can report, at rest:
- Health (`HEALTH.json`)
- Status (`STATUS.md`)
- What changed today (`WHAT_CHANGED_TODAY.md`)
- Active configuration (`ACTIVE_STATE.md`)

## Fail-Closed Requirements
- Boot fails if `HEALTH.json` or `STATUS.md` cannot be generated/validated.
- Export fails if observability is missing or invalid.

## How to Apply
1. Encode the learning as a DeltaPack in `metablooms/deltas/`.
2. Ensure OBSERVABILITY_CORE surfaces:
   - `deltas_active`
   - `last_delta`
3. Boot; verify status files reflect the change.
4. Only then export.

## Anti-Patterns
- “Smart” system with no `/status` → operator becomes state machine.
- Narrative summaries not rooted in artifacts → drift and distrust.
