# Auto RCR + Export Gate Wiring (v3)

This bundle enforces **no dormant capability** and prevents **ellipsis/Locked/truncated placeholders** from shipping.

## How it works
1. `tools/rcr/metablooms_export_gate.py` scans the target ZIP/dir.
2. If gate FAILS, `tools/rcr/metablooms_rcr.py repair` applies safe repairs (quarantine stubs + wire activation gate).
3. Gate reruns. **Ship proceeds only on PASS**.

## Run (recommended)
```bash
python tools/rcr/metablooms_ship.py /path/to/MetaBlooms_OS.zip
```

## Validate with autofix
```bash
python validate_metablooms_export.py --autofix /path/to/MetaBlooms_OS.zip
```

Outputs:
- PASS: `SHIP_OK`
- FAIL: `SHIP_FAILED` with `rcr_reports/` path
