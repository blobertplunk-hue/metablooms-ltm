#!/usr/bin/env python3
"""
BOOT_METABLOOMS.py (IMMUTABLE ENTRYPOINT)
=========================================
MetaBlooms OS canonical boot entrypoint. This file is intended to NEVER CHANGE
across versions. Only internal payloads should evolve.

Fail-Closed Contract:
- If governance/doctrine cannot be loaded and validated -> EXIT NON-ZERO
- No permissive fallback behavior
- Boot is a judge, not a helper: it does not "fix" problems, it halts loudly.

Responsibilities (and ONLY these):
1) Environment sanity checks
2) Governance/doctrine load (read-only) + validation
3) Ledger availability (append-only; create if missing)
4) Smoke tests (minimal)
5) Handoff to runtime (RUN_METABLOOMS.py) or halt

This boot file is code-as-prose: it is intentionally explicit and readable.
"""

from __future__ import annotations

import json
import os
import sys
import time
import hashlib
import traceback
from pathlib import Path
from typing import Dict, Any, Tuple

BOOT_VERSION = "BOOT_METABLOOMS.py::v1"
RRU_REFERENCE = "RRU-000"

BASE_DIR = Path(__file__).resolve().parent
GOV_DIR = BASE_DIR / "governance"
DOCTRINE_DIR = GOV_DIR / "doctrines"
DOCTRINE_REGISTRY = DOCTRINE_DIR / "doctrine_registry.json"
LEDGER_PATH = GOV_DIR / "epistemic_ledger.ndjson"
DELTA_MD = BASE_DIR / "MetaBlooms_RRU-000_Epistemic_DELTA.md"
DELTA_JSON = BASE_DIR / "MetaBlooms_RRU-000_Epistemic_DELTA.json"
RUNTIME_ENTRY = BASE_DIR / "RUN_METABLOOMS.py"


class BootFailure(SystemExit):
    """Raised for deterministic, fail-closed boot termination."""


def _die(code: int, msg: str) -> None:
    print(f"[BOOT_FAILED] {msg}", file=sys.stderr)
    raise BootFailure(code)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        _die(21, f"Missing required JSON file: {path}")
    except json.JSONDecodeError as e:
        _die(22, f"Invalid JSON (parse error) in {path}: {e}")


def env_sanity() -> Dict[str, Any]:
    """
    Minimal environment checks. We do not attempt to repair environments.
    """
    if sys.version_info < (3, 10):
        _die(10, f"Python >= 3.10 required. Detected: {sys.version.split()[0]}")

    if not BASE_DIR.exists():
        _die(11, f"Base dir not found: {BASE_DIR}")

    # We tolerate different OSes, but we make state explicit.
    return {
        "python": sys.version.split()[0],
        "platform": sys.platform,
        "base_dir": str(BASE_DIR),
        "boot_version": BOOT_VERSION,
        "rru_reference": RRU_REFERENCE,
        "ts": int(time.time()),
    }


def load_and_validate_doctrines() -> Dict[str, Any]:
    """
    Loads doctrine registry and required doctrines. Validates content hashes.
    Fail-closed: missing registry or doctrine => stop.
    """
    if not DOCTRINE_REGISTRY.exists():
        _die(30, f"Missing doctrine registry: {DOCTRINE_REGISTRY}")

    reg = _read_json(DOCTRINE_REGISTRY)

    required = reg.get("required_at_boot")
    if not isinstance(required, list) or not required:
        _die(31, "Doctrine registry missing 'required_at_boot' list.")

    doctrines = reg.get("doctrines")
    if not isinstance(doctrines, list) or not doctrines:
        _die(32, "Doctrine registry missing 'doctrines' list.")

    by_id = {d.get("id"): d for d in doctrines if isinstance(d, dict)}
    loaded: Dict[str, Dict[str, Any]] = {}

    for did in required:
        if did not in by_id:
            _die(33, f"Required doctrine not declared in registry: {did}")

        entry = by_id[did]
        rel_path = entry.get("path")
        expected_hash = entry.get("sha256")

        if not rel_path or not expected_hash:
            _die(34, f"Doctrine registry entry incomplete for {did} (needs path + sha256).")

        doc_path = BASE_DIR / rel_path
        if not doc_path.exists():
            _die(35, f"Missing required doctrine file {did}: {doc_path}")

        actual_hash = _sha256_file(doc_path)
        if actual_hash != expected_hash:
            _die(36, f"Doctrine hash mismatch for {did}: expected {expected_hash}, got {actual_hash}")

        # Read-only load: we do not interpret doctrine beyond validation and availability.
        try:
            text = doc_path.read_text(encoding="utf-8")
        except Exception as e:
            _die(37, f"Unable to read doctrine {did}: {e}")

        loaded[did] = {
            "id": did,
            "path": str(doc_path),
            "sha256": actual_hash,
            "bytes": doc_path.stat().st_size,
            "title": (text.splitlines()[0].strip() if text.splitlines() else did),
        }

    return {"registry": reg, "loaded": loaded}


def ensure_ledger(env: Dict[str, Any], doctrines: Dict[str, Any]) -> None:
    """
    Ensure ledger exists. If missing, create append-only file and seed boot_event.
    We do not truncate or delete.
    """
    GOV_DIR.mkdir(parents=True, exist_ok=True)

    if not LEDGER_PATH.exists():
        LEDGER_PATH.write_text("", encoding="utf-8")

    # Append boot event
    event = {
        "type": "boot_event",
        "rru": RRU_REFERENCE,
        "boot_version": BOOT_VERSION,
        "ts": env["ts"],
        "python": env["python"],
        "platform": env["platform"],
        "doctrines_loaded": sorted(list(doctrines["loaded"].keys())),
    }
    with LEDGER_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def smoke_tests() -> None:
    """
    Minimal, deterministic smoke tests. No repairs. No optional behavior.
    """
    # Governance directory must exist (created earlier), doctrine registry must exist.
    if not DOCTRINE_REGISTRY.exists():
        _die(40, "Smoke test failed: doctrine registry missing after load.")

    # Epistemic deltas should exist in the bundle if present; if absent, we fail-closed
    # because governance must be auditable and reproducible.
    if not DELTA_MD.exists():
        _die(41, f"Missing required epistemic delta (md): {DELTA_MD}")
    if not DELTA_JSON.exists():
        _die(42, f"Missing required epistemic delta (json): {DELTA_JSON}")

    if not RUNTIME_ENTRY.exists():
        _die(43, f"Missing runtime entrypoint: {RUNTIME_ENTRY}")


def handoff(env: Dict[str, Any], doctrines: Dict[str, Any]) -> None:
    """
    Handoff to RUN_METABLOOMS.py. We pass only validated context.
    """
    # Provide context via env var (stringified) for runtime to consume, if desired.
    # Runtime may ignore it, but boot guarantees correctness of what it provides.
    context = {
        "env": env,
        "doctrines": doctrines["loaded"],
        "rru": RRU_REFERENCE,
    }
    os.environ["METABLOOMS_BOOT_CONTEXT_JSON"] = json.dumps(context)

    # Execute runtime in the same process for determinism.
    code = compile(RUNTIME_ENTRY.read_text(encoding="utf-8"), str(RUNTIME_ENTRY), "exec")
    globals_dict = {"__name__": "__main__", "__file__": str(RUNTIME_ENTRY)}
    exec(code, globals_dict)


def main() -> int:
    try:
        env = env_sanity()
        doctrines = load_and_validate_doctrines()
        ensure_ledger(env, doctrines)
        smoke_tests()

        print("[BOOT_OK] Governance loaded; handing off to runtime.")
        handoff(env, doctrines)
        return 0
    except BootFailure as e:
        return int(e.code)
    except Exception as e:
        # Unknown error => fail-closed
        print(f"[BOOT_FAILED] Unhandled exception: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return 99


if __name__ == "__main__":
    raise SystemExit(main())
