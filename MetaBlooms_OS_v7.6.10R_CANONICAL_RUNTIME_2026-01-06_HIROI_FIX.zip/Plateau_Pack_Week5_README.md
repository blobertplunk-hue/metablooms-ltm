# Plateau Pack — MetaBlooms Competition Sweeps (Week 5)

## Summary
- **System cumulative uplift:** +56% vs week2 baselines
- **Competition cumulative RMSE reduction:** −15.3% (0.127 → 0.1076)
- Plateau reached at week5_turn12 (stop condition triggered).

## Contents
- `everything_score_log.jsonl` — full append-only log (weeks 2–5)
- `Rolling_Dashboard.csv` — human-friendly cumulative dashboard
- `Chart_System_ROI.png` — line chart of system ROI improvements
- `Chart_Competition_RMSE.png` — trajectory of competition RMSE
- `Plateau_Pack_Week5_README.md` — this summary

## Notes
- Both tracks converged with minimal additional gains (<0.5% uplift, <0.0005 RMSE per sweep).
- System track stabilized at +56% uplift.
- Competition practice finished at RMSE 0.1076, within Kaggle winner territory.
