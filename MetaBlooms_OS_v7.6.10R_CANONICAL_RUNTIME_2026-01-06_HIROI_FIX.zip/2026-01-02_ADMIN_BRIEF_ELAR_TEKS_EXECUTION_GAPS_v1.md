# 2026-01-02_ADMIN_BRIEF_ELAR_TEKS_EXECUTION_GAPS_v1
## Multi-Audience Administrative Brief (ELAR TEKS English I–IV) — Execution Gaps & Repair Principles

**Scope:** Texas ELAR TEKS English I–IV (Chapter 110, amended 06/2021).  
**Purpose:** Diagnose predictable *standards-of-execution* gaps (not a curriculum critique) and provide neutral, implementation-agnostic repair principles.

---

## Anchor Map (Document Pointers)
These anchors reference the provided TEKS PDF (section IDs and page numbers in the PDF viewer).

- **English I**: §110.36(b)(1)–(2) — integrated strands; recursive/progressive; domains — **PDF p.1**
- **English I**: §110.36(b)(6) — emphasis on oral language proficiency — **PDF p.1**
- **English II**: §110.37(b)(1)–(2) — parallel introductory structure — **PDF p.6**
- **English III**: §110.38(b)(1)–(2) — parallel introductory structure — **PDF p.11**
- **English IV**: §110.39(b)(1)–(2) — parallel introductory structure — **PDF p.16**

---

## 1) Legislature / Board (Executive-Safe Summary)

### What the standards intend
The ELAR TEKS frame literacy as an integrated system across listening, speaking, reading, writing, and “thinking,” organized into multiple strands, and taught recursively with increasing complexity (see anchors above).

### Predictable execution gaps (system-level)
1. **Schema Gaps:** Learners are expected to comprehend increasingly complex texts, but implementations often fail to build/verify the background knowledge (schema) needed for comprehension consistency.
2. **Evidence Gaps:** Verbs like “analyze,” “evaluate,” and “synthesize” are often implemented without a consistent, observable definition of mastery evidence across contexts.
3. **Repair Gaps:** When learners fail, systems default to repetition rather than targeted repair (diagnosis → specific intervention → re-check).
4. **Transfer Gaps:** Transfer across genres/domains is commonly assumed rather than measured.
5. **Vertical Coherence Gaps:** Course progression assumes prerequisites are secured; in practice, students advance with unresolved gaps, producing chronic reteaching/remediation.

### Neutral repair principles (no programs prescribed)
Require any implementation to document:
- minimum schema prerequisites per unit/skill family,
- mastery evidence definitions,
- explicit failure-mode repair pathways,
- transfer checks across domains/genres,
- vertical prerequisite guarantees.

---

## 2) TEA / Agency (Requirements That Preserve Neutrality)

**Require evidence of implementation readiness**, not a particular curriculum:
- **Mastery Evidence Model:** observable outputs that count as “analysis/evaluation” (claim + warrant + textual evidence, etc.).
- **Repair Pathways:** what happens after failure; how “repair” differs from “repeat.”
- **Transfer Validation:** demonstrated performance across at least two genres/domains before mastery is asserted.
- **Vertical Prerequisite Mapping:** prerequisite chains for major skill families (inference, argumentation, craft, vocabulary, revision/editing) and a check protocol.

---

## 3) District / Superintendent (Operational Questions)

- Do we know the **minimum schema** assumed by our texts and tasks?
- Do we have a **consistent mastery evidence definition** for complex verbs?
- When students fail, do we have **repair**, or only repetition?
- Do we measure **transfer**, or assume it?
- Are prerequisites **guaranteed** year-to-year, or recovered via endless remediation?

---

## 4) Campus Leaders (Diagnostic Prompts)

1. What background knowledge does this task assume?
2. What observable student work counts as mastery?
3. What are the top 3 failure modes and their repair moves?
4. What transfer task verifies mastery beyond the training context?
5. What prerequisite gaps should we detect early?

---

## 5) Teacher + Student Appendix (Plain Language)

**Students:** If something doesn’t make sense, it may be because the text assumes knowledge you have not yet had a chance to build. That’s a missing bridge, not a character flaw.  
**Teachers:** Pair reading and writing as evidence: reading produces a claim; writing demonstrates evidence and reasoning. Use failure as a signal to diagnose the bridge (schema, vocabulary, syntax, strategy) and repair it.

---

## Notes on Use
This brief is designed to be **publishable and implementation-agnostic**. It does not recommend programs, tools, or vendors; it specifies the *minimum conditions* that must be true for successful execution of the standards.
