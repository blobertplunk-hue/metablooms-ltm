# 2026-01-02_TEKS_ELAR_ANCHOR_MAP_v1

Source PDF: `ch-110-elar-english-i-iv-amended-0621.pdf`

## Anchor Map (viewer pages are 1-based)

- **english_i**: {'section': '§110.36', 'first_seen_page': 1}
- **english_ii**: {'section': '§110.37', 'first_seen_page': 6}
- **english_iii**: {'section': '§110.38', 'first_seen_page': 11}
- **english_iv**: {'section': '§110.39', 'first_seen_page': 16}
- **110.36_b1**: {'pattern': '110\\.36\\(b\\)\\(1\\)', 'first_seen_page': None}
- **110.36_b2**: {'pattern': '110\\.36\\(b\\)\\(2\\)', 'first_seen_page': None}
- **110.37_b1**: {'pattern': '110\\.37\\(b\\)\\(1\\)', 'first_seen_page': None}
- **110.37_b2**: {'pattern': '110\\.37\\(b\\)\\(2\\)', 'first_seen_page': None}
- **110.38_b1**: {'pattern': '110\\.38\\(b\\)\\(1\\)', 'first_seen_page': None}
- **110.38_b2**: {'pattern': '110\\.38\\(b\\)\\(2\\)', 'first_seen_page': None}
- **110.39_b1**: {'pattern': '110\\.39\\(b\\)\\(1\\)', 'first_seen_page': None}
- **110.39_b2**: {'pattern': '110\\.39\\(b\\)\\(2\\)', 'first_seen_page': None}

## Limitations
- This is a best-effort text scan; if PDF text is image-based in portions, some anchors may be missing.
- Page numbers are 1-based to match typical PDF viewers.