# 2026-01-02 OS Indexing Master Plan v1 — Technical Review (MetaBlooms)

## Executive assessment
Your plan is **strong and converges closely** with the architecture I would ship. It correctly identifies the real requirement: **query-first cognition** backed by a **canonical semantic index**, with **fail-closed governance** and **reproducible runs**.

If we define “as good as my plan” as “will it eliminate 20‑minute file hunts and prevent context-window pollution,” then: **yes, this is in the right solution class**. It is materially better than ad-hoc manifests or one-off maps because it creates an **OS subsystem** (indexer + schema + gates + ledgers) rather than a document.

## What’s excellent (keep as-is)
1. **Query-first invariant** (Section 2): This is the correct behavioral rule to stop “full rereads.”
2. **Two-layer model (Meaning + Facts)**: Separating “facts” from “meaning” prevents accidental hallucinated semantics.
3. **Multi-pass pipeline** (Pass 0–4): The staged approach matches how robust code intelligence systems work (inventory → candidate discovery → semantic reading → cross-linking → validate/render/freeze).
4. **Governance gates with advisory→gate promotion**: This is exactly how you avoid bricking early iterations while still trending toward strictness.
5. **Provenance posture**: Necessary if you are going to integrate external tools or ideas and want the OS to stay clean-room defensible.
6. **Acceptance criteria** are measurable and map to user pain.

## Where it is weaker than my plan (high-impact gaps)
These are not “nice-to-haves.” They are the difference between “we have an index” and “MetaBlooms navigates like it has spatial memory.”

### Gap A — No explicit *role-shard* indexes
You describe one canonical index (`INDEX/OS/index.meta.json`). That is necessary, but the transcript’s key improvement is **sharding cognition** so the coordinator never loads everything.

**Add:** `INDEX/OS/shards/` with deterministic shard files (small JSON) keyed by role/domain:
- `shards/boot.json`
- `shards/sandcrawler.json`
- `shards/ledgers.json`
- `shards/export_gate.json`
- `shards/learning_code_as_prose.json`
Each shard contains **only component_ids + minimal fields** (path pointers, invoked_when, key invariants). This keeps the coordinator’s “working set” small.

### Gap B — No routing table for “who answers what”
The plan says “read OSI first,” but not **how** MetaBlooms decides *which subset* of OSI to consult for a question.

**Add:** `kernel/indexing/router.py` (or `kernel/indexing/queries/router.json`) defining:
- intent patterns → shard(s)
- escalation rules → facts layer → bounded file reads
- confidence thresholds (fail-closed if below threshold)

This converts the index from a database into an **operational navigation system**.

### Gap C — No incremental / delta indexing strategy
Without incremental indexing, the system will drift toward heavy runs that eventually become “too slow,” causing people to skip them (then the index rots).

**Add:** `INDEX/OS/state/` with:
- `content_hashes.ndjson` (path → hash → last_seen)
- `component_fingerprints.json` (component_id → fingerprint of key files)
- pass-level cache markers so Pass 2 only rereads components whose fingerprints changed

### Gap D — No explicit “evidence weight” model
You require evidence, which is good. But “evidence” is not binary. In practice you will want to express:
- direct evidence (the file itself)
- derived evidence (facts layer edges)
- heuristic evidence (pattern match)

**Add:** `evidence[]` entries with:
- `kind`: direct|facts|heuristic|runtime_observed
- `weight`: 0–1
- `source`: path or facts_id
- `extract`: optional short excerpt hash pointer

This makes promotion gates more intelligent (“don’t promote on heuristics alone”).

## Concrete changes to make it “equal or better” than my plan
Below are minimal, surgical additions that preserve your structure.

### 1) Extend target end-state file tree
Add:

```
INDEX/
  OS/
    shards/
      boot.json
      sandcrawler.json
      export.json
      ledgers.json
      learning.json
    state/
      content_hashes.ndjson
      component_fingerprints.json
kernel/
  indexing/
    router.py
    passes/
      pass0_inventory.py
      ...
      pass5_shard_build.py      # build shards from canonical index
      pass6_incremental_cache.py # update hashes/fingerprints
```

### 2) Extend OSI schema (component entry)
Add fields:
- `domains` (list) — for routing and sharding
- `evidence[]` structured objects with `kind/weight/source`
- `shard_keys` (optional) — explicit shard membership override
- `confidence` (computed) — gating can require confidence >= threshold for promotion

### 3) Add a router invariant (companion to query-first)
**Router-first rule:**
1. Route question → shards (not full OSI).
2. If shards insufficient → consult full OSI.
3. If still insufficient → facts layer.
4. Only then bounded file reads.

This is the transcript pattern expressed in MetaBlooms terms.

## Relative rating
- **Your plan now:** 8.5/10 (already good enough to ship)
- **With the 4 gaps closed:** 10/10 (matches the sub-agent/sharded cognition advantage and prevents future index rot)

## Recommended next action
If you want the quickest convergence with the other chat’s ideas:
1. Keep your plan as the spine.
2. Add the four gap-fixes above as **Plan v1.1**.
3. Implement Pass 5 (Shard Build) and Router rules first; they produce the immediate “no more hunting” win.

