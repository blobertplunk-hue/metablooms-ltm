# GULP — Genuine Unified Literacy Principle

GULP is the working name for the unified literacy initiative:
- reading prose
- reading code as prose
- reading prose as code (structure-first / schema-first interpretation)
- producing writing/code via literacy production doctrine

This marker exists so the query router can reliably locate the literacy stack.
