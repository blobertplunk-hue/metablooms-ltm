# CHANGELOG — FASTBOOT_CONVENIENCE

Date: 2026-01-02

## Added
- `INDEX_QUICKREF.md` — one-page boot + lookup + Gulp quick reference.

## Updated
- `SYSTEM_INDEX.json`
  - Added `lookup.by_alias` for common instant-resolution names (`boot`, `manifest`, `system_index`, `runtime_index`, `gulp`, `router`).
  - Added `lookup.core` list for minimal critical files.

## Intent
Make the next chat able to:
- Boot immediately via `BOOT.md` + `BOOT_METABLOOMS.py`
- Resolve locations instantly via `SYSTEM_INDEX.json` without exploratory crawling
- Confirm “Gulp” presence and its canonical artifacts via index/marker

## 2026-01-03 — Epistemic Loop wiring
Added:
- `metablooms_epistemic_loop.py` — executable epistemic spine (rigor calibration + misreading alarms + adapters).
- `metablooms_epistemic_loop_doctrine_v1.md` — operational doctrine for universal transfer.
- `metablooms_epistemic_loop_activation_proof.py` — fail-closed preflight proof.

Updated:
- `boot_manifest.json` — doctrine + preflight registration.

---

Date: 2026-01-03

## Added: Epistemic Reasoning Engine high-up wiring
- Added `metablooms_reasoning_engine.py` as the canonical entrypoint for reasoning/synthesis/diagnosis.
- Added doctrine: `metablooms_reasoning_engine_doctrine_v1.md` (P0: all reasoning routes through EpistemicLoop).
- Boot preflight now runs `metablooms_reasoning_engine_activation_proof.py` (fail-closed).
- Updated `metablooms_query_router_mastery_hook_v1.py` to mediate mastery evaluation via ReasoningEngine.
- Updated `RUN_METABLOOMS.py` to include `reasoning_engine_self_check` in `RUNTIME_INDEX.json`.
- Regenerated `SYSTEM_INDEX.json` to include the new ReasoningEngine files and doctrine.
