
# Temporal Gate Rejection Reporter

import json
from pathlib import Path

def generate_temporal_rejection_report(root: Path):
    log = root / "_TDL" / "temporal_rejections.json"
    if not log.exists():
        return None
    data = json.loads(log.read_text())
    report = {
        "total_rejections": len(data),
        "examples": data[:5]
    }
    out = root / "_TDL" / "reports" / "temporal_rejection_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2))
    return out
