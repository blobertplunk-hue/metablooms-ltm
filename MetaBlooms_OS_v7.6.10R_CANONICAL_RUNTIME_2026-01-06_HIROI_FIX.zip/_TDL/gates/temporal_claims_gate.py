
# Temporal Claims Gate (P0)
# Rejects duration/recency language unless CAL/CEO ids are present

import re

TEMPORAL_PATTERNS = [
    r"\b(minutes?|hours?|days?|weeks?|months?|years?)\b",
    r"\b(recently|earlier|later|previously|long ago|just now)\b",
    r"\b(last|next)\s+(minute|hour|day|week|month|year)s?\b"
]

def temporal_claims_gate(text: str, cal_ids: list[str] | None = None) -> bool:
    cal_ids = cal_ids or []
    if not cal_ids:
        for pat in TEMPORAL_PATTERNS:
            if re.search(pat, text, re.IGNORECASE):
                return False
    return True
