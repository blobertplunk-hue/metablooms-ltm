
# Temporal Draft Linter
# Flags temporal language before gate enforcement

import re

TEMPORAL_PATTERNS = [
    r"\b(minutes?|hours?|days?|weeks?|months?|years?)\b",
    r"\b(recently|earlier|later|previously|long ago|just now)\b",
    r"\b(last|next)\s+(minute|hour|day|week|month|year)s?\b"
]

def lint_temporal_language(text: str) -> list[str]:
    findings = []
    for pat in TEMPORAL_PATTERNS:
        if re.search(pat, text, re.IGNORECASE):
            findings.append(pat)
    return findings
