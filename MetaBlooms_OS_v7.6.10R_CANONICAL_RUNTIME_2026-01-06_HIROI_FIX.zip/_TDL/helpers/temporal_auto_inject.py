
# Temporal Auto-Injection Helper
# Attaches CAL/CEO ids to outputs that reference time, when available

import re

TEMPORAL_PATTERNS = [
    r"\b(minutes?|hours?|days?|weeks?|months?|years?)\b",
    r"\b(recently|earlier|later|previously|long ago|just now)\b",
    r"\b(last|next)\s+(minute|hour|day|week|month|year)s?\b"
]

def attach_cal_ids(text: str, cal_ids: list[str]) -> dict:
    if not cal_ids:
        return {"text": text, "cal_ids": []}
    for pat in TEMPORAL_PATTERNS:
        if re.search(pat, text, re.IGNORECASE):
            return {
                "text": text + f"\n\n[CAL_IDS: {', '.join(cal_ids)}]",
                "cal_ids": cal_ids
            }
    return {"text": text, "cal_ids": cal_ids}
