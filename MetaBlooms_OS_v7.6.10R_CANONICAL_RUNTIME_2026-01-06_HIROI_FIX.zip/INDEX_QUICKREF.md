# MetaBlooms Fast Boot & Instant Lookup (QuickRef)

This file exists to make MetaBlooms **convenient** while staying **solid-as-a-rock**.

## Zero-Search Boot (What the next chat should do)

1. **Find `BOOT.md` at bundle root.**
2. Follow `BOOT.md` exactly (fail-closed).
3. The immutable entrypoint is **`BOOT_METABLOOMS.py`**.

If boot succeeds, it will emit the stable success line:
- `BOOT_OK`

## Instant “Where is X?” (No crawling)

Use `SYSTEM_INDEX.json` (schema: `metablooms.system_index.v1`) as the single source of truth.

### Core files (always present)
- `BOOT.md`
- `BOOT_METABLOOMS.py`
- `boot_manifest.json`
- `SYSTEM_INDEX.json`
- `RUNTIME_INDEX.json`

### Alias lookup (convenience)
`SYSTEM_INDEX.json -> lookup.by_alias` provides O(1) lookup for common names:

- `boot` -> `BOOT_METABLOOMS.py`
- `manifest` -> `boot_manifest.json`
- `system_index` -> `SYSTEM_INDEX.json`
- `runtime_index` -> `RUNTIME_INDEX.json`
- `gulp` -> `GULP.md`
- `router` -> (canonical query router path)

## Gulp (Universal Literacy / Code-as-Prose)

### Canonical marker
- `GULP.md`

### Primary Code-as-Prose artifacts in this bundle
- `2026-01-02_SCIENCE_OF_READING_TEKS_CODE_AS_PROSE_RESUME_PLAN_v1.md`
- `2026-01-02_SCIENCE_OF_READING_TEKS_CAP_PIPELINE_SCHEMA_v1.json`

### Router entry (when using an expanded OS that includes runtime routing)
- `metablooms/indexing/query_router.py` (see `lookup.by_alias.router`)

Expected behavior: a `gulp` intent routes to the literacy stack (GULP marker + Code-as-Prose / SoR-TEKS artifacts) and returns a structured result set.

## Reliability Rules (do not regress)

- **P0:** Boot must be impossible without a readable `SYSTEM_INDEX.json`.
- **P0:** If a subsystem is declared “present,” it must be either executable or explicitly “discoverable-only” (never implied executable).
- **Fail-closed:** ambiguity is an error state, not an invitation to guess.

