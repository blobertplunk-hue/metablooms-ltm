
"""
MetaBlooms Tool Demand Layer (TDL) v1 – Executable Scaffold

Purpose:
- Detect situation signals
- Demand tool instantiation
- Block narrative-only continuation

This is a scaffold, not full OS integration.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
import json, time, hashlib

# ----------------------------
# Situation Signals
# ----------------------------

@dataclass
class SituationSignals:
    ambiguity: bool = False
    state_exists: bool = False
    repetition: bool = False
    claim_exceeds_evidence: bool = False
    lifecycle_boundary: bool = False
    irreversibility_risk: bool = False

    def active(self):
        return [k for k, v in asdict(self).items() if v]


# ----------------------------
# Tool Demand Object
# ----------------------------

@dataclass
class ToolDemand:
    active_signals: list
    required_tool_classes: list
    risk_level: str
    timestamp: float

    def to_dict(self):
        return asdict(self)


# ----------------------------
# Utility
# ----------------------------

def snapshot_world(root: Path):
    records = []
    for p in root.rglob("*"):
        if p.is_file():
            h = hashlib.sha256(p.read_bytes()).hexdigest()
            records.append({
                "path": str(p),
                "size": p.stat().st_size,
                "sha256": h
            })
    return records


# ----------------------------
# TDL Core
# ----------------------------

def evaluate_tdl(root: Path, signals: SituationSignals):
    active = signals.active()
    if not active:
        return None

    tool_classes = set()

    if "state_exists" in active:
        tool_classes.add("world_capture")
        tool_classes.add("inspection")

    if "ambiguity" in active:
        tool_classes.add("arbitration")

    if "claim_exceeds_evidence" in active:
        tool_classes.add("audit")

    if "repetition" in active:
        tool_classes.add("historical_replay")

    if "lifecycle_boundary" in active or "irreversibility_risk" in active:
        tool_classes.add("verification")
        tool_classes.add("determinism")

    risk = "high" if len(active) >= 2 else "medium"

    return ToolDemand(
        active_signals=active,
        required_tool_classes=sorted(tool_classes),
        risk_level=risk,
        timestamp=time.time()
    )


# ----------------------------
# Example Usage
# ----------------------------

if __name__ == "__main__":
    root = Path("/mnt/data")
    signals = SituationSignals(
        ambiguity=True,
        state_exists=True,
        claim_exceeds_evidence=True
    )

    demand = evaluate_tdl(root, signals)

    if demand:
        out = root / "_TDL"
        out.mkdir(exist_ok=True)
        (out / "tool_demand.json").write_text(
            json.dumps(demand.to_dict(), indent=2)
        )
        print("TDL ACTIVE — Tool instantiation required")
        print(json.dumps(demand.to_dict(), indent=2))
    else:
        print("TDL not active — conversational reasoning permitted")
