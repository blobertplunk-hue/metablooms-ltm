
"""MetaBlooms Boot Wrapper with TDL (P0)


# MB_CHRONOLOGY_BOOT_INTEGRATION_v1
# Chronology P0: emit boot start/end CEOs + tie intent lock to CEO ids
try:
    from pathlib import Path as _MBP
    from chronology_engine import new_ceo as _mb_new_ceo, append_ceo as _mb_append_ceo
    _MB_ROOT = _MBP(__file__).resolve().parents[2] if 'ROOT' not in globals() else ROOT  # best-effort
    _mb_boot_start = _mb_append_ceo(_MB_ROOT, _mb_new_ceo(root=_MB_ROOT, event_name="boot_started", actor_id="BOOT", context="BOOT", metadata={"mode": str(mode) if 'mode' in globals() else None}))
    try:
        # If intent ack module exists, include CEO id in its status artifacts
        from intent_ack import acknowledge as _mb_ack
        _mb_ack(_MB_ROOT, "FULL_OS_ZIP" if "os" in str(mode).lower() or "boot" in str(mode).lower() else "NON_OS", str(mode), extra={"ceo_id": _mb_boot_start.id})
    except Exception:
        pass
except Exception:
    _mb_boot_start = None
This wrapper MUST be invoked before:
- boot
- export
- canonicalization

If TDL is active and required tools are not run,
execution is BLOCKED.
"""

from pathlib import Path
import json, time
from metablooms_tdl import evaluate_tdl, SituationSignals

ROOT = Path("/mnt/data")

def run_boot_or_export(mode: str):
    # Detect basic signals
    signals = SituationSignals(
        ambiguity=False,
        state_exists=any(ROOT.iterdir()),
        repetition=False,
        claim_exceeds_evidence=False,
        lifecycle_boundary=True,
        irreversibility_risk=(mode == "export"),
    )

    demand = evaluate_tdl(ROOT, signals)
    if demand:
        out = ROOT / "_TDL"
        out.mkdir(exist_ok=True)
        (out / f"{mode}_tool_demand.json").write_text(
            json.dumps(demand.to_dict(), indent=2)
        )
        raise RuntimeError(
            f"TDL ACTIVE ({mode}). Required tool classes: "
            + ", ".join(demand.required_tool_classes)
        )

    return f"{mode} permitted"

if __name__ == "__main__":
    print(run_boot_or_export("boot"))

# Intent lock acknowledgment
try:
    from intent_lock_gate import infer_and_lock
    from intent_ack import acknowledge
    _locked = infer_and_lock(mode)
    print(acknowledge(ROOT, _locked, mode))
except Exception:
    pass


# MB_CHRONOLOGY_BOOT_INTEGRATION_v1_END
try:
    from pathlib import Path as _MBP
    from chronology_engine import new_ceo as _mb_new_ceo, append_ceo as _mb_append_ceo
    _MB_ROOT = _MBP(__file__).resolve().parents[2] if 'ROOT' not in globals() else ROOT
    _mb_append_ceo(_MB_ROOT, _mb_new_ceo(root=_MB_ROOT, event_name="boot_finished", actor_id="BOOT", context="BOOT", metadata={"success": True}))
except Exception:
    pass

