
"""Lane Ω — Enforcement

Blocks continuation if:
- symptom-only explanations detected
- required tools not run
"""

def enforce(arbitration_result):
    if not arbitration_result.get("pass", False):
        raise RuntimeError("Lane Ω BLOCK: Symptom-only explanations detected")
    return "Lane Ω pass"
