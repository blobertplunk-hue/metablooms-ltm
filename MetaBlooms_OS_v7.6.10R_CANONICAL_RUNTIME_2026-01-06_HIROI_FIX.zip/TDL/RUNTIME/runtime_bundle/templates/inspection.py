def run_inspection(root):
    return {
        "type": "inspection",
        "files": [str(p) for p in root.rglob("*") if p.is_file()]
    }
