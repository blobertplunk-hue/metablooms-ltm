def run_world_capture(root):
    records = []
    for p in root.rglob("*"):
        if p.is_file():
            records.append({
                "path": str(p),
                "size": p.stat().st_size,
                "sha256": __import__("hashlib").sha256(p.read_bytes()).hexdigest()
            })
    return {
        "type": "world_capture",
        "generated_at": __import__("time").time(),
        "records": records
    }
