"""Improved verification: search for required boot markers anywhere under root."""
from pathlib import Path

REQUIRED = ["BOOT.md", "boot_manifest.json", "BOOT_METABLOOMS.py", "RUN_METABLOOMS.py"]

def verify(root: Path):
    found = {r: False for r in REQUIRED}
    for r in REQUIRED:
        for p in root.rglob(r):
            found[r] = True
            break
    missing = [r for r, ok in found.items() if not ok]
    return {"required": REQUIRED, "missing": missing, "pass": len(missing) == 0}
