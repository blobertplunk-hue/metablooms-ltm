def run_arbitration(explanations):
    flagged = [e for e in explanations if "was not" in e.lower()]
    return {
        "type": "arbitration",
        "flagged_symptom_only": flagged,
        "pass": len(flagged) == 0
    }
