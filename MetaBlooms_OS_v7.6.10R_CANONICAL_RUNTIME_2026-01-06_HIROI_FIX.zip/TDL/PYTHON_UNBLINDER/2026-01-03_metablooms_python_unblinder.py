"""MetaBlooms Python Unblinder v1

This module is a lightweight, auditable scaffold that encourages broad Python usage
via *capability lanes* and forces outputs into lane reports.

Design goals:
- Deterministic: same inputs -> same outputs
- Auditable: emits JSON/MD lane reports
- Extensible: add lane runners without breaking API
- Fail-closed optional: can be used as a gate wrapper

NOTE: This is a scaffold, not a full OS integration.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Dict, List, Optional, Any
import json
import hashlib
import time


@dataclass
class LaneResult:
    lane_id: str
    title: str
    verdict: str  # "pass" | "warn" | "fail" | "info"
    summary: str
    evidence: List[dict]
    outputs: List[str]
    started_at: float
    finished_at: float

    def to_dict(self) -> dict:
        d = asdict(self)
        d["duration_s"] = round(self.finished_at - self.started_at, 6)
        return d


LaneFn = Callable[[Path, dict], LaneResult]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def write_md(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


class LaneRunner:
    """Run multiple independent lane analyzers and emit lane reports."""

    def __init__(self) -> None:
        self._lanes: Dict[str, LaneFn] = {}

    def register(self, lane_id: str, fn: LaneFn) -> None:
        if not lane_id or not lane_id.strip():
            raise ValueError("lane_id required")
        if lane_id in self._lanes:
            raise ValueError(f"lane already registered: {lane_id}")
        self._lanes[lane_id] = fn

    def list_lanes(self) -> List[str]:
        return sorted(self._lanes.keys())

    def run(
        self,
        root: Path,
        cfg: Optional[dict] = None,
        out_dir: Optional[Path] = None,
        fail_closed: bool = False,
    ) -> dict:
        cfg = cfg or {}
        out_dir = out_dir or (root / "_unblinder_reports")
        out_dir.mkdir(parents=True, exist_ok=True)

        results: List[dict] = []
        overall = "pass"

        for lane_id in self.list_lanes():
            fn = self._lanes[lane_id]
            res = fn(root, cfg)
            results.append(res.to_dict())

            # overall aggregation
            if res.verdict == "fail":
                overall = "fail"
            elif res.verdict == "warn" and overall != "fail":
                overall = "warn"

            # per-lane JSON
            write_json(out_dir / f"lane_{lane_id}.json", res.to_dict())

        # index JSON
        index = {
            "overall": overall,
            "root": str(root),
            "lanes": self.list_lanes(),
            "results": results,
            "generated_at": time.time(),
        }
        write_json(out_dir / "unblinder_index.json", index)

        if fail_closed and overall == "fail":
            raise RuntimeError("Unblinder fail-closed: at least one lane failed")

        return index


# --- Example lanes (starter set) ---------------------------------------------

def lane_inventory(root: Path, cfg: dict) -> LaneResult:
    """Lane A-ish: inventory files and emit basic stats."""
    started = time.time()
    evidence = []
    outputs = []
    total_files = 0
    total_bytes = 0

    for p in root.rglob("*"):
        if p.is_file():
            total_files += 1
            try:
                sz = p.stat().st_size
            except OSError:
                sz = 0
            total_bytes += sz

    summary = f"Inventory: {total_files} files, {total_bytes} bytes under {root}"
    evidence.append({"metric": "total_files", "value": total_files})
    evidence.append({"metric": "total_bytes", "value": total_bytes})

    finished = time.time()
    return LaneResult(
        lane_id="inventory",
        title="File inventory",
        verdict="info",
        summary=summary,
        evidence=evidence,
        outputs=outputs,
        started_at=started,
        finished_at=finished,
    )


def lane_symptom_vs_mechanism_guard(root: Path, cfg: dict) -> LaneResult:
    """Lane H: detect symptom-only explanations in provided text inputs.

    Expected cfg:
      cfg["explanations"] = list[str]
    """
    started = time.time()
    explanations = cfg.get("explanations") or []
    evidence = []
    outputs = []

    # A small heuristic set (expand over time)
    symptom_markers = [
        "was missing",
        "was not generated",
        "wasn't generated",
        "was not loaded",
        "wasn't loaded",
        "not present",
        "couldn't find",
    ]
    mechanism_markers = [
        "because the build",
        "because the pipeline",
        "lacks an invariant",
        "no gate",
        "no preflight",
        "deferred to runtime",
        "responsibility mismatch",
        "lifecycle mismatch",
    ]

    flagged = []
    for i, s in enumerate(explanations):
        s_l = s.lower()
        has_symptom = any(m in s_l for m in symptom_markers)
        has_mechanism = any(m in s_l for m in mechanism_markers)
        if has_symptom and not has_mechanism:
            flagged.append({"index": i, "text": s})

    if flagged:
        verdict = "warn"
        summary = f"Flagged {len(flagged)} symptom-only explanations (no mechanism markers)."
        evidence.extend(flagged)
    else:
        verdict = "pass"
        summary = "No symptom-only explanations detected (heuristic)."

    finished = time.time()
    return LaneResult(
        lane_id="symptom_guard",
        title="Symptom vs mechanism guard",
        verdict=verdict,
        summary=summary,
        evidence=evidence,
        outputs=outputs,
        started_at=started,
        finished_at=finished,
    )


def build_default_runner() -> LaneRunner:
    r = LaneRunner()
    r.register("inventory", lane_inventory)
    r.register("symptom_guard", lane_symptom_vs_mechanism_guard)
    return r


if __name__ == "__main__":
    # Example usage:
    # python metablooms_python_unblinder.py /mnt/data -- will run on current directory by default
    import sys

    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".").resolve()
    runner = build_default_runner()
    idx = runner.run(root, cfg={"explanations": []}, fail_closed=False)
    print(json.dumps(idx, indent=2))
