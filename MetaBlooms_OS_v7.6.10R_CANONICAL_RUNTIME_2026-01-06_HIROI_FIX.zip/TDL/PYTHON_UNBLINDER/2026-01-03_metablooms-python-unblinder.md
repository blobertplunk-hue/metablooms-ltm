# MetaBlooms Python Unblinder v1 (Fail-Closed Capability Expansion Doctrine)

Date: 2026-01-03

## Purpose

This document removes “narrow-lane” heuristics about Python by explicitly enumerating **capability lanes** and defining a **default instantiation protocol**: when a task is non-trivial or ambiguous, MetaBlooms must *automatically* consider Python as a general-purpose instrument for **search, parsing, verification, synthesis, simulation, transformation, and artifact production**—not just “analysis” or “plotting.”

This is doctrine-level guidance: it is intended to change behavior by creating an auditable checklist and a mechanism-selection rubric.

## Problem Statement

Observed failure mode:
- Python is treated as a *small* tool (analysis-only, plotting-only, light file ops), rather than a **universal workbench**.
- As a result, the system repeatedly:
  - over-relies on a single reasoning thread,
  - fails to externalize deterministic steps,
  - and under-uses automation to prevent “symptom-as-cause” explanations.

## The Unblinder Principle

> If a reasoning step can be externalized into a deterministic program, it should be.

Python is the default language for that externalization.

## Capability Lanes (Non-Exhaustive, Practical)

### Lane A — Data Acquisition & Ingestion (Offline / Local)
Use Python to ingest:
- ZIPs, nested archives, directory trees
- PDFs (render + extract), DOCX, PPTX, XLSX
- NDJSON logs, YAML/JSON manifests
- Image sets, audio transcripts (where available)
- Any “project files” mount in `/mnt/data`

Typical outputs:
- indexed inventories
- normalized datasets
- searchable caches

### Lane B — Structure Recovery (“Make the implicit explicit”)
Use Python to recover structure from messy artifacts:
- infer schema from semi-structured text
- parse config fragments
- reconstruct dependency graphs
- detect entrypoints and required doctrine files

Typical outputs:
- graphs (DOT), adjacency lists
- schema proposals + validators
- “what depends on what” maps

### Lane C — Verification & Gating (Fail-Closed)
Use Python to enforce invariants:
- presence checks (EVG / doctrine existence)
- hash-based integrity checks
- reproducible build checks (determinism)
- regression tests (smoke + deeper tests)

Typical outputs:
- gate reports
- pass/fail verdicts with evidence pointers
- diff reports against known-good baselines

### Lane D — Search / Retrieval Over Local Corpora
Use Python to:
- build local BM25/embedding-lite search (when allowed)
- create concordances across project files
- run heuristic finders (regex, AST matching)

Typical outputs:
- ranked findings with evidence spans
- “where is X referenced” reports

### Lane E — Program Analysis & Transformation
Use Python to:
- parse Python/JS/TS code into ASTs
- detect anti-patterns
- auto-refactor known transformations
- generate patched files with DIFF logs

Typical outputs:
- patch bundles
- lint-like diagnostics
- “before/after” diffs

### Lane F — Simulation & Counterfactuals
Use Python to:
- run what-if simulations
- model scheduling, throughput, failure probability
- validate constraints and boundary cases

Typical outputs:
- scenario tables
- sensitivity analyses
- guardrail recommendations

### Lane G — Artifact Production (Ship the thing)
Use Python to generate:
- PDFs (reportlab), DOCX (python-docx), XLSX (openpyxl), HTML
- JSON bundles / manifests / ledgers
- zip exports (deterministic)

Typical outputs:
- deliverable files ready to download
- reproducible build scripts

### Lane H — Automated Multi-Lens Workflows (Pseudo “Multi-Agent”)
Even without external parallelism, Python can enforce pluralism by:
- running multiple independent analyzers
- writing their outputs to separate “lane reports”
- comparing and scoring explanations
- refusing to converge if outputs collapse to symptom statements

Typical outputs:
- lane reports (A/B/C/D…)
- arbitration scorecards
- forced re-run triggers

## Selection Rubric (When to instantiate Python)

Instantiate Python by default when **any** of the following holds:
- ambiguity is high (multiple plausible explanations)
- repeated failure modes exist
- external evidence is required
- more than ~8 reasoning steps are needed
- any non-trivial parsing, diffing, or artifact generation is involved

If none holds, Python may remain optional.

## Causal-Directionality Enforcement (Root Cause Discipline)

### Symptom vs Mechanism Gate
A “root cause” candidate MUST include:
1. An upstream **mechanism** (“what made the symptom inevitable”)
2. A **preventive lever** that can be encoded as a gate/test
3. A **generalization claim** (what other failures it prevents)

Examples (allowed):
- “Index absent because build pipeline lacks an invariant requiring index materialization at build time; fix by adding BuildGate:IndexMaterialized() with deterministic generator.”

Examples (rejected):
- “Index absent because it wasn’t generated.”

### Arbitration: Prefer Upstream, Enforceable Explanations
When lane outputs disagree, prefer the candidate that is:
- furthest upstream,
- easiest to gate,
- and most general.

## Deliverable Policy (Artifact-First)

Any non-trivial use of Python must produce at least one of:
- a report (md/json) with evidence pointers
- a generated artifact (pdf/docx/xlsx/zip)
- a reproducible script that can re-run the action deterministically

## Minimal “Unblinder” Checklist (Pasteable)

- [ ] Did we consider Python lanes A–H?
- [ ] Which lanes are relevant (and why)?
- [ ] What deterministic steps can be externalized?
- [ ] What gates/tests prevent recurrence?
- [ ] Do we have an artifact + DIFF log?
- [ ] Did we reject symptom-only explanations?

## Status

- This is a v1 doctrine draft.
- Intended next step: encode this into an executable “Lane Runner” (see accompanying Python module).
