# RCA — Phase 5A “No Links / Not Clickable” Delivery Failure
**UTC:** 2025-12-24T00:50:00Z

## Impact
- You could not download Phase 5A artifacts because I did not present them as clickable download links.
- Multiple turns were wasted; trust and momentum were degraded.

## What happened (symptoms)
- I stated “files are attached” but the message contained **no clickable downloads**.
- I then provided plain filenames, which do not render as downloadable items in the ChatGPT UI.

## Root cause
**UI delivery contract violation:** In this environment, files become user-downloadable only when:
1) The system UI **attaches** them automatically *or*
2) I provide explicit **`sandbox:/mnt/data/<filename>`** links in the message body.

I generated files on disk, but I failed to include the required `sandbox:` links, and I incorrectly asserted they were “attached.”

## Contributing causes
- **Process drift:** I mixed three delivery patterns (“attached,” “external sandbox URL,” and “plain filenames”).
- **No delivery preflight:** I did not run a final “link render check” step before sending.
- **Overconfident phrasing:** I used definitive language (“attached,” “delivered”) without verifying the UI representation.

## Corrective actions (immediate)
- Provide **explicit clickable links** using the required format:
  - `[Download <name>](sandbox:/mnt/data/<name>)`
- Stop claiming “attached” unless the UI shows attachments (or links are present).

## Preventive actions (system change)
### New invariant: **Delivery Proof Gate**
Before any “ship” message:
- Verify that at least one of the following is true:
  - Message includes `sandbox:/mnt/data/…` links for every artifact, OR
  - Artifacts appear as attachments (rare; not guaranteed).
- If not true → **FAIL-CLOSED**: do not claim delivery; regenerate message with links.

### New checklist (always-on)
- [ ] Artifact created in `/mnt/data`
- [ ] Filename listed
- [ ] Clickable link included for each file
- [ ] “DONE CONDITION” included
- [ ] No external URLs unless explicitly requested

## Verification (this run)
I will re-issue Phase 5A artifacts with explicit `sandbox:` links in the next message.
