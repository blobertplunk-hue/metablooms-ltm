# Chronology ↔ web.run Integration (Orchestrated, Fail-Closed)

## Non-negotiable constraint
Runtime Python has **no internet access** in the ChatGPT sandbox; it cannot call HTTP APIs.

Therefore **web.run integration is orchestration-time**, not runtime-time:

1. The orchestrator (assistant) runs `web.run` for a time question.
2. The orchestrator extracts a timestamp (and keeps the web source ref id).
3. The orchestrator passes a `ResolvedExternalTime` payload into the Chronology Engine.
4. The Chronology Engine mints an **external CEO** whose `ts_utc` is the *external* event time and whose evidence_refs include the `web_source_ref`.

This preserves MetaBlooms principles:
- Evidence is first-class and referenced by id.
- No time claims without provenance.
- Fail-closed when evidence is missing.

## Required payload fields
See: `webrun_resolved_time_contract.json`

## Usage pattern (pseudo)
- Run `web.run` query
- Identify the authoritative timestamp
- Create payload:
  - query
  - parsed_ts_utc
  - web_source_ref
  - (optional) evidence_url, snippet, extractor, confidence
- Validate payload with `webrun_bridge.require_resolved(payload)`
- Call `chronology_engine_v2.make_external_ceo_from_webrun(...)` with these fields
- Append CEO to log

## Gate policy
Any gate relying on external time MUST require:
- CEO.event_type == "external"
- CEO.source == "web.run"
- evidence_refs includes the web source ref id
