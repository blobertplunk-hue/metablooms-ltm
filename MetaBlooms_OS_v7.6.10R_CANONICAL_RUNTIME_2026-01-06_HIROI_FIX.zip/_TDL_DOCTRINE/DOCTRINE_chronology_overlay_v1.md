# MetaBlooms Chronology Engine Overlay v1 (CEO v2)

## What this adds
- **Append-only** chronology log (`_TDL/chronology/chronology.ndjson`) using JSON Lines (one JSON per line). citeturn0search3
- **Tamper-evident** integrity via hash chaining for each record. citeturn0search13
- **Dual ordering**:
  - Physical time (`ts_utc`)
  - Logical time (`logical_clock`) based on Lamport's happened-before model. citeturn0search2
- **Fail-closed gates** for:
  - event existence
  - duration claims
  - ordering claims

## Why NDJSON instead of a single JSON array
NDJSON/JSON Lines is designed for streaming and log files, and it is resilient to partial writes and truncation. citeturn0search3turn0search22

## Why hash chaining
Hash chaining is a standard technique to make log records verifiable and tamper-evident. citeturn0search13

## How this aligns with log management guidance
Time-stamped, detailed logs support auditing, forensic reconstruction, and baselining—core to MetaBlooms chronology. citeturn0search0turn0search8

## Integration points (required)
1. BOOT wrapper: emit `boot_started` / `boot_finished` CEOs
2. Each gate: emit `gate:<name>:start` / `gate:<name>:end` CEOs and enforce `gate_duration`
3. Release builder: emit `release_build_started` / `release_build_finished`
4. Any external-time claim: must be represented by an external CEO with `web_source_ref`

## Contract
- If a response contains “recently / weeks / minutes / yesterday / last time” without CEO references, it is **invalid**.
