# MetaBlooms Boot (Project-Files Bundle)

This bundle is **bootable** and designed to let a fresh chat boot immediately without exploratory work.

## Entrypoint

- **Immutable entrypoint:** `BOOT_METABLOOMS.py`
- **Authoritative manifest:** `boot_manifest.json`

## Index (must already exist)

- **Canonical system index:** `SYSTEM_INDEX.json`
  - Required at boot time.
  - Validated fail-closed by `metablooms_system_index_gate.py`.
  - If missing or corrupt, the gate regenerates deterministically via `metablooms_system_index.py`.

- **Runtime payload index:** `RUNTIME_INDEX.json`
  - Produced by `RUN_METABLOOMS.py` at runtime for convenience.

## Fail-closed guarantees

A boot is only considered successful if:
- Doctrine files listed in `boot_manifest.json` exist and are readable.
- Preflight scripts listed in `boot_manifest.json` run successfully **in order**.
- The system index gate prints `SYSTEM_INDEX_OK`.

## Quick verification signals

- `SYSTEM_INDEX_OK`
- `BOOTGATE_OK`
- `RUN_OK: wrote RUNTIME_INDEX.json (...)`

