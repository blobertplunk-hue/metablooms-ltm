# Apply This MVKL Bundle to MetaBlooms OS

**Goal:** Add Experience Record + Policy Artifact layers, then enforce one policy that prevents
"assume SYSTEM_INDEX is loaded" failures.

## Order (must follow)
1) Copy files from this bundle into the OS tree (preserve paths).
2) Add `POLICY-INDEX-REQUIRED-BEFORE-REASONING` into `policies/policy_registry.json` OR
   merge `policies/ready_policy_INDEX_REQUIRED.json` as an enabled policy.
3) Wire the enforcement hook at the earliest reasoning entrypoint:
   - compute `SYSTEM_INDEX_READY`
   - call `runtime.reasoning_policy_enforcer.enforce_before_reasoning(...)`
4) Verify:
   - If index is not ready, reasoning blocks and writes an experience record.
   - If index is ready, reasoning proceeds.

## Notes
- GULP is unchanged. This module does not call GULP.
- This is "behavioral learning" because policy enforcement changes future behavior deterministically.
