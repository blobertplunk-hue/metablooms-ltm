MetaBlooms OS v7.6.10R

Changes:
- Sandcrawler promoted to global invariant
- Sandcrawler run stats tracked
- Manifest Outputter subsystem added
- Ingestion outputs now registered OS artifacts

This build eliminates heuristic-only planning.