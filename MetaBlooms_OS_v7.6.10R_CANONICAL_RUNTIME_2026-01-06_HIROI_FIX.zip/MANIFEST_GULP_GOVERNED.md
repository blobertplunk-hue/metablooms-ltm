MultiMetaBlooms OS v7.6.9R — ProjectFiles Bootable — GULP Governed Patch
Generated: 2026-01-04 00:49:27 UTC

Adds:
- Expanded GULP.md (P0 invariant + phases + artifact-type reading modes)
- metablooms/governance/preflight_gate.py (fail-closed)
- metablooms/governance/csrd_thresholds.json (observer thresholds)

Base: MultiMetaBlooms_OS_v7_6_9R_PROJECTFILES_BOOTABLE_INDEXED_ROUTABLE_FASTBOOT_CONVENIENCE_PATCHED.zip
