# Index Coverage + Query Router

Generated: 2026-01-02T19:49:01.347661+00:00

## Coverage
- Total files on disk: 367
- Excluded by policy: 8
- Non-excluded files: 359
- Indexed entries (canonical): 367
- Coverage (non-excluded): 100.00%

## Query Router Paths (canonical)
- canonical_index: `metablooms/indexing/OS_INDEX_CANONICAL.json`
- views_index: `metablooms/indexing/OS_INDEX_VIEWS.json`
- human_index: `metablooms/indexing/OS_INDEX.md`
- generator: `metablooms/indexing/generate_os_index.py`
- alias_pack: `metablooms/indexing/ALIAS_PACK.json`
- query_templates: `metablooms/indexing/QUERY_TEMPLATES.json`
- query_router: `metablooms/indexing/query_router.py`

## Snap-mode add-ons
- Alias Pack: normalizes vague phrasing into canonical hints/tags/subsystems.
- Query Templates: common workflows (boot flow, export flow, EVG enforcement, Sandcrawler fail-close) represented as machine-readable steps.

## Example queries
- `python metablooms/indexing/query_router.py whereis --hint "ship os"`
- `python metablooms/indexing/query_router.py find --text "fail close" --limit 25`
- `python metablooms/indexing/query_router.py template --name sandcrawler_fail_close`
- `python metablooms/indexing/query_router.py subsystem --name governance`

## Exclusion policy (coverage)
- `__pycache__/`, `*.pyc`, `*.pyo`, `.DS_Store`, `Thumbs.db`, `.git/`
