#!/usr/bin/env python3
"""MetaBlooms Governance Preflight Gate — GULP-governed (fail-closed)

This gate is intended to be invoked by BOOT_METABLOOMS.py (or export tooling) before shipping.
It verifies that GULP doctrine exists and that an OS index is present, then records a pass/fail artifact.

Fail-closed: if checks fail, downstream ship/export must not proceed.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, Any

class PreflightError(RuntimeError):
    pass

def run(project_root: str) -> Dict[str, Any]:
    root = Path(project_root)

    # required doctrine/artifacts
    required = [
        # Top-level markers
        root / "GULP.md",
        root / "SYSTEM_INDEX.json",
        root / "boot_manifest.json",
        # Canonical P0 doctrine (must not be bypassable)
        root / "metablooms" / "governance" / "DOCTRINE_GULP_P0.md",
        root / "metablooms" / "governance" / "DOCTRINE_GAP_GOVERNANCE_P0.md",
        # Sandcrawler governance invariants (auditable research)
        root / "metablooms" / "governance" / "invariants" / "INVARIANT_SANDCRAWLER_IMPROVEMENT_REPORT.md",
        # Ledger substrate (durable continuity)
        root / "metablooms" / "ledgers" / "SCHEMAS_LEDGER_v1.json",
        # Runtime enforcement modules
        root / "metablooms" / "governance" / "GULP_GATE_RUNTIME.py",
        root / "metablooms" / "governance" / "gapfinder.py",
        root / "metablooms" / "governance" / "gapfiller.py",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise PreflightError(f"Missing required artifacts: {missing}")

    # minimal sanity: SYSTEM_INDEX must be parseable JSON
    try:
        json.loads((root / "SYSTEM_INDEX.json").read_text(encoding="utf-8", errors="ignore"))
    except Exception as e:
        raise PreflightError(f"SYSTEM_INDEX.json invalid JSON: {e}")

    return {"ok": True, "gate": "GULP_GOVERNANCE_PREFLIGHT", "version": "1.0"}

if __name__ == "__main__":
    print(json.dumps(run("."), indent=2))
