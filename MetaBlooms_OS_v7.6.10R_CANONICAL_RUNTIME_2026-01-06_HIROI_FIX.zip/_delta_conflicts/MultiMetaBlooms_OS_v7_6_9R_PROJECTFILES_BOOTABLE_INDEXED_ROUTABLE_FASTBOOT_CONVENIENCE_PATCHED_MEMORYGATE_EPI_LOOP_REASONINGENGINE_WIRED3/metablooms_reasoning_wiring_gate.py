#!/usr/bin/env python3
"""Reasoning Wiring Gate (fail-closed preflight).

Fail-closed static wiring check: required modules must explicitly import
`metablooms_reasoning_engine`. This prevents regressions where high-leverage
modules bypass the EpistemicLoop-mediated ReasoningEngine.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).parent


REQUIRED = [
    "metablooms_mastery_gate_v1.py",
    "metablooms_mer_producer_v1.py",
    "query_router.py",
]


def fail(msg: str) -> None:
    raise SystemExit(f"REASONING_WIRING_FAIL: {msg}")


def main() -> None:
    for fname in REQUIRED:
        fp = ROOT / fname
        if not fp.exists():
            fail(f"missing required module file: {fname}")
        txt = fp.read_text(encoding="utf-8", errors="ignore")
        if "metablooms_reasoning_engine" not in txt:
            fail(f"{fname} not wired: missing 'metablooms_reasoning_engine' import")

    # Smoke imports (ensures no syntax/import errors)
    try:
        __import__("metablooms_mastery_gate_v1")
        __import__("metablooms_mer_producer_v1")
        __import__("query_router")
    except Exception as e:
        fail(f"import smoke failed: {e}")

    print("REASONING_WIRING_OK")


if __name__ == "__main__":
    main()
