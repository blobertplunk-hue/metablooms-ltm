"""MetaBlooms Literacy WQI Ledger v1 (minimal implementation).

This module exists so MER producers and evaluators have a canonical, append-only
ledger sink inside the bundle.

Design goals
- Deterministic
- Append-only
- No external dependencies

Ledger format
- Newline-delimited JSON (NDJSON)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional


ROOT = Path(__file__).resolve().parent
DEFAULT_LEDGER_PATH = str((ROOT / "ledgers" / "literacy_wqi_ledger.ndjson").as_posix())


def append_run(record: Dict[str, Any], *, ledger_path: Optional[str] = None) -> None:
    """Append a single run record to the WQI ledger (NDJSON)."""
    lp = Path(ledger_path or DEFAULT_LEDGER_PATH)
    lp.parent.mkdir(parents=True, exist_ok=True)
    lp.open("a", encoding="utf-8").write(json.dumps(record, ensure_ascii=False) + "\n")
