# CHANGELOG — FASTBOOT_CONVENIENCE

Date: 2026-01-02

## Added
- `INDEX_QUICKREF.md` — one-page boot + lookup + Gulp quick reference.

## Updated
- `SYSTEM_INDEX.json`
  - Added `lookup.by_alias` for common instant-resolution names (`boot`, `manifest`, `system_index`, `runtime_index`, `gulp`, `router`).
  - Added `lookup.core` list for minimal critical files.

## Intent
Make the next chat able to:
- Boot immediately via `BOOT.md` + `BOOT_METABLOOMS.py`
- Resolve locations instantly via `SYSTEM_INDEX.json` without exploratory crawling
- Confirm “Gulp” presence and its canonical artifacts via index/marker

