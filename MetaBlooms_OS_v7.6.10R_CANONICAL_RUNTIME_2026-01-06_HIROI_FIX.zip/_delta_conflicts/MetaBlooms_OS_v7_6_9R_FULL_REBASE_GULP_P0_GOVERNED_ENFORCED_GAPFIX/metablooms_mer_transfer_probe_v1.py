"""
MetaBlooms MER Transfer Probe v1 (Scaffold)

Purpose:
- Define a transfer-aware assessment probe that can be used by MER.
- Near transfer: same topic, different passage form.
- Mid transfer: different topic, same structure/skill demand.
- Far transfer is intentionally not implemented in v1 (risk of overclaiming).

Design constraints:
- K–12 progression: probes are parameterized by grade_band.
- Evidence discipline: probes must emit explicit criteria for PASS/HOLD and log what counted as evidence.
"""

from __future__ import annotations
from typing import Dict, Any, List


def build_transfer_probe(
    *,
    grade_band: str,
    skill: str,
    near_text: str,
    mid_text: str,
) -> Dict[str, Any]:
    """
    Returns a structured probe specification. Execution is performed elsewhere (MER executor).
    """
    return {
        "probe_id": f"TPv1::{grade_band}::{skill}",
        "grade_band": grade_band,
        "skill": skill,
        "near": {
            "text": near_text,
            "task": "Apply the same skill to a closely related text; cite evidence.",
            "pass_criteria": [
                "Identifies target skill output correctly",
                "Cites >=1 relevant detail as evidence",
            ],
        },
        "mid": {
            "text": mid_text,
            "task": "Apply the same skill to a different topic but similar structure; cite evidence.",
            "pass_criteria": [
                "Identifies target skill output correctly",
                "Cites >=1 relevant detail as evidence",
            ],
        },
        "governance": {
            "fail_close": True,
            "notes": "If near passes but mid fails → HOLD and schedule targeted instruction + re-probe.",
        },
    }


def evaluate_transfer_results(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Minimal evaluation: expects result dicts with keys {tier: 'near'|'mid', pass: bool, evidence: [...]}
    """
    by_tier = {r["tier"]: r for r in results}
    near_ok = bool(by_tier.get("near", {}).get("pass"))
    mid_ok = bool(by_tier.get("mid", {}).get("pass"))
    decision = "PASS" if (near_ok and mid_ok) else "HOLD"
    return {
        "decision": decision,
        "near_pass": near_ok,
        "mid_pass": mid_ok,
        "next_required": "Proceed to far transfer only after stable PASS across multiple probes." if decision=="PASS"
                        else "Targeted instruction + re-probe; do not claim transfer.",
    }
