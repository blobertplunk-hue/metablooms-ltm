#!/usr/bin/env python3
"""
MetaBlooms Export Gate (Fail-Closed)
Purpose:
- Prevent "ellipsis/truncation" artifacts and dormant capabilities from shipping.
- Enforce that shipped subsystems are wired + testable.

Usage:
  python metablooms_export_gate.py /path/to/MetaBlooms_OS.zip
  python metablooms_export_gate.py /path/to/extracted_dir

Exit codes:
  0 = PASS
  2 = FAIL (violations found)
"""
from __future__ import annotations
import sys, os, zipfile, tempfile, shutil, re, json
from pathlib import Path

# --- Policy knobs (conservative defaults) ---
MIN_TEXT_BYTES_DEFAULT = 80  # below this, a text file is suspicious unless allowlisted
SUSPICIOUS_TOKENS = [
    r"\.\.\.",                 # ellipsis
    r'"status"\s*:\s*"locked"', # locked markers
    r"\bLocked\.\b",            # "Locked."
    r"\bPLACEHOLDER\b",
    r"\bTODO\b",
]

# Files that are allowed to be very small (bytes) or empty by design.
SMALL_ALLOWLIST = {
    "control_plane/__init__.py",
}

# Patterns that indicate a file is likely machine-readable even if small (rare; keep tight)
SMALL_JSON_ALLOW_PATTERNS = [
    re.compile(r"^boot_.*\.json$"),
]

TEXT_EXTS = {".md", ".txt", ".py", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg"}

def is_text_file(p: Path) -> bool:
    return p.suffix.lower() in TEXT_EXTS

def scan_tree(root: Path) -> list[dict]:
    violations: list[dict] = []
    token_res = [re.compile(t, re.IGNORECASE | re.MULTILINE) for t in SUSPICIOUS_TOKENS]

    for fp in root.rglob("*"):
        if fp.is_dir():
            continue
        rel = fp.relative_to(root).as_posix()
        size = fp.stat().st_size

        if rel in SMALL_ALLOWLIST:
            continue

        if is_text_file(fp):
            try:
                data = fp.read_text(errors="replace")
            except Exception as e:
                violations.append({"type":"READ_ERROR","path":rel,"detail":str(e)})
                continue

            # Suspicious token scan
            for cre in token_res:
                if cre.search(data):
                    violations.append({"type":"SUSPICIOUS_TOKEN","path":rel,"detail":cre.pattern})
                    break

            # Tiny text heuristic (catch truncated manifests/docs)
            if size < MIN_TEXT_BYTES_DEFAULT:
                # allow a few small json control files only if name matches
                if fp.suffix.lower() == ".json" and any(pat.match(fp.name) for pat in SMALL_JSON_ALLOW_PATTERNS):
                    continue
                violations.append({"type":"TINY_TEXT_FILE","path":rel,"detail":f"{size} bytes < {MIN_TEXT_BYTES_DEFAULT}"})

    # Activation wiring checks (best-effort, still fail-closed)
    # Require core boot artifacts
    required = ["BOOT_METABLOOMS.py", "RUN_METABLOOMS.py", "boot_manifest.json", "boot_contract.json"]
    for req in required:
        if not (root / req).exists():
            violations.append({"type":"MISSING_REQUIRED","path":req,"detail":"required boot artifact missing"})

    # Require a control_plane activation registry and boot activator (prevents dormancy)
    wiring = [
        "control_plane/activation_registry.py",
        "control_plane/boot_activator.py",
        "control_plane/shopping_mode_controller.py",
    ]
    for req in wiring:
        if not (root / req).exists():
            violations.append({"type":"MISSING_WIRING","path":req,"detail":"required wiring module missing"})

    # Ensure RUN_METABLOOMS imports/uses boot_activator (very simple check)
    runp = root / "RUN_METABLOOMS.py"
    if runp.exists():
        txt = runp.read_text(errors="replace")
        if "boot_activator" not in txt:
            violations.append({"type":"DORMANT_RISK","path":"RUN_METABLOOMS.py","detail":"does not reference boot_activator"})
        if "SHOPPING_MODE_CONTROLLER" not in txt:
            violations.append({"type":"DORMANT_RISK","path":"RUN_METABLOOMS.py","detail":"does not reference SHOPPING_MODE_CONTROLLER"})

    return violations

def materialize(input_path: Path) -> Path:
    if input_path.is_dir():
        return input_path
    if input_path.is_file() and input_path.suffix.lower() == ".zip":
        tmp = Path(tempfile.mkdtemp(prefix="mb_export_gate_"))
        with zipfile.ZipFile(input_path, "r") as z:
            z.extractall(tmp)
        return tmp
    raise SystemExit(f"Unsupported input: {input_path}")

def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(__doc__.strip())
        return 2
    inp = Path(argv[1]).expanduser().resolve()
    root = materialize(inp)

    violations = scan_tree(root)
    if violations:
        print("EXPORT_GATE_FAIL")
        print(f"violations={len(violations)}")
        for v in violations[:200]:
            print(f"- {v['type']}: {v['path']} :: {v['detail']}")
        if len(violations) > 200:
            print(f"... and {len(violations)-200} more")
        return 2

    print("EXPORT_GATE_PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
