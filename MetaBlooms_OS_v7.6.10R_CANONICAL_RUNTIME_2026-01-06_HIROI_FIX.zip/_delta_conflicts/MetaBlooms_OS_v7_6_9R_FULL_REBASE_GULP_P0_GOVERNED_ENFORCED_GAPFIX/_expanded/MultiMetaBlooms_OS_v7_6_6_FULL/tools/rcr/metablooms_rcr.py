#!/usr/bin/env python3
"""
MetaBlooms RCR Engine (Root Cause & Repair) — Fail-Closed, Auto-Repair Where Safe

Goals:
- When a gate fails (ellipsis/truncation, locked placeholders, dormant wiring), produce:
  1) Root cause classification
  2) Repair plan
  3) Auto-repair patch set (safe subset only)
  4) Re-run gates + emit receipts

Usage:
  python metablooms_rcr.py analyze <zip_or_dir>
  python metablooms_rcr.py repair  <zip_or_dir> --out <dir_or_zip>

Exit codes:
  0 PASS
  2 FAIL (analysis/repair could not reach PASS)
"""
from __future__ import annotations
import argparse, sys, zipfile, tempfile, shutil, json, re
from pathlib import Path
from datetime import datetime

TEXT_EXTS = {".md",".txt",".py",".json",".yaml",".yml",".toml",".ini",".cfg"}

SUSPICIOUS_PATTERNS = [
    ("ELLIPSIS", re.compile(r"\.\.\.", re.IGNORECASE|re.MULTILINE)),
    ("LOCKED_STATUS", re.compile(r'"status"\s*:\s*"locked"', re.IGNORECASE|re.MULTILINE)),
    ("LOCKED_WORD", re.compile(r"\bLocked\.\b", re.IGNORECASE|re.MULTILINE)),
    ("PLACEHOLDER", re.compile(r"\bPLACEHOLDER\b", re.IGNORECASE|re.MULTILINE)),
    ("TODO", re.compile(r"\bTODO\b", re.IGNORECASE|re.MULTILINE)),
]

CORE_REQUIRED = ["BOOT_METABLOOMS.py","RUN_METABLOOMS.py","boot_manifest.json","boot_contract.json"]
WIRING_REQUIRED = [
    "control_plane/activation_registry.py",
    "control_plane/boot_activator.py",
    "control_plane/shopping_mode_controller.py",
]

def is_text(p: Path)->bool:
    return p.suffix.lower() in TEXT_EXTS

def materialize(inp: Path) -> tuple[Path, Path|None]:
    """Return (root, tmp_dir_if_any)."""
    if inp.is_dir():
        return inp, None
    if inp.is_file() and inp.suffix.lower()==".zip":
        tmp = Path(tempfile.mkdtemp(prefix="mb_rcr_"))
        with zipfile.ZipFile(inp,"r") as z:
            z.extractall(tmp)
        return tmp, tmp
    raise SystemExit(f"Unsupported input: {inp}")

def scan(root: Path) -> list[dict]:
    v=[]
    # missing core
    for req in CORE_REQUIRED:
        if not (root/req).exists():
            v.append({"type":"MISSING_REQUIRED","path":req,"detail":"required boot artifact missing"})
    for req in WIRING_REQUIRED:
        if not (root/req).exists():
            v.append({"type":"MISSING_WIRING","path":req,"detail":"required wiring missing"})
    # dormant risk: RUN not referencing boot_activator / controller
    runp=root/"RUN_METABLOOMS.py"
    if runp.exists():
        txt=runp.read_text(errors="replace")
        if "boot_activator" not in txt:
            v.append({"type":"DORMANT_RISK","path":"RUN_METABLOOMS.py","detail":"does not reference boot_activator"})
        if "SHOPPING_MODE_CONTROLLER" not in txt and "shopping_mode_controller" not in txt:
            v.append({"type":"DORMANT_RISK","path":"RUN_METABLOOMS.py","detail":"does not reference shopping mode"})
    # token scan + tiny text heuristic
    for fp in root.rglob("*"):
        if fp.is_dir():
            continue
        rel=fp.relative_to(root).as_posix()
        if is_text(fp):
            data=fp.read_text(errors="replace")
            for name,cre in SUSPICIOUS_PATTERNS:
                if cre.search(data):
                    v.append({"type":"SUSPICIOUS_TOKEN","path":rel,"detail":name})
                    break
            if fp.stat().st_size < 80:
                # common stubs: lock markers / tiny manifests
                v.append({"type":"TINY_TEXT_FILE","path":rel,"detail":f"{fp.stat().st_size} bytes"})
    return v

def classify(violations:list[dict]) -> dict:
    """Root-cause buckets with counts."""
    buckets={
        "TRUNCATION_OR_PLACEHOLDER":0,
        "DORMANT_WIRING":0,
        "MISSING_CORE":0,
        "TINY_STUBS":0,
        "OTHER":0,
    }
    for v in violations:
        t=v["type"]
        if t=="SUSPICIOUS_TOKEN":
            buckets["TRUNCATION_OR_PLACEHOLDER"]+=1
        elif t=="DORMANT_RISK" or t=="MISSING_WIRING":
            buckets["DORMANT_WIRING"]+=1
        elif t=="MISSING_REQUIRED":
            buckets["MISSING_CORE"]+=1
        elif t=="TINY_TEXT_FILE":
            buckets["TINY_STUBS"]+=1
        else:
            buckets["OTHER"]+=1
    return buckets

def safe_autorepair(root: Path, violations:list[dict]) -> list[dict]:
    """
    Apply SAFE repairs only:
    - quarantine placeholder/locked/tiny stub docs into stubs_quarantine/ (excluded at export)
    - ensure RUN_METABLOOMS imports boot_activator.activate_all() and enforces activation gate
    - add an EXPORT_EXCLUDE.txt used by exporters to skip quarantined stubs
    """
    actions=[]
    quarantine=root/"stubs_quarantine"
    quarantine.mkdir(exist_ok=True)

    # 1) Quarantine placeholder/locked/tiny stub files (safe; preserves data)
    for v in violations:
        if v["type"] in ("SUSPICIOUS_TOKEN","TINY_TEXT_FILE"):
            p=root/Path(v["path"])
            if p.exists() and p.is_file():
                dest=quarantine/Path(v["path"]).name
                try:
                    shutil.copy2(p, dest)
                    p.unlink()
                    actions.append({"action":"QUARANTINE_STUB","path":v["path"],"to":dest.relative_to(root).as_posix()})
                except Exception as e:
                    actions.append({"action":"QUARANTINE_FAILED","path":v["path"],"error":str(e)})

    # 2) Ensure RUN_METABLOOMS wiring (safe textual patch)
    runp=root/"RUN_METABLOOMS.py"
    if runp.exists():
        txt=runp.read_text(errors="replace")
        changed=False
        if "boot_activator" not in txt:
            # insert near top
            inject = "\nfrom control_plane import boot_activator\n"
            txt = inject + txt
            changed=True
        # ensure activate_all called
        if "boot_activator.activate_all" not in txt:
            # naive insert before main guard or at end
            marker = "if __name__ == \"__main__\":"
            if marker in txt:
                txt = txt.replace(marker, "boot_activator.activate_all()\n\n"+marker, 1)
            else:
                txt += "\n\nboot_activator.activate_all()\n"
            changed=True
        # ensure activation gate
        if "ACTIVATION_REGISTRY" not in txt:
            gate = "\nfrom control_plane.activation_registry import ACTIVATION_REGISTRY\n"
            txt = gate + txt
            changed=True
        if "assert ACTIVATION_REGISTRY.is_active" not in txt:
            gate_block = "\n# Activation Gate (fail-closed)\nfor _sys in ACTIVATION_REGISTRY.required_systems():\n    assert ACTIVATION_REGISTRY.is_active(_sys), f\"{_sys} not active\"\n"
            txt += gate_block
            changed=True
        if changed:
            runp.write_text(txt, encoding="utf-8")
            actions.append({"action":"PATCH_RUN_METABLOOMS","path":"RUN_METABLOOMS.py","detail":"wired boot_activator + activation gate"})

    # 3) Add export exclude list (used by exporters/gates)
    ex = root/"EXPORT_EXCLUDE.txt"
    if not ex.exists():
        ex.write_text("stubs_quarantine/\n", encoding="utf-8")
        actions.append({"action":"ADD_EXPORT_EXCLUDE","path":"EXPORT_EXCLUDE.txt","detail":"exclude stubs_quarantine/ from ship"})
    return actions

def write_reports(root: Path, violations:list[dict], buckets:dict, actions:list[dict], outdir:Path)->None:
    outdir.mkdir(parents=True, exist_ok=True)
    ts=datetime.now().strftime("%Y-%m-%d_%H%M%S")
    (outdir/"violations.json").write_text(json.dumps(violations,indent=2),encoding="utf-8")
    (outdir/"root_cause_buckets.json").write_text(json.dumps(buckets,indent=2),encoding="utf-8")
    (outdir/"actions.json").write_text(json.dumps(actions,indent=2),encoding="utf-8")
    plan = []
    plan.append(f"# MetaBlooms RCR Report\n\nTimestamp: {ts}\n")
    plan.append("## Root cause buckets\n")
    for k,v in buckets.items():
        plan.append(f"- {k}: {v}\n")
    plan.append("\n## Violations (top 100)\n")
    for v in violations[:100]:
        plan.append(f"- {v['type']}: `{v['path']}` — {v['detail']}\n")
    if len(violations)>100:
        plan.append(f"\n… plus {len(violations)-100} more.\n")
    plan.append("\n## Actions applied (safe subset)\n")
    if actions:
        for a in actions:
            plan.append(f"- {a['action']}: {a.get('path','')} {a.get('detail','')}\n")
    else:
        plan.append("- (none)\n")
    (outdir/"RCR_REPORT.md").write_text("".join(plan),encoding="utf-8")

def rezip(root: Path, out_zip: Path)->None:
    if out_zip.exists():
        out_zip.unlink()
    with zipfile.ZipFile(out_zip,"w",zipfile.ZIP_DEFLATED) as z:
        for fp in root.rglob("*"):
            rel=fp.relative_to(root).as_posix()
            z.write(fp, arcname=rel)

def cmd_analyze(args)->int:
    inp=Path(args.input).expanduser().resolve()
    root,tmp = materialize(inp)
    violations=scan(root)
    buckets=classify(violations)
    outdir=Path(args.report_dir).expanduser().resolve()
    write_reports(root, violations, buckets, [], outdir)
    if tmp: shutil.rmtree(tmp, ignore_errors=True)
    print(str(outdir/"RCR_REPORT.md"))
    return 0 if not violations else 2

def cmd_repair(args)->int:
    inp=Path(args.input).expanduser().resolve()
    root,tmp = materialize(inp)
    violations=scan(root)
    buckets=classify(violations)
    actions=[]
    if violations:
        actions = safe_autorepair(root, violations)
        # rescan after repair
        violations2=scan(root)
        buckets2=classify(violations2)
    else:
        violations2=[]
        buckets2=buckets
    outdir=Path(args.report_dir).expanduser().resolve()
    write_reports(root, violations2, buckets2, actions, outdir)

    # output
    out=args.out
    if out:
        outp=Path(out).expanduser().resolve()
        if outp.suffix.lower()==".zip":
            rezip(root, outp)
            print(f"Wrote repaired zip: {outp}")
        else:
            if outp.exists():
                shutil.rmtree(outp)
            shutil.copytree(root, outp)
            print(f"Wrote repaired dir: {outp}")

    if tmp: shutil.rmtree(tmp, ignore_errors=True)
    return 0 if not violations2 else 2

def main(argv:list[str])->int:
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd", required=True)

    a=sub.add_parser("analyze")
    a.add_argument("input")
    a.add_argument("--report-dir", default="rcr_reports")
    a.set_defaults(fn=cmd_analyze)

    r=sub.add_parser("repair")
    r.add_argument("input")
    r.add_argument("--out", required=False, help="Output dir or .zip for repaired artifact")
    r.add_argument("--report-dir", default="rcr_reports")
    r.set_defaults(fn=cmd_repair)

    args=ap.parse_args(argv[1:])
    return args.fn(args)

if __name__=="__main__":
    raise SystemExit(main(sys.argv))
