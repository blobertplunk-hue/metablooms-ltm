"""
MetaBlooms Query Router Mastery Hook v1

Purpose:
- Provide a small, explicit integration point so the Query Router can answer:
  - "Do we have mastery for X?"
  - "Is this evidence eligible for mastery?"
- Enforces DEMO DATA RULE via metablooms_mastery_gate_v1.
- Adds optional TRANSFER PROBE REQUIREMENT for mastery (policy flag).

This module is intentionally adapter-only: it does not change core router logic.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from metablooms_mastery_gate_v1 import mastery_gate


def requires_transfer_for_mastery(record: Dict[str, Any]) -> bool:
    """
    Policy hook. For now:
    - If record already contains transfer results, require near+mid pass.
    - If no transfer results exist, return True (conservative) so mastery holds.
    """
    tp = record.get("transfer_probe")
    if not tp:
        return True
    near_ok = bool(tp.get("near_pass"))
    mid_ok = bool(tp.get("mid_pass"))
    return not (near_ok and mid_ok)


def evaluate_mastery_for_record(
    record: Dict[str, Any],
    *,
    enforce_transfer: bool = True,
) -> Dict[str, Any]:
    """
    Returns a router-friendly evaluation object.
    """
    gate = mastery_gate(record)
    if gate.decision != "PASS":
        return {
            "mastery_decision": gate.decision,
            "mastery_reason": gate.reason,
            "next_required": gate.next_required,
        }

    if enforce_transfer and requires_transfer_for_mastery(record):
        return {
            "mastery_decision": "HOLD",
            "mastery_reason": "Transfer evidence missing or insufficient (near+mid required).",
            "next_required": "Run transfer probes (near+mid) on real (non-demo) text; attach results to record.",
        }

    return {
        "mastery_decision": "PASS",
        "mastery_reason": "Non-demo record passed AIL and satisfies transfer requirement.",
        "next_required": None,
    }


def route_mastery_query(
    *,
    intent: str,
    record: Dict[str, Any],
    enforce_transfer: bool = True,
) -> Dict[str, Any]:
    """
    Minimal routing function. In the full router, intent classification selects this handler.
    """
    if intent not in {"mastery_check", "evidence_eligibility"}:
        return {"error": f"Unsupported intent for mastery hook: {intent}"}
    return evaluate_mastery_for_record(record, enforce_transfer=enforce_transfer)
