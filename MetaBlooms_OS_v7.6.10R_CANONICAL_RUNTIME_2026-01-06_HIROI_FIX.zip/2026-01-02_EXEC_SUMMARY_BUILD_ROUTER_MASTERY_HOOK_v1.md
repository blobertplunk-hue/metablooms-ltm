# Executive Summary (Build) — Router Mastery Hook v1

This update adds a dedicated adapter (`metablooms_query_router_mastery_hook_v1.py`) that lets the Query Router evaluate whether a given evidence record is eligible to count toward mastery.

What it enforces:
- DEMO data is hard-blocked from mastery (via the existing Mastery Gate).
- Mastery is held unless there is transfer evidence (near + mid) or transfer enforcement is explicitly disabled.

Why it matters:
- It prevents “good-looking” demo runs from being mistaken as real learning.
- It makes mastery queries fast and consistent: the router calls one function instead of re-reading system files.
